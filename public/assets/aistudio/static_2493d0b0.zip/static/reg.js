/* Окно входа / регистрации Leaf.
   Работает через локальный адаптер: /api/login, /api/login/verify, /api/register, /api/register/verify, *_resend.
   После успешного подтверждения кода сообщает приложению (pywebview.api.auth_done) — оно откроет главное окно. */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const screens = { register: $('screen-register'), login: $('screen-login'), verify: $('screen-verify') };
  const loading = $('loading');
  const otpBoxes = Array.prototype.slice.call(document.querySelectorAll('#otp-row .otp-box'));
  let pending = { mode: 'login', gmail: '' };
  let resendTimer = null;

  function showScreen(name) {
    Object.keys(screens).forEach((k) => screens[k] && screens[k].classList.toggle('active', k === name));
    const first = screens[name] && screens[name].querySelector('input');
    if (first) setTimeout(() => first.focus(), 50);
  }
  function setLoading(on) { if (loading) loading.hidden = !on; }
  function setError(id, text, ok) {
    const el = $(id);
    if (!el) return;
    el.textContent = text || '';
    el.classList.toggle('success', !!ok);
  }
  function clearErrors() { ['reg-error', 'login-error', 'verify-error'].forEach((id) => setError(id, '')); }

  async function post(url, body) {
    let res;
    try {
      res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    } catch (e) {
      return { ok: false, message: 'Сервер недоступен' };
    }
    let data = null;
    try { data = await res.json(); } catch (e) {  }
    if (res.ok) return { ok: true, data: data || {} };
    let msg = data && typeof data.detail === 'string' ? data.detail : '';
    if (!msg) msg = res.status === 503 ? 'Сервер недоступен' : 'Ошибка (' + res.status + ')';
    return { ok: false, message: msg };
  }

  /* ---------- переключение экранов ---------- */
  document.querySelectorAll('[data-switch]').forEach((a) => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      clearErrors();
      showScreen(a.getAttribute('data-switch'));
    });
  });

  /* ---------- код подтверждения ---------- */
  function otpValue() { return otpBoxes.map((b) => b.value.replace(/\D/g, '')).join(''); }
  function otpClear() { otpBoxes.forEach((b) => { b.value = ''; }); if (otpBoxes[0]) otpBoxes[0].focus(); }
  otpBoxes.forEach((box, i) => {
    box.addEventListener('input', () => {
      box.value = box.value.replace(/\D/g, '').slice(0, 1);
      if (box.value && otpBoxes[i + 1]) otpBoxes[i + 1].focus();
      if (otpValue().length === otpBoxes.length) submitVerify();
    });
    box.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !box.value && otpBoxes[i - 1]) { otpBoxes[i - 1].focus(); otpBoxes[i - 1].value = ''; }
      else if (e.key === 'ArrowLeft' && otpBoxes[i - 1]) otpBoxes[i - 1].focus();
      else if (e.key === 'ArrowRight' && otpBoxes[i + 1]) otpBoxes[i + 1].focus();
    });
    box.addEventListener('paste', (e) => {
      const txt = ((e.clipboardData || window.clipboardData).getData('text') || '').replace(/\D/g, '');
      if (!txt) return;
      e.preventDefault();
      otpBoxes.forEach((b, j) => { b.value = txt[j] || ''; });
      const last = Math.min(txt.length, otpBoxes.length) - 1;
      if (otpBoxes[last]) otpBoxes[last].focus();
      if (txt.length >= otpBoxes.length) submitVerify();
    });
  });

  function openVerify(mode, gmail) {
    pending = { mode: mode, gmail: gmail };
    $('verify-gmail').textContent = gmail;
    clearErrors();
    otpClear();
    showScreen('verify');
    startResendCooldown();
  }
  function startResendCooldown() {
    const link = $('verify-resend');
    if (!link) return;
    clearInterval(resendTimer);
    let left = 30;
    link.style.pointerEvents = 'none'; link.style.opacity = '0.5';
    const tick = () => {
      if (left <= 0) {
        clearInterval(resendTimer);
        link.textContent = 'Отправить код ещё раз';
        link.style.pointerEvents = ''; link.style.opacity = '';
        return;
      }
      link.textContent = 'Отправить код ещё раз (' + left + ')';
      left -= 1;
    };
    tick();
    resendTimer = setInterval(tick, 1000);
  }

  /* ---------- вход ---------- */
  async function submitLogin() {
    const login = $('login-login').value.trim();
    const gmail = $('login-gmail').value.trim();
    const password = $('login-password').value;
    if (!login || !gmail || !password) { setError('login-error', 'Заполните все поля'); return; }
    setError('login-error', '');
    $('login-submit').disabled = true; setLoading(true);
    const r = await post('/api/login', { login: login, gmail: gmail, password: password });
    $('login-submit').disabled = false; setLoading(false);
    if (!r.ok) { setError('login-error', r.message); return; }
    openVerify('login', gmail);
  }

  /* ---------- регистрация ---------- */
  async function submitRegister() {
    const login = $('reg-login').value.trim();
    const username = $('reg-username').value.trim().replace(/^@/, '');
    const gmail = $('reg-gmail').value.trim();
    const password = $('reg-password').value;
    const confirm = $('reg-password-confirm').value;
    if (!login || !username || !gmail || !password) { setError('reg-error', 'Заполните все поля'); return; }
    if (password.length < 6) { setError('reg-error', 'Пароль — минимум 6 символов'); return; }
    if (password !== confirm) { setError('reg-error', 'Пароли не совпадают'); return; }
    if (!$('reg-agree').checked) { setError('reg-error', 'Нужно принять соглашение и политику конфиденциальности'); return; }
    setError('reg-error', '');
    $('reg-submit').disabled = true; setLoading(true);
    const r = await post('/api/register', {
      login: login, username: username, gmail: gmail, password: password, password_confirm: confirm, agree_to_terms: true,
    });
    $('reg-submit').disabled = false; setLoading(false);
    if (!r.ok) { setError('reg-error', r.message); return; }
    openVerify('register', gmail);
  }

  /* ---------- подтверждение кода ---------- */
  let verifying = false;
  async function submitVerify() {
    if (verifying) return;
    const code = otpValue();
    if (code.length < otpBoxes.length) { setError('verify-error', 'Введите код полностью'); return; }
    verifying = true;
    setError('verify-error', '');
    $('verify-submit').disabled = true; setLoading(true);
    const r = await post('/api/' + pending.mode + '/verify', { gmail: pending.gmail, code: code });
    verifying = false;
    $('verify-submit').disabled = false;
    if (!r.ok) { setLoading(false); setError('verify-error', r.message); otpClear(); return; }
    finishAuth();
  }

  function finishAuth() {
    // загрузочный экран остаётся, пока приложение открывает главное окно
    const api = window.pywebview && window.pywebview.api;
    if (api && typeof api.auth_done === 'function') {
      Promise.resolve(api.auth_done()).catch(() => { location.href = '/'; });
      // страховка: если окно не сменилось — открываем плеер здесь
      setTimeout(() => { if (document.visibilityState !== 'hidden') location.href = '/'; }, 6000);
    } else {
      location.href = '/';
    }
  }

  async function resend() {
    const r = await post('/api/' + pending.mode + '/resend', { gmail: pending.gmail });
    if (r.ok) { setError('verify-error', 'Код отправлен ещё раз', true); startResendCooldown(); }
    else setError('verify-error', r.message);
  }

  $('login-submit').addEventListener('click', submitLogin);
  $('reg-submit').addEventListener('click', submitRegister);
  $('verify-submit').addEventListener('click', submitVerify);
  $('verify-resend').addEventListener('click', (e) => { e.preventDefault(); resend(); });
  $('verify-back').addEventListener('click', (e) => {
    e.preventDefault(); clearErrors();
    showScreen(pending.mode === 'register' ? 'register' : 'login');
  });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (e.target && e.target.tagName === 'A') return;
    if (screens.login.classList.contains('active')) submitLogin();
    else if (screens.register.classList.contains('active')) submitRegister();
    else if (screens.verify.classList.contains('active')) submitVerify();
  });
})();
