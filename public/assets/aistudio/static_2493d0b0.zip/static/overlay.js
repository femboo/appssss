(function () {
  'use strict';

  var I18N = {
    ru: { none: 'Ничего не играет', hint: 'Выберите трек в Leaf' },
    en: { none: 'Nothing playing', hint: 'Pick a track in Leaf' },
    pl: { none: 'Nic nie gra', hint: 'Wybierz utwór w Leaf' },
  };
  var FALLBACK_COVER = 'images/Leaf.png';

  function $(id) { return document.getElementById(id); }
  var island = $('island'), glow = $('glow');
  var elCover = $('cover'), elPillCover = $('pill-cover');
  var elTitle = $('title'), elArtist = $('artist');
  var barEl = $('bar'), barFill = $('bar-fill'), barKnob = $('bar-knob');
  var tCur = $('t-cur'), tRem = $('t-rem');
  var bLike = $('b-like');

  var st = null;          // последнее состояние с сервера
  var stAt = 0;           // performance.now() в момент получения
  var isOpen = false;     // остров раскрыт (решает Python: наведение курсора или хоткей)
  var active = false;     // оверлей показан: идёт опрос состояния
  var pollTimer = 0, measureTimer = 0, rafId = 0, dragging = false, dragFrac = 0;
  var lastCover = '', lastTitle = '', lastArtist = '', lastLang = '';

  /* ---------- связь с Python (pywebview js_api окна оверлея) ---------- */
  function call(name) {
    var args = Array.prototype.slice.call(arguments, 1);
    var api = window.pywebview && window.pywebview.api;
    if (api && typeof api[name] === 'function') {
      try { api[name].apply(api, args); } catch (e) {}
    }
  }

  /* ---------- состояние ---------- */
  function poll() {
    fetch('/api/overlay/state', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) { st = j; stAt = performance.now(); applyStatic(); })
      .catch(function () {});
  }

  function position() {
    if (!st) return 0;
    if (dragging) return dragFrac * (st.duration || 0);
    var p = st.position || 0;
    if (st.is_playing) p += (st.age || 0) + (performance.now() - stAt) / 1000;
    var d = st.duration || 0;
    return d > 0 ? Math.max(0, Math.min(d, p)) : Math.max(0, p);
  }

  function fmt(s) {
    s = Math.max(0, Math.floor(s));
    var m = Math.floor(s / 60), r = s % 60;
    return m + ':' + (r < 10 ? '0' : '') + r;
  }

  /* Бегущая строка включается только если текст не влезает. Мерить можно лишь когда карточка раскрыта
     (в свёрнутом состоянии ширина контейнера ~0), поэтому после открытия перемеряем ещё раз. */
  function measure(wrap) {
    var span = wrap.firstElementChild;
    wrap.classList.remove('scroll');
    span.style.removeProperty('--shift');
    if (!isOpen || !island.classList.contains('open')) return;
    var over = span.scrollWidth - wrap.clientWidth;
    if (over > 4) { span.style.setProperty('--shift', '-' + (over + 14) + 'px'); wrap.classList.add('scroll'); }
  }
  function remeasureAll() { measure($('title-wrap')); measure($('artist-wrap')); }
  function setMarquee(wrap, span, text) {
    span.textContent = text;
    requestAnimationFrame(function () { measure(wrap); });
  }

  function applyStatic() {
    if (!st) return;
    var L = I18N[st.lang] || I18N.ru;
    if (st.accent) document.documentElement.style.setProperty('--accent', st.accent);
    if (st.lang !== lastLang) { lastLang = st.lang; $('empty-t').textContent = L.none; $('empty-s').textContent = L.hint; }

    island.classList.toggle('noplay', !st.has_track);
    island.classList.toggle('paused', !st.is_playing);
    bLike.classList.toggle('liked', !!st.liked);

    var cover = st.cover || FALLBACK_COVER;
    if (cover !== lastCover) {
      lastCover = cover;
      elCover.src = cover; elPillCover.src = cover;
      glow.style.backgroundImage = 'url("' + cover.replace(/"/g, '%22') + '")';
    }
    if (st.title !== lastTitle) { lastTitle = st.title; setMarquee($('title-wrap'), elTitle, st.title || ''); }
    if (st.artist !== lastArtist) { lastArtist = st.artist; setMarquee($('artist-wrap'), elArtist, st.artist || ''); }
  }

  function frame() {
    rafId = 0;
    if (!isOpen) return;
    if (st) {
      var d = st.duration || 0, p = position();
      var f = d > 0 ? p / d : 0;
      barFill.style.width = (f * 100) + '%';
      barKnob.style.left = (f * 100) + '%';
      tCur.textContent = fmt(p);
      tRem.textContent = d > 0 ? '-' + fmt(d - p) : '--:--';
    }
    rafId = requestAnimationFrame(frame);
  }

  /* ---------- раскрытие / сворачивание (команды из Python) ---------- */
  /* Наведение курсора определяет Python (GetCursorPos): окно не активируется и обрезается по форме
     острова, поэтому события мыши в странице ненадёжны. Страница только рисует состояние. */
  function applyOpen(want) {
    want = !!want;
    if (want === isOpen) return;
    isOpen = want;
    island.classList.toggle('open', want);
    clearTimeout(measureTimer);
    if (want) {
      poll();
      measureTimer = setTimeout(remeasureAll, 650);        // после анимации раскрытия
      if (!rafId) rafId = requestAnimationFrame(frame);
    } else {
      remeasureAll();                                      // сбрасывает бегущую строку
      if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    }
  }
  window.leafOverlaySet = applyOpen;
  window.leafOverlayShow = function () {            // оверлей включён: показываем маленькую «таблетку»
    active = true;
    poll();
    clearInterval(pollTimer);
    pollTimer = setInterval(poll, 1000);
  };
  window.leafOverlayHide = function () {            // оверлей выключен
    active = false;
    clearInterval(pollTimer); pollTimer = 0;
    applyOpen(false);
  };

  /* ---------- кнопки ---------- */
  $('b-play').addEventListener('click', function () {
    if (st) { st.is_playing = !st.is_playing; st.position = position(); st.age = 0; stAt = performance.now(); island.classList.toggle('paused', !st.is_playing); }
    call('cmd', 'playPause');
  });
  $('b-next').addEventListener('click', function () { call('cmd', 'next'); });
  $('b-prev').addEventListener('click', function () { call('cmd', 'prev'); });
  bLike.addEventListener('click', function () {
    if (st) { st.liked = !st.liked; bLike.classList.toggle('liked', st.liked); }
    call('cmd', 'like');
  });
  $('close-btn').addEventListener('click', function () { call('collapse'); });   // свернуть обратно в «таблетку»

  /* ---------- перемотка по полосе ---------- */
  function fracFromEvent(e) {
    var r = barEl.getBoundingClientRect();
    return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
  }
  barEl.addEventListener('pointerdown', function (e) {
    if (!st || !st.duration) return;
    dragging = true; dragFrac = fracFromEvent(e);
    barEl.classList.add('drag');
    try { barEl.setPointerCapture(e.pointerId); } catch (err) {}
  });
  barEl.addEventListener('pointermove', function (e) { if (dragging) dragFrac = fracFromEvent(e); });
  function endDrag(e) {
    if (!dragging) return;
    dragging = false;
    barEl.classList.remove('drag');
    var secs = dragFrac * (st.duration || 0);
    st.position = secs; st.age = 0; stAt = performance.now();
    call('cmd', 'seek', secs);
  }
  barEl.addEventListener('pointerup', endDrag);
  barEl.addEventListener('pointercancel', endDrag);

  /* запрет контекстного меню и перетаскивания картинок */
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
})();
