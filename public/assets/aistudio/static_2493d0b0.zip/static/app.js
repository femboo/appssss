(function () {
  'use strict';

  const ICON_PATHS = {
    home: '<path d="M3 9.5 12 3l9 6.5V21a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    library: '<path d="M4 4h4v16H4zM10 4h4v16h-4zM17 4l4 1v15l-4-1z"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/>',
    radio: '<circle cx="12" cy="12" r="2"/><path d="M4.9 19.1a10 10 0 0 1 0-14.2M19.1 4.9a10 10 0 0 1 0 14.2M7.8 16.2a5.5 5.5 0 0 1 0-8.4M16.2 7.8a5.5 5.5 0 0 1 0 8.4"/>',
    leaf: '<path d="M11 20A7 7 0 0 1 4 13c0-4 4-11 15-11 0 11-7 15-11 15Z"/><path d="M4 20 15 9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.2a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.2a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.6V3a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.6 1H21a2 2 0 1 1 0 4h-.2a1.7 1.7 0 0 0-1.6 1Z"/>',
    play: '<path d="M6 4.5v15l13-7.5Z"/>',
    pause: '<path d="M6 4h4v16H6zM14 4h4v16h-4z"/>',
    skipBack: '<path d="M19 5v14L8 12ZM5 5v14"/>',
    skipForward: '<path d="M5 5v14l11-7ZM19 5v14"/>',
    shuffle: '<path d="M2 5h4l10 14h6M2 19h4l4-5.5M18 5h4v4M22 5l-6 7M22 19l-6-7"/>',
    repeat: '<path d="M17 2l4 4-4 4M3 12v-2a4 4 0 0 1 4-4h14M7 22l-4-4 4-4M21 12v2a4 4 0 0 1-4 4H3"/>',
    volume2: '<path d="M5 9v6h4l5 5V4L9 9Z"/><path d="M16 8a5 5 0 0 1 0 8M18.5 5.5a9 9 0 0 1 0 13"/>',
    volume1: '<path d="M5 9v6h4l5 5V4L9 9Z"/><path d="M16 8a5 5 0 0 1 0 8"/>',
    volumeX: '<path d="M5 9v6h4l5 5V4L9 9Z"/><path d="M17 9l5 6M22 9l-5 6"/>',
    mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 19v3"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M2 14h4M10 8h4M18 12h4"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    rotateCcw: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    volumeIcon: '<path d="M5 9v6h4l5 5V4L9 9Z"/>',
    trendingUp: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
    sparkles: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8"/>',
    headphones: '<path d="M3 14v-2a9 9 0 0 1 18 0v2"/><rect x="3" y="14" width="5" height="7" rx="1.5"/><rect x="16" y="14" width="5" height="7" rx="1.5"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7Z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v5h1"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>',
    palette: '<circle cx="12" cy="12" r="9"/><circle cx="9" cy="10" r="1.2"/><circle cx="13" cy="8.5" r="1.2"/><circle cx="16" cy="11.5" r="1.2"/><circle cx="10.5" cy="15" r="1.2"/><path d="M12 3a9 9 0 0 0 0 18c1.2 0 2-.8 2-2 0-.6-.3-1-.6-1.4-.3-.4-.6-.8-.6-1.4 0-.9.7-1.6 1.6-1.6H16a4 4 0 0 0 4-4 9 9 0 0 0-8-8.6Z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  };
  const LIKES_COVER = 'images/Likes.png';
  const PNG_ICONS = {
    play: 'Wave', pause: 'Pause', skipBack: 'Previous', skipForward: 'Next', shuffle: 'Shuffle', repeat: 'Repeat',
    heart: 'Heart', volume2: 'Volume', volume1: 'VolumeLow', volumeX: 'Mute',
    home: 'Home', search: 'Search', library: 'Book Shelf', settings: 'Settings',
    music: 'Music', trash: 'trash', leaf: 'Leaf', user: 'User',
  };
  function icon(name, cls, attrs, svgOnly) {
    if (PNG_ICONS[name] && !svgOnly) return `<span class="pic pic-${name} ico ${cls || ''}" ${attrs || ''}></span>`;
    return `<svg class="ico ${cls || ''}" ${attrs || ''} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICON_PATHS[name] || ''}</svg>`;
  }

  const I18N = {
    ru: {
      appName: 'Leaf', tagline: 'Музыка для души',
      navHome: 'Главная', navSearch: 'Поиск', navLibrary: 'Моя медиатека', navLiked: 'Любимые треки',
      createPlaylist: 'Создать плейлист',
      searchPlaceholder: 'Поиск...', searchPlaceholderFull: 'Треки, исполнители, альбомы...', searchHint: 'Введите запрос и нажмите Enter',
      light: 'Светлая', dark: 'Тёмная',
      tracks: 'треков',
      search: 'Поиск', yourLibrary: 'Моя медиатека',
      playlistWord: 'Плейлист', likedSongs: 'Любимые треки', noLiked: 'Пока нет любимых треков. Нажмите на сердечко у трека.',
      recentlyPlayed: 'Недавно слушали', recentSub: 'Продолжите с того места, где остановились',
      popularNow: 'Популярное сейчас', popularSub: 'Подборка популярных треков',
      showAll: 'Показать все', showLess: 'Свернуть', retry: 'Повторить', loadFailed: 'Не удалось загрузить треки',
      deletePlaylist: 'Удалить плейлист', removeFromPlaylist: 'Удалить из плейлиста',
      nothingPlaying: 'Ничего не играет', equalizerTitle: 'Эквалайзер',
      settings: 'Настройки', personalize: 'Настройте Leaf под себя',
      appearance: 'Внешний вид', styleLabel: 'Стиль', darkMode: 'Тёмный режим', lightMode: 'Светлый режим',
      colorTheme: 'Цветовая тема',
      myPresets: 'Мои пресеты', presetNamePlaceholder: 'Название пресета', savePreset: 'Сохранить', deletePreset: 'Удалить пресет',
      themeGreen: 'Зелёная', themeBlue: 'Синяя', themeWhite: 'Белая', themeRed: 'Красная', themePurple: 'Фиолетовая',
      language: 'Язык',
      langRu: 'Русский', langPl: 'Polski', langEn: 'English',
      devices: 'Устройства', outputDevice: 'Устройство вывода', connected: 'Подключено',
      externalDeviceConnected: 'Внешнее аудиоустройство', systemDefaultDevice: 'Системное устройство по умолчанию',
      about: 'Leaf Music', version: 'Версия 1.0.0 — сделано с любовью',
      equalizer: 'Эквалайзер', shapeSound: 'Настройте звучание',
      presets: 'Пресеты', bassBoost: 'Усиление баса', reverb: 'Реверберация',
      noResults: 'Ничего не найдено. Попробуйте другой запрос.', resultsFor: 'Результаты по запросу',
      showMore: 'Показать больше', loadingMore: 'Загрузка...',
      greetingMorning: 'Доброе утро', greetingDay: 'Добрый день', greetingEvening: 'Добрый вечер', greetingNight: 'Доброй ночи',
      createPlaylistTitle: 'Новый плейлист', playlistNamePlaceholder: 'Название плейлиста', create: 'Создать', cancel: 'Отмена',
      addToPlaylist: 'Добавить в плейлист', newPlaylist: 'Новый плейлист', noPlaylistsYet: 'У вас пока нет плейлистов',
      emptyPlaylist: 'В этом плейлисте пока нет треков', tracksByArtist: 'Треки',
      outputDeviceUnknown: 'Не удалось определить устройство',
      collapse: 'Свернуть', vinylView: 'Вид пластинки', lyricsTitle: 'Текст песни', lyricsLoading: 'Загружаем текст…', lyricsNotFound: 'Текст песни не найден',
    },
    pl: {
      appName: 'Leaf', tagline: 'Muzyka dla duszy',
      navHome: 'Strona główna', navSearch: 'Szukaj', navLibrary: 'Twoja biblioteka', navLiked: 'Ulubione utwory',
      createPlaylist: 'Utwórz playlistę',
      searchPlaceholder: 'Szukaj...', searchPlaceholderFull: 'Utwory, artyści, albumy...', searchHint: 'Wpisz zapytanie i naciśnij Enter',
      light: 'Jasny', dark: 'Ciemny',
      tracks: 'utworów',
      search: 'Szukaj', yourLibrary: 'Twoja biblioteka',
      playlistWord: 'Playlista', likedSongs: 'Ulubione utwory', noLiked: 'Brak ulubionych utworów. Kliknij serce przy utworze.',
      recentlyPlayed: 'Ostatnio słuchane', recentSub: 'Wróć do tego, co grało',
      popularNow: 'Popularne teraz', popularSub: 'Wybór popularnych utworów',
      showAll: 'Pokaż wszystko', showLess: 'Zwiń', retry: 'Spróbuj ponownie', loadFailed: 'Nie udało się załadować utworów',
      deletePlaylist: 'Usuń playlistę', removeFromPlaylist: 'Usuń z playlisty',
      nothingPlaying: 'Nic nie jest odtwarzane', equalizerTitle: 'Korektor',
      settings: 'Ustawienia', personalize: 'Dostosuj Leaf do siebie',
      appearance: 'Wygląd', styleLabel: 'Styl', darkMode: 'Tryb ciemny', lightMode: 'Tryb jasny',
      colorTheme: 'Motyw kolorystyczny',
      myPresets: 'Moje ustawienia', presetNamePlaceholder: 'Nazwa ustawienia', savePreset: 'Zapisz', deletePreset: 'Usuń ustawienie',
      themeGreen: 'Zielony', themeBlue: 'Niebieski', themeWhite: 'Biały', themeRed: 'Czerwony', themePurple: 'Fioletowy',
      language: 'Język',
      langRu: 'Rosyjski', langPl: 'Polski', langEn: 'Angielski',
      devices: 'Urządzenia', outputDevice: 'Urządzenie wyjściowe', connected: 'Połączono',
      externalDeviceConnected: 'Zewnętrzne urządzenie audio', systemDefaultDevice: 'Domyślne urządzenie systemowe',
      about: 'Leaf Music', version: 'Wersja 1.0.0 — stworzone z troską',
      equalizer: 'Korektor', shapeSound: 'Ukształtuj swój dźwięk',
      presets: 'Ustawienia wstępne', bassBoost: 'Wzmocnienie basu', reverb: 'Pogłos',
      noResults: 'Brak wyników. Spróbuj innego zapytania.', resultsFor: 'Wyniki dla',
      showMore: 'Pokaż więcej', loadingMore: 'Ładowanie...',
      greetingMorning: 'Dzień dobry', greetingDay: 'Dzień dobry', greetingEvening: 'Dobry wieczór', greetingNight: 'Dobranoc',
      createPlaylistTitle: 'Nowa playlista', playlistNamePlaceholder: 'Nazwa playlisty', create: 'Utwórz', cancel: 'Anuluj',
      addToPlaylist: 'Dodaj do playlisty', newPlaylist: 'Nowa playlista', noPlaylistsYet: 'Nie masz jeszcze playlist',
      emptyPlaylist: 'Ta playlista jest jeszcze pusta', tracksByArtist: 'Utwory',
      outputDeviceUnknown: 'Nie udało się wykryć urządzenia',
      collapse: 'Zwiń', vinylView: 'Widok płyty', lyricsTitle: 'Tekst piosenki', lyricsLoading: 'Ładowanie tekstu…', lyricsNotFound: 'Nie znaleziono tekstu piosenki',
    },
    en: {
      appName: 'Leaf', tagline: 'Music for the soul',
      navHome: 'Home', navSearch: 'Search', navLibrary: 'Your Library', navLiked: 'Liked Songs',
      createPlaylist: 'Create Playlist',
      searchPlaceholder: 'Search...', searchPlaceholderFull: 'Songs, artists, albums...', searchHint: 'Type a query and press Enter',
      light: 'Light', dark: 'Dark',
      tracks: 'tracks',
      search: 'Search', yourLibrary: 'Your Library',
      playlistWord: 'Playlist', likedSongs: 'Liked Songs', noLiked: 'No liked songs yet. Tap the heart on any track.',
      recentlyPlayed: 'Recently played', recentSub: 'Pick up where you left off',
      popularNow: 'Popular right now', popularSub: 'A selection of popular tracks',
      showAll: 'Show all', showLess: 'Show less', retry: 'Retry', loadFailed: 'Could not load tracks',
      deletePlaylist: 'Delete playlist', removeFromPlaylist: 'Remove from playlist',
      nothingPlaying: 'Nothing playing', equalizerTitle: 'Equalizer',
      settings: 'Settings', personalize: 'Personalize your Leaf',
      appearance: 'Appearance', styleLabel: 'Style', darkMode: 'Dark mode', lightMode: 'Light mode',
      colorTheme: 'Color Theme',
      myPresets: 'My presets', presetNamePlaceholder: 'Preset name', savePreset: 'Save', deletePreset: 'Delete preset',
      themeGreen: 'Green', themeBlue: 'Blue', themeWhite: 'White', themeRed: 'Red', themePurple: 'Purple',
      language: 'Language',
      langRu: 'Russian', langPl: 'Polish', langEn: 'English',
      devices: 'Devices', outputDevice: 'Output Device', connected: 'Connected',
      externalDeviceConnected: 'External audio device', systemDefaultDevice: 'System default device',
      about: 'Leaf Music', version: 'Version 1.0.0 — Crafted with care',
      equalizer: 'Equalizer', shapeSound: 'Shape your sound',
      presets: 'Presets', bassBoost: 'Bass Boost', reverb: 'Reverb',
      noResults: 'No results found. Try a different query.', resultsFor: 'Results for',
      showMore: 'Show more', loadingMore: 'Loading...',
      greetingMorning: 'Good morning', greetingDay: 'Good afternoon', greetingEvening: 'Good evening', greetingNight: 'Good night',
      createPlaylistTitle: 'New Playlist', playlistNamePlaceholder: 'Playlist name', create: 'Create', cancel: 'Cancel',
      addToPlaylist: 'Add to playlist', newPlaylist: 'New playlist', noPlaylistsYet: "You don't have any playlists yet",
      emptyPlaylist: 'This playlist has no tracks yet', tracksByArtist: 'Tracks',
      outputDeviceUnknown: 'Could not detect a device',
      collapse: 'Collapse', vinylView: 'Vinyl view', lyricsTitle: 'Lyrics', lyricsLoading: 'Loading lyrics…', lyricsNotFound: 'Lyrics not found',
    },
  };
  function t(key) { return (I18N[state.language] && I18N[state.language][key]) || I18N.en[key] || key; }
  Object.assign(I18N.ru, {
    czBackground: 'Фон', czNone: 'Без фона', czCustomImage: 'Свой файл', czAccountBg: 'Фон аккаунта',
    czDim: 'Затемнение', czBlur: 'Размытие', czRemoveBg: 'Убрать фон', czSyncBg: 'Сохранять фон в аккаунте (синхронизация)',
    czAccent: 'Свой цвет акцента', czAccentReset: 'Сбросить', czEffects: 'Эффекты', czOff: 'Выкл', czSnow: 'Снег', czRain: 'Дождь',
    czLibrary: 'Библиотека тем', czLibraryLocal: 'Встроенные', czLibraryServer: 'Темы сервера',
    czServerLoading: 'Загрузка тем…', czServerEmpty: 'На сервере пока нет тем', czServerError: 'Не удалось загрузить темы сервера', czRetry: 'Повторить',
    czNeedTier: 'Эта тема требует другой тариф', czRateLimited: 'Слишком часто меняете тему — попробуйте позже',
    czThemeFail: 'Не удалось применить тему на сервере', czBadType: 'Поддерживаются JPG, PNG, GIF и WEBP',
    czUploadFail: 'Не удалось обработать изображение', czImageTooBig: 'Изображение слишком большое для локального хранилища',
    czFileOver10: 'Файл больше 10 МБ — в аккаунт не загружен', czSynced: 'Фон сохранён в аккаунте', czSyncFail: 'Не удалось сохранить фон в аккаунте',
    czApplied: 'Тема применена',
  });
  Object.assign(I18N.en, {
    czBackground: 'Background', czNone: 'No background', czCustomImage: 'Your image', czAccountBg: 'Account background',
    czDim: 'Dimming', czBlur: 'Blur', czRemoveBg: 'Remove background', czSyncBg: 'Save background to account (sync)',
    czAccent: 'Custom accent color', czAccentReset: 'Reset', czEffects: 'Effects', czOff: 'Off', czSnow: 'Snow', czRain: 'Rain',
    czLibrary: 'Theme library', czLibraryLocal: 'Built-in', czLibraryServer: 'Server themes',
    czServerLoading: 'Loading themes…', czServerEmpty: 'No themes on the server yet', czServerError: 'Could not load server themes', czRetry: 'Retry',
    czNeedTier: 'This theme requires a different plan', czRateLimited: 'Changing themes too often — try again later',
    czThemeFail: 'Could not apply the theme on the server', czBadType: 'Only JPG, PNG, GIF and WEBP are supported',
    czUploadFail: 'Could not process the image', czImageTooBig: 'Image is too large for local storage',
    czFileOver10: 'File is over 10 MB — not uploaded to the account', czSynced: 'Background saved to your account', czSyncFail: 'Could not save the background to your account',
    czApplied: 'Theme applied',
  });

  function svgDataUri(svg) { return 'data:image/svg+xml,' + encodeURIComponent(svg); }
  const DEFAULT_TRACK_COVER = svgDataUri(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">' +
    '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
    '<stop offset="0" stop-color="#52525b"/><stop offset="1" stop-color="#18181b"/></linearGradient></defs>' +
    '<rect width="200" height="200" fill="url(#g)"/>' +
    '<path d="M120 55v70a22 22 0 1 1-10-18V70l-40 10v58a22 22 0 1 1-10-18V60l60-15z" fill="rgba(255,255,255,0.55)"/>' +
    '</svg>'
  );
  const DEFAULT_AVATAR = svgDataUri(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">' +
    '<defs><linearGradient id="a" x1="0" y1="0" x2="1" y2="1">' +
    '<stop offset="0" stop-color="#71717a"/><stop offset="1" stop-color="#27272a"/></linearGradient></defs>' +
    '<rect width="200" height="200" fill="url(#a)"/>' +
    '<circle cx="100" cy="80" r="34" fill="rgba(255,255,255,0.5)"/>' +
    '<path d="M40 176c8-42 40-62 60-62s52 20 60 62" fill="rgba(255,255,255,0.5)"/>' +
    '</svg>'
  );
  const STOCK_COVER_RE = /pexels\.com\/photos\/1370545/;
  function coverOf(tr) {
    const c = tr && tr.cover;
    return (c && !STOCK_COVER_RE.test(c)) ? c : DEFAULT_TRACK_COVER;
  }

  function isScTrack(tr) { return !!tr && /^\d+$/.test(String(tr.id)) && (tr.source || 'soundcloud') === 'soundcloud'; }
  function isYtTrack(tr) { return !!tr && /^yt_[A-Za-z0-9_-]{11}$/.test(String(tr.id)); }
  function isServerTrack(tr) { return isScTrack(tr) || isYtTrack(tr); }
  function isPlayableTrack(tr) { return !!(tr && (tr.streamSrc || isServerTrack(tr))); }
  let safeAudio = false;
  try { safeAudio = localStorage.getItem('leaf-safe-audio') === '1'; } catch (e) {  }
  function streamUrlFor(tr) {
    const q = [];
    if (isServerTrack(tr)) q.push('id=' + encodeURIComponent(tr.id));
    if (tr.streamSrc) q.push('url=' + encodeURIComponent(tr.streamSrc));
    if (safeAudio) q.push('safe=1');
    return '/stream?' + q.join('&');
  }

  let tracks = [];
  let searchResults = [];
  let allKnownTracks = {};
  function registerTracks(list) {
    (list || []).forEach((tr) => { if (tr && tr.id) allKnownTracks[tr.id] = tr; });
  }

  function formatTime(seconds) {
    if (!seconds || !isFinite(seconds)) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  const NAV_ITEMS = [
    { id: 'home', icon: 'home', key: 'navHome' },
    { id: 'search', icon: 'search', key: 'navSearch' },
    { id: 'library', icon: 'library', key: 'navLibrary' },
    { id: 'liked', icon: 'heart', key: 'navLiked' },
  ];

  const COLOR_THEMES = ['green', 'blue', 'white', 'red', 'purple'];

  const EQ_BANDS = [60, 170, 310, 600, 1000, 3000, 6000, 12000, 14000, 16000];
  const EQ_BAND_LABELS = ['60', '170', '310', '600', '1K', '3K', '6K', '12K', '14K', '16K'];
  const EQ_PRESETS = {
    Flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    Bass: [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
    Treble: [0, 0, 0, 0, 0, 2, 4, 5, 6, 6],
    Vocal: [-2, 0, 2, 4, 4, 2, 0, -1, -2, -2],
    Rock: [4, 3, 0, -2, -1, 2, 4, 5, 5, 4],
    Jazz: [3, 2, 1, 2, -1, -1, 0, 1, 2, 3],
    Classical: [3, 2, 1, 0, 0, 0, -1, -2, -2, -2],
    Electronic: [5, 4, 1, 0, -2, 2, 3, 4, 4, 5],
    Pop: [-1, 1, 3, 4, 3, 0, -1, -1, -2, -2],
    'Hip-Hop': [5, 4, 2, 3, -1, -1, 2, -1, 2, 3],
    Dance: [6, 5, 3, 0, 0, -3, -4, -4, 0, 0],
    Acoustic: [4, 4, 3, 1, 2, 2, 3, 3, 3, 2],
    Metal: [5, 4, 1, 0, -2, 0, 3, 5, 6, 5],
    Lounge: [-3, -1, 2, 3, 1, -1, -2, 0, 1, 2],
    Piano: [2, 1, 0, 2, 3, 2, 3, 4, 3, 3],
    'R&B': [3, 6, 5, 1, -2, -1, 2, 2, 2, 3],
    Latin: [3, 2, 0, 0, -1, -1, -1, 0, 3, 4],
    Podcast: [-4, -3, 0, 3, 5, 5, 3, 0, -2, -3],
    Loudness: [6, 4, 1, 0, -1, 0, 1, 3, 5, 5],
    'Late Night': [-3, -1, 0, 2, 3, 2, 1, -1, -3, -4],
    'Bass Reducer': [-6, -5, -4, -2, 0, 0, 0, 0, 0, 0],
    'Treble Reducer': [0, 0, 0, 0, 0, 0, -2, -4, -5, -6],
  };

  function loadSettings() {
    try {
      const raw = localStorage.getItem('leaf-settings');
      if (raw) return JSON.parse(raw);
    } catch (e) {  }
    return {};
  }
  function saveSettings() {
    try {
      localStorage.setItem('leaf-settings', JSON.stringify({
        style: state.style,
        colorTheme: state.colorTheme,
        language: state.language,
      }));
    } catch (e) {  }
  }
  const saved = loadSettings();

  function loadLikes() {
    try {
      const raw = localStorage.getItem('leaf-likes');
      if (raw) return JSON.parse(raw);
    } catch (e) {  }
    return {};
  }
  function saveLikes() {
    try { localStorage.setItem('leaf-likes', JSON.stringify(likedTracksData)); } catch (e) {  }
  }
  let likedTracksData = loadLikes();
  function likedList() {
    return Object.values(likedTracksData).sort((a, b) => (b._ord || 0) - (a._ord || 0));
  }
  function nextLikedOrd() {
    let m = 0;
    Object.values(likedTracksData).forEach((t) => { if ((t._ord || 0) > m) m = t._ord; });
    return m + 1;
  }

  function loadCachedUser() {
    try { const u = JSON.parse(localStorage.getItem('leaf-user') || 'null'); return u && u.name ? u : null; } catch (e) { return null; }
  }
  function loadRecents() {
    try {
      const a = JSON.parse(localStorage.getItem('leaf-recent') || '[]');
      return Array.isArray(a) ? a.filter(isPlayableTrack) : [];
    } catch (e) { return []; }
  }
  let recents = loadRecents();
  registerTracks(recents);
  function pushRecent(tr) {
    const slim = { id: tr.id, source: tr.source, title: tr.title, artist: tr.artist, cover: tr.cover,
      duration: tr.duration, genre: tr.genre, streamSrc: tr.streamSrc };
    recents = [slim].concat(recents.filter((x) => x.id !== tr.id)).slice(0, 12);
    try { localStorage.setItem('leaf-recent', JSON.stringify(recents)); } catch (e) {  }
  }

  const state = {
    style: saved.style === 'light' ? 'light' : 'dark',
    colorTheme: COLOR_THEMES.includes(saved.colorTheme) ? saved.colorTheme : 'green',
    language: I18N[saved.language] ? saved.language : 'ru',
    view: 'home',
    currentTrack: null,
    isPlaying: false,
    progress: 0,
    volume: 70,
    shuffle: false,
    repeat: false,
    likedTracks: new Set(Object.keys(likedTracksData)),
    eqOpen: false,
    settingsOpen: false,
    searchQuery: '',
    searchLoading: false,
    searchLoadingMore: false,
    searchLimit: 50,
    searchHasMore: false,
    queue: [],
    queueIndex: -1,
    user: loadCachedUser(),
    homeStatus: 'loading',
    homeExpanded: false,
    fullOpen: false,
    lyricsOpen: false,
    vinyl: (() => { try { return localStorage.getItem('leaf-vinyl') === '1'; } catch (e) { return false; } })(),
    _animNext: false,
    _seeking: false,
    _seekPct: 0,
    audioDevice: null,
    currentArtistName: null,
    currentPlaylistId: null,
    addToPlaylistTrackId: null,
    createPlaylistOpen: false,
    _rendering: false,
  };

  function loadEqState() {
    const st = { bands: [...EQ_PRESETS.Flat], activePreset: 'Flat', enabled: true, bassBoost: 0, reverb: 0 };
    try {
      const raw = JSON.parse(localStorage.getItem('leaf-eq') || 'null');
      if (raw && Array.isArray(raw.bands) && raw.bands.length === EQ_BANDS.length) {
        st.bands = raw.bands.map((n) => Math.max(-12, Math.min(12, Number(n) || 0)));
        st.activePreset = typeof raw.activePreset === 'string' ? raw.activePreset : 'Custom';
        st.enabled = raw.enabled !== false;
        st.bassBoost = Math.max(0, Math.min(12, Number(raw.bassBoost) || 0));
        st.reverb = Math.max(0, Math.min(100, Number(raw.reverb) || 0));
      }
    } catch (e) {  }
    return st;
  }
  const eqState = loadEqState();
  let _eqSaveTimer = null;
  function saveEqState() {
    clearTimeout(_eqSaveTimer);
    _eqSaveTimer = setTimeout(() => {
      try { localStorage.setItem('leaf-eq', JSON.stringify(eqState)); } catch (e) {  }
    }, 250);
  }
  function loadEqCustom() {
    try {
      const o = JSON.parse(localStorage.getItem('leaf-eq-custom') || '{}');
      return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
    } catch (e) { return {}; }
  }
  let eqCustom = loadEqCustom();
  function saveEqCustom() {
    try { localStorage.setItem('leaf-eq-custom', JSON.stringify(eqCustom)); } catch (e) {  }
  }

  let _appliedLook = null;
  function applyRootClasses() {
    const html = document.documentElement;
    const look = state.style + '|' + state.colorTheme + '|' + state.language;
    if (_appliedLook === look) return;
    if (_appliedLook !== null) {
      html.classList.add('theme-switching');
      clearTimeout(window._themeTimer);
      window._themeTimer = setTimeout(() => html.classList.remove('theme-switching'), 300);
    }
    _appliedLook = look;
    html.classList.toggle('dark', state.style === 'dark');
    COLOR_THEMES.forEach((c) => html.classList.toggle('theme-' + c, c === state.colorTheme));
    html.lang = state.language;
  }

  const audioEl = document.getElementById('audio-el');
  let audioCtx = null;
  let eqFilterNodes = [];
  let bassFilterNode = null;
  let convolverNode = null;
  let dryGainNode = null;
  let wetGainNode = null;

  function buildImpulseResponse(ctx, duration, decay) {
    const rate = ctx.sampleRate;
    const length = Math.max(1, Math.floor(rate * duration));
    const impulse = ctx.createBuffer(2, length, rate);
    for (let ch = 0; ch < 2; ch++) {
      const data = impulse.getChannelData(ch);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
      }
    }
    return impulse;
  }

  function ensureAudioGraph() {
    if (audioCtx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    audioCtx = new AC();
    const source = audioCtx.createMediaElementSource(audioEl);

    eqFilterNodes = EQ_BANDS.map((freq, i) => {
      const f = audioCtx.createBiquadFilter();
      f.type = 'peaking';
      f.frequency.value = freq;
      f.Q.value = 1;
      f.gain.value = eqState.enabled ? eqState.bands[i] : 0;
      return f;
    });

    bassFilterNode = audioCtx.createBiquadFilter();
    bassFilterNode.type = 'lowshelf';
    bassFilterNode.frequency.value = 120;
    bassFilterNode.gain.value = eqState.enabled ? eqState.bassBoost : 0;

    convolverNode = audioCtx.createConvolver();
    convolverNode.buffer = buildImpulseResponse(audioCtx, 2, 2.5);

    dryGainNode = audioCtx.createGain();
    wetGainNode = audioCtx.createGain();

    let node = source;
    eqFilterNodes.forEach((f) => { node.connect(f); node = f; });
    node.connect(bassFilterNode);
    bassFilterNode.connect(dryGainNode);
    bassFilterNode.connect(convolverNode);
    convolverNode.connect(wetGainNode);
    dryGainNode.connect(audioCtx.destination);
    wetGainNode.connect(audioCtx.destination);

    updateReverbMix();
  }

  function updateReverbMix() {
    if (!dryGainNode || !wetGainNode) return;
    const wet = eqState.enabled ? eqState.reverb / 100 : 0;
    wetGainNode.gain.value = wet * 0.6;
    dryGainNode.gain.value = 1 - wet * 0.4;
  }

  function applyEqToGraph() {
    saveEqState();
    if (!audioCtx) return;
    eqFilterNodes.forEach((f, i) => { f.gain.value = eqState.enabled ? eqState.bands[i] : 0; });
    if (bassFilterNode) bassFilterNode.gain.value = eqState.enabled ? eqState.bassBoost : 0;
    updateReverbMix();
  }

  let _pbTrackId = null;
  let _justLiked = null;

  function loadAndPlay(track) {
    if (!track) return;
    ensureAudioGraph();
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    state.currentTrack = track;
    state.progress = 0;
    pushRecent(track);
    audioEl.src = streamUrlFor(track);
    audioEl.volume = state.volume / 100;
    audioEl.play().catch(() => {  });
    renderAll();
  }

  function updatePlayerBarOnly() {
    const wrap = document.querySelector('.player-wrap');
    if (!wrap) return;
    const track = state.currentTrack;
    const trackId = track ? String(track.id) : null;
    const liked = track ? state.likedTracks.has(track.id) : false;
    const dur = track ? track.duration : 0;
    const pct = dur ? Math.min(100, Math.max(0, (state.progress / dur) * 100)) : 0;
    const volIcon = state.volume === 0 ? 'volumeX' : state.volume < 50 ? 'volume1' : 'volume2';
    const trackChanged = trackId !== _pbTrackId;
    _pbTrackId = trackId;
    const _setText = (el, v) => { if (el && el.textContent !== v) el.textContent = v; };
    if (trackChanged) {
      if (track) loadLyrics();
      else { lyr.key = null; lyr.lines = []; lyr.synced = false; lyr.status = 'idle'; }
    }
    updateTopLyric();

    if (trackChanged) {
      const meta = wrap.querySelector('.now-playing .meta');
      if (meta) {
        meta.innerHTML = `<p class="title text-primary-c truncate">${track ? esc(track.title) : t('nothingPlaying')}</p>`
          + (track
            ? `<div class="artist-row">${sourceBadge(track)}<button class="artist truncate artist-link" data-artist="${esc(track.artist)}">${esc(track.artist)}</button></div>`
            : `<p class="artist truncate">—</p>`);
      }
      const img = wrap.querySelector('.now-playing img');
      if (img) {
        const src = track ? coverOf(track) : DEFAULT_TRACK_COVER;
        if (img.getAttribute('src') !== src) {
          delete img.dataset.fb;
          img.onload = () => { img.onload = null; img.classList.remove('swap'); void img.offsetWidth; img.classList.add('swap'); };
          img.src = src;
        }
      }
    }

    const playBtn = wrap.querySelector('.play-btn');
    if (playBtn) {
      const k = state.isPlaying ? 'pause' : 'play';
      if (playBtn.dataset.ico !== k) {
        const first = playBtn.dataset.ico === undefined;
        playBtn.dataset.ico = k;
        playBtn.innerHTML = filled(icon(k));
        if (!first) { playBtn.classList.remove('swap'); void playBtn.offsetWidth; playBtn.classList.add('swap'); }
      }
    }

    const seekFill = wrap.querySelector('.track-fill');
    if (seekFill && !state._seeking) {
      if (trackChanged) {
        seekFill.classList.add('snap');
        seekFill.style.width = pct + '%';
        void seekFill.offsetWidth;
        seekFill.classList.remove('snap');
      } else {
        const w = pct.toFixed(1) + '%';
        if (seekFill.style.width !== w) seekFill.style.width = w;
      }
    }
    if (!state._seeking) _setText(wrap.querySelector('.seek-time.start'), formatTime(state.progress));
    _setText(wrap.querySelector('.seek-time.end'), formatTime(dur));

    const likeBtn = wrap.querySelector('#player-like');
    if (likeBtn) {
      if (trackId) setLikedClass(likeBtn, liked, trackId);
      else likeBtn.classList.remove('liked');
    }
    const shuffleBtn = wrap.querySelector('#btn-shuffle');
    if (shuffleBtn) shuffleBtn.classList.toggle('toggle-on', state.shuffle);
    const repeatBtn = wrap.querySelector('#btn-repeat');
    if (repeatBtn) repeatBtn.classList.toggle('toggle-on', state.repeat);

    const volumeIconEl = wrap.querySelector('.volume-group > .ico');
    if (volumeIconEl && volumeIconEl.dataset.ico !== volIcon) {
      volumeIconEl.outerHTML = icon(volIcon, '', `data-ico="${volIcon}"`);
    }
    const volumeFill = wrap.querySelector('.volume-fill');
    if (volumeFill) volumeFill.style.width = state.volume + '%';
    if (state.fullOpen) updateFullPlayer();
  }

  function enableSafeAudio(reason) {
    if (safeAudio) return false;
    safeAudio = true;
    try { localStorage.setItem('leaf-safe-audio', '1'); } catch (e) {  }
    fetch('/api/client-log', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event: 'safe-audio-enabled', reason }) }).catch(() => {});
    return true;
  }
  try {
    const aac = audioEl.canPlayType('audio/mp4; codecs="mp4a.40.2"');
    if (!aac) enableSafeAudio('canPlayType(aac) is empty');
  } catch (e) {  }
  audioEl.addEventListener('error', () => {
    const err = audioEl.error || {};
    fetch('/api/client-log', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event: 'audio-error', code: err.code, message: err.message, src: audioEl.src,
        canPlay: { aac: audioEl.canPlayType('audio/mp4; codecs="mp4a.40.2"'), mp3: audioEl.canPlayType('audio/mpeg'),
          opus: audioEl.canPlayType('audio/ogg; codecs="opus"') }, safeAudio }) }).catch(() => {});
    const tr = state.currentTrack;
    if ((err.code === 3 || err.code === 4) && tr && isServerTrack(tr) && enableSafeAudio('media error ' + err.code)) {
      audioEl.src = streamUrlFor(tr);
      audioEl.play().catch(() => {});
    }
  });
  audioEl.addEventListener('play', () => { state.isPlaying = true; updatePlayerBarOnly(); syncTrackRows(); });
  audioEl.addEventListener('pause', () => { state.isPlaying = false; updatePlayerBarOnly(); syncTrackRows(); });
  audioEl.addEventListener('timeupdate', () => {
    state.progress = audioEl.currentTime;
    updatePlayerBarOnly();
  });
  audioEl.addEventListener('loadedmetadata', () => {
    if (state.currentTrack && audioEl.duration && isFinite(audioEl.duration)) {
      state.currentTrack.duration = audioEl.duration;
    }
    updatePlayerBarOnly();
  });
  audioEl.addEventListener('ended', () => {
    if (state.repeat) { audioEl.currentTime = 0; audioEl.play(); return; }
    handleNext();
  });

  function queueForView() {
    if (state.view === 'search') return searchResults;
    if (state.view === 'liked') return likedList();
    if (state.view === 'artist') return artistTracks;
    if (state.view === 'playlist') {
      const pl = userPlaylists.find((p) => p.id === state.currentPlaylistId);
      return pl ? pl.trackIds.map((id) => allKnownTracks[id]).filter(Boolean) : [];
    }
    return tracks;
  }
  function playTrackById(id, queue, force) {
    if (!force && state.currentTrack && String(state.currentTrack.id) === String(id) && audioEl.src) {
      if (audioEl.paused) audioEl.play().catch(() => {  });
      else audioEl.pause();
      return;
    }
    const list = queue || queueForView();
    const idx = list.findIndex((tr) => tr.id === id);
    if (idx === -1) return;
    state.queue = list;
    state.queueIndex = idx;
    loadAndPlay(list[idx]);
  }
  function handleNext() {
    if (!state.queue || state.queue.length === 0) return;
    let idx;
    if (state.shuffle) idx = Math.floor(Math.random() * state.queue.length);
    else idx = (state.queueIndex + 1) % state.queue.length;
    state.queueIndex = idx;
    loadAndPlay(state.queue[idx]);
  }
  function handlePrev() {
    if (!state.queue || state.queue.length === 0) return;
    if (audioEl.currentTime > 3) { audioEl.currentTime = 0; return; }
    const idx = (state.queueIndex - 1 + state.queue.length) % state.queue.length;
    state.queueIndex = idx;
    loadAndPlay(state.queue[idx]);
  }
  function toggleLike(trackId) {
    let removed = false;
    let tr = null;
    if (state.likedTracks.has(trackId)) {
      tr = likedTracksData[trackId];
      state.likedTracks.delete(trackId);
      delete likedTracksData[trackId];
      removed = true;
    } else {
      tr = allKnownTracks[trackId]
        || (state.currentTrack && state.currentTrack.id === trackId ? state.currentTrack : null);
      if (!tr) return;
      state.likedTracks.add(trackId);
      tr = Object.assign({}, tr, { _ord: nextLikedOrd() });
      likedTracksData[trackId] = tr;
    }
    saveLikes();
    _justLiked = removed ? null : trackId;
    renderAll();
    if (serverMode && isServerTrack(tr || { id: trackId })) {
      const req = removed
        ? apiJson('/api/user/liked/' + encodeURIComponent(trackId), 'DELETE')
        : apiJson('/api/user/liked', 'POST', tr);
      req.catch(() => {
        if (removed) { state.likedTracks.add(trackId); if (tr) likedTracksData[trackId] = tr; }
        else { state.likedTracks.delete(trackId); delete likedTracksData[trackId]; }
        saveLikes(); renderAll();
      });
    }
  }

  const SEARCH_PAGE_SIZE = 50;
  const SEARCH_PAGE_STEP = 20;

  let _searchSeq = 0;
  async function performSearch(query, options) {
    options = options || {};
    query = (query || '').trim();
    state.searchQuery = query;
    const seq = ++_searchSeq;
    if (!query) {
      searchResults = []; state.searchLimit = SEARCH_PAGE_SIZE; state.searchHasMore = false;
      state.searchLoading = false; state.searchLoadingMore = false;
      renderAll();
      return;
    }
    if (!options.loadMore) state.searchLimit = SEARCH_PAGE_SIZE;
    if (options.loadMore) state.searchLoadingMore = true;
    else state.searchLoading = true;
    state.view = 'search';
    renderAll();
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&limit=${state.searchLimit}`);
      const data = await res.json();
      if (seq !== _searchSeq) return;
      searchResults = (data.tracks || []).filter(isPlayableTrack);
      registerTracks(searchResults);
      state.searchHasMore = searchResults.length >= state.searchLimit;
    } catch (e) {
      if (seq !== _searchSeq) return;
      searchResults = [];
      state.searchHasMore = false;
    }
    state.searchLoading = false;
    state.searchLoadingMore = false;
    state._animNext = !options.loadMore;
    renderAll();
  }

  function loadMoreSearchResults() {
    if (!state.searchQuery || state.searchLoadingMore) return;
    state.searchLimit += SEARCH_PAGE_STEP;
    performSearch(state.searchQuery, { loadMore: true });
  }

  async function loadHomeTracks() {
    state.homeStatus = 'loading';
    if (!tracks.length) renderAll();
    try {
      const res = await fetch('/api/home');
      if (!res.ok) throw new Error('http ' + res.status);
      const data = await res.json();
      const list = (data.tracks || []).filter(isPlayableTrack);
      if (list.length) { tracks = list; registerTracks(tracks); }
    } catch (e) {  }
    state.homeStatus = tracks.length ? 'ready' : 'error';
    state._animNext = true;
    renderAll();
  }

  const HEADPHONE_HINT = /headphone|headset|airpods|buds|earbud|bluetooth|беспровод|наушник|гарнитур/i;

  function getAudioOutputDevice() {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        return navigator.mediaDevices.enumerateDevices()
          .then(devices => {
            const outputs = devices.filter(d => d.kind === 'audiooutput' && d.label);
            if (outputs.length > 0) {
              const headphone = outputs.find(d => HEADPHONE_HINT.test(d.label));
              return headphone ? headphone.label : outputs[0].label;
            }

            const allOutputs = devices.filter(d => d.kind === 'audiooutput');
            if (allOutputs.length > 1) {
              return t('externalDeviceConnected');
            }
            return null;
          })
          .catch(() => null);
      }
      return Promise.resolve(null);
    } catch (e) {
      return Promise.resolve(null);
    }
  }

  async function loadTelemetry() {
    try {
      const res = await fetch('/api/telemetry/status');
      const data = await res.json();

      if (data.audioDevice && data.audioDevice !== 'Default Audio Device') {
        state.audioDevice = data.audioDevice;
      } else {
        const device = await getAudioOutputDevice();
        state.audioDevice = device || t('outputDeviceUnknown');
      }
    } catch (e) {
      state.audioDevice = t('outputDeviceUnknown');
    }
    renderAll();
  }

  let artistTracks = [];
  let artistTracksLoading = false;
  function openArtistPage(name) {
    if (!name) return;
    state.view = 'artist';
    state.currentArtistName = name;
    renderAll();
    loadArtistTracks(name);
  }
  async function loadArtistTracks(name) {
    artistTracksLoading = true;
    artistTracks = [];
    renderAll();
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(name)}&limit=30`);
      const data = await res.json();
      const playable = (data.tracks || []).filter(isPlayableTrack);
      artistTracks = playable.filter((tr) => tr.artist === name);
      if (!artistTracks.length) artistTracks = playable;
      registerTracks(artistTracks);
    } catch (e) { artistTracks = []; }
    artistTracksLoading = false;
    state._animNext = true;
    renderAll();
  }

  function loadUserPlaylists() {
    try {
      const raw = localStorage.getItem('leaf-user-playlists');
      if (raw) return JSON.parse(raw);
    } catch (e) {  }
    return [];
  }
  function saveUserPlaylists() {
    try { localStorage.setItem('leaf-user-playlists', JSON.stringify(userPlaylists)); } catch (e) {  }
  }
  let userPlaylists = loadUserPlaylists();

  function playlistCover(pl) {
    if (pl.trackIds && pl.trackIds.length) {
      const tr = allKnownTracks[pl.trackIds[0]];
      if (tr) return coverOf(tr);
    }
    return null;
  }
  let serverMode = false;
  const isLocalPlaylist = (pl) => String(pl.id).startsWith('up-');

  async function apiJson(url, method, body) {
    const res = await fetch(url, {
      method: method || 'GET',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) { const err = new Error('http ' + res.status); err.status = res.status; throw err; }
    return res.json();
  }

  async function migrateLegacyLibrary() {
    const legacyLikes = Object.values(likedTracksData).filter(isScTrack);
    const legacyPlaylists = userPlaylists.filter(isLocalPlaylist);
    if (!legacyLikes.length && !legacyPlaylists.length) return true;
    try {
      if (!localStorage.getItem('leaf-legacy-backup')) {
        localStorage.setItem('leaf-legacy-backup', JSON.stringify({ likes: likedTracksData, playlists: userPlaylists }));
      }
    } catch (e) {  }

    let ok = true;
    for (const tr of legacyLikes) {
      try { await apiJson('/api/user/liked', 'POST', tr); } catch (e) { ok = false; if (e.status === 401) return false; }
    }
    for (const lp of legacyPlaylists) {
      let serverId;
      try { serverId = (await apiJson('/api/user/playlists', 'POST', { name: lp.name })).id; }
      catch (e) { ok = false; if (e.status === 401) return false; continue; }
      for (const id of lp.trackIds || []) {
        let tr = allKnownTracks[id] || likedTracksData[id];
        if (!tr) { try { tr = await apiJson('/api/track-info?id=' + encodeURIComponent(id)); } catch (e) { tr = null; } }
        if (!tr) { ok = false; continue; }
        try { await apiJson(`/api/user/playlists/${serverId}/tracks`, 'POST', tr); } catch (e) { ok = false; }
      }
    }
    return ok;
  }

  async function syncLibrary() {
    let me;
    try { me = await apiJson('/api/me'); } catch (e) { serverMode = false; return; }
    serverMode = true;
    const who = String(me.login || me.id || 'user');
    state.user = { name: me.username || me.login || '', avatar: me.avatar_url || '' };
    try { localStorage.setItem('leaf-user', JSON.stringify(state.user)); } catch (e) {  }
    czSetAccountBg(me.background_url || '');

    let owner = null;
    try { owner = localStorage.getItem('leaf-cache-owner'); } catch (e) {  }
    const setOwner = () => { try { localStorage.setItem('leaf-cache-owner', who); } catch (e) {  } };
    if (owner && owner !== who) {
      likedTracksData = {}; state.likedTracks = new Set(); userPlaylists = [];
      recents = []; try { localStorage.removeItem('leaf-recent'); } catch (e) {  }
      setOwner();
    } else if (!owner) {
      if (await migrateLegacyLibrary()) setOwner();
    }

    try {
      const d = await apiJson('/api/user/liked?sort=added_desc');
      const map = {};
      const n = (d.tracks || []).length;
      (d.tracks || []).forEach((tr, i) => { map[tr.id] = Object.assign({}, tr, { _ord: n - i }); });
      likedTracksData = map;
      state.likedTracks = new Set(Object.keys(map));
      registerTracks(d.tracks);
      saveLikes();
    } catch (e) {  }

    try {
      const pls = (await apiJson('/api/user/playlists')).playlists || [];
      const loaded = await Promise.all(pls.map(async (p) => {
        try {
          const d = await apiJson(`/api/user/playlists/${p.id}/tracks?sort=added_desc`);
          return { p, tracks: d.tracks || [] };
        } catch (e) { return { p, tracks: null }; }
      }));
      userPlaylists = loaded.map(({ p, tracks }) => {
        const prev = userPlaylists.find((x) => x.id === p.id);
        if (tracks) registerTracks(tracks);
        return { id: String(p.id), name: p.name, trackIds: tracks ? tracks.map((t) => t.id) : (prev ? prev.trackIds : []) };
      });
      saveUserPlaylists();
    } catch (e) {  }
    renderAll();
  }

  async function createUserPlaylist(name) {
    name = (name || '').trim();
    if (!name) return;
    let pl;
    if (!serverMode) {
      try { await apiJson('/api/me'); serverMode = true; } catch (e) {  }
    }
    if (serverMode) {
      try {
        const r = await apiJson('/api/user/playlists', 'POST', { name });
        pl = { id: String(r.id), name: r.name || name, trackIds: [] };
      } catch (e) {
        alert(e.status === 402 || e.status === 403
          ? 'Достигнут лимит плейлистов на вашем тарифе'
          : 'Не удалось создать плейлист на сервере. Проверьте соединение.');
        return;
      }
    } else {
      pl = { id: 'up-' + Date.now() + '-' + Math.floor(Math.random() * 1000), name, trackIds: [] };
    }
    userPlaylists.unshift(pl);
    saveUserPlaylists();
    renderAll();
    return pl;
  }
  async function addTrackToPlaylist(playlistId, trackId) {
    const pl = userPlaylists.find((p) => p.id === playlistId);
    const tr = allKnownTracks[trackId];
    if (!pl || !tr) return;
    const prevIds = pl.trackIds.slice();
    pl.trackIds = pl.trackIds.filter((id) => id !== trackId);
    pl.trackIds.unshift(trackId);
    saveUserPlaylists();
    renderAll();
    if (serverMode && !isLocalPlaylist(pl)) {
      try { await apiJson(`/api/user/playlists/${pl.id}/tracks`, 'POST', tr); }
      catch (e) { pl.trackIds = prevIds; saveUserPlaylists(); renderAll(); }
    }
  }
  async function deleteUserPlaylist(id) {
    const pl = userPlaylists.find((p) => p.id === id);
    if (!pl) return;
    if (!confirm('Удалить плейлист «' + pl.name + '»? Это действие необратимо.')) return;
    if (serverMode && !isLocalPlaylist(pl)) {
      try { await apiJson('/api/user/playlists/' + encodeURIComponent(id), 'DELETE'); } catch (e) { return; }
    }
    userPlaylists = userPlaylists.filter((p) => p.id !== id);
    saveUserPlaylists();
    if (state.view === 'playlist' && state.currentPlaylistId === id) state.view = 'library';
    renderAll();
  }
  async function removeTrackFromPlaylist(plId, trackId) {
    const pl = userPlaylists.find((p) => p.id === plId);
    if (!pl) return;
    const prevIds = pl.trackIds.slice();
    pl.trackIds = pl.trackIds.filter((id) => id !== trackId);
    saveUserPlaylists();
    renderAll();
    if (serverMode && !isLocalPlaylist(pl)) {
      try { await apiJson('/api/user/playlists/' + encodeURIComponent(plId) + '/tracks/' + encodeURIComponent(trackId), 'DELETE'); }
      catch (e) { pl.trackIds = prevIds; saveUserPlaylists(); renderAll(); }
    }
  }
  document.addEventListener('click', (ev) => {
    const del = ev.target.closest && ev.target.closest('[data-del-playlist]');
    const rm = ev.target.closest && ev.target.closest('[data-rm-from-playlist]');
    if (!del && !rm) return;
    ev.stopPropagation(); ev.preventDefault();
    if (del) deleteUserPlaylist(del.getAttribute('data-del-playlist'));
    else removeTrackFromPlaylist(state.currentPlaylistId, rm.getAttribute('data-rm-from-playlist'));
  }, true);
  function openUserPlaylist(id) {
    state.view = 'playlist';
    state.currentPlaylistId = id;
    renderAll();
  }
  function openAddToPlaylist(trackId) {
    state.addToPlaylistTrackId = trackId;
    renderAll();
  }
  function closeAddToPlaylist() {
    state.addToPlaylistTrackId = null;
    renderAll();
  }
  function openCreatePlaylistModal() {
    state.createPlaylistOpen = true;
    renderAll();
  }
  function closeCreatePlaylistModal() {
    state.createPlaylistOpen = false;
    renderAll();
  }

  const root = document.getElementById('root');
  let _lastView = null;
  let _lastLang = null;
  let _lastViewKey = null;
  let _lastModalKey = '';
  let _lastSecs = null;
  let _lastSettingsHtml = null;
  let _lastAvatar = null;
  let _lastPlaylistsHtml = null;
  let recentView = recents.slice(0, 6);

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function filled(svg) { return svg.replace('<svg ', '<svg fill="currentColor" '); }
  function sec(key, html, cls, style) {
    return `<div data-sec="${key}"${cls ? ` class="${cls}"` : ''}${style ? ` style="${style}"` : ''}>${html}</div>`;
  }
  function modalKeyNow() {
    return [
      state.eqOpen ? 'eq' : '',
      state.settingsOpen ? 'settings' : '',
      state.createPlaylistOpen ? 'cp' : '',
      state.addToPlaylistTrackId ? 'atp' : '',
      state.fullOpen ? 'full' : '',
    ].filter(Boolean).join(':');
  }

  function patchView(viewRoot, html, switched, animate) {
    if (!viewRoot) return false;
    const tpl = document.createElement('template');
    tpl.innerHTML = html;
    const newPad = tpl.content.firstElementChild;
    const kids = newPad ? Array.from(newPad.children) : [];
    const secs = kids.map((k) => ({ key: k.getAttribute('data-sec') || '', html: k.outerHTML }));
    const sameShape = !switched && _lastSecs && _lastSecs.length === secs.length
      && secs.every((s, i) => s.key && s.key === _lastSecs[i].key);

    let changed = false;
    if (!sameShape) {
      viewRoot.innerHTML = html;
      changed = true;
    } else {
      const live = viewRoot.firstElementChild ? viewRoot.firstElementChild.children : [];
      secs.forEach((s, i) => {
        if (s.html === _lastSecs[i].html || !live[i]) return;
        const wasEmpty = /^<div[^>]*><\/div>$/.test(_lastSecs[i].html);
        if (!animate && !wasEmpty) kids[i].classList.add('static');
        live[i].replaceWith(kids[i]);
        changed = true;
      });
    }
    _lastSecs = secs;
    return changed;
  }

  function markLoadedImages() {
    root.querySelectorAll('img.cover-img:not(.loaded)').forEach((img) => {
      if (img.complete && img.naturalWidth) img.classList.add('loaded');
    });
  }

  function syncTrackRows() {
    const cur = state.currentTrack ? String(state.currentTrack.id) : null;
    root.querySelectorAll('.track-row').forEach((row) => {
      const id = row.getAttribute('data-play-track');
      const isCur = id === cur;
      row.classList.toggle('current', isCur);
      row.classList.toggle('playing', isCur && state.isPlaying);
      const btn = row.querySelector('.track-like-btn');
      if (btn) setLikedClass(btn, state.likedTracks.has(id), id);
    });
  }
  function setLikedClass(btn, liked, id) {
    const was = btn.classList.contains('liked');
    if (was === liked) return;
    btn.classList.toggle('liked', liked);
    if (liked && _justLiked === id) {
      btn.classList.remove('pop');
      void btn.offsetWidth;
      btn.classList.add('pop');
      btn.addEventListener('animationend', () => btn.classList.remove('pop'), { once: true });
    }
  }

  function afterViewPatch(viewSwitched) {
    syncTrackRows();
    markLoadedImages();
    const si = root.querySelector('#search-input');
    if (si) {
      if (document.activeElement !== si && si.value !== (state.searchQuery || '')) si.value = state.searchQuery || '';
      if (viewSwitched && (!document.activeElement || document.activeElement === document.body)) {
        si.focus();
        si.setSelectionRange(si.value.length, si.value.length);
      }
    }
  }

  function renderAll() {
    if (state._rendering) return;
    state._rendering = true;
    try {
      applyRootClasses();

      const modalKey = modalKeyNow();
      const viewKey = state.view
        + (state.view === 'artist' ? ':' + (state.currentArtistName || '') : '')
        + (state.view === 'playlist' ? ':' + (state.currentPlaylistId || '') : '');
      const langChanged = _lastLang !== null && _lastLang !== state.language;
      const fullRebuild = !root.querySelector('.app') || _lastView === null || langChanged;
      const viewSwitched = _lastViewKey !== viewKey;
      _lastView = state.view;
      _lastViewKey = viewKey;
      const animate = state._animNext;
      state._animNext = false;

      if (viewSwitched && state.view === 'home') recentView = recents.slice(0, 6);

      let keepPanelTop = null;
      if (fullRebuild) {
        const oldScroller = root.querySelector('.content-scroll');
        const keepTop = oldScroller ? oldScroller.scrollTop : 0;
        const oldPanel = root.querySelector('.side-panel-inner');
        if (oldPanel) keepPanelTop = oldPanel.scrollTop;
        const html = document.documentElement;
        if (langChanged) {
          html.classList.add('no-enter');
          requestAnimationFrame(() => requestAnimationFrame(() => html.classList.remove('no-enter')));
        }
        root.innerHTML = `
          <div class="app">
            <div class="app-body">
              ${renderSidebar()}
              <main class="main">
                ${renderTopbar()}
                <div class="content-scroll"><div id="view-root"></div></div>
              </main>
            </div>
            ${renderPlayerBar()}
            ${renderMobileNav()}
          </div>
        `;
        _lastSecs = null; _lastPlaylistsHtml = null; _lastAvatar = null; _pbTrackId = null;
        wireEvents();
        patchView(root.querySelector('#view-root'), renderView(), true, true);
        const newScroller = root.querySelector('.content-scroll');
        if (newScroller && !viewSwitched) newScroller.scrollTop = keepTop;
        updatePlayerBarOnly();
      } else {
        const scroller = root.querySelector('.content-scroll');
        const scrollTop = scroller ? scroller.scrollTop : 0;
        patchView(root.querySelector('#view-root'), renderView(), viewSwitched, animate);
        if (scroller) scroller.scrollTop = viewSwitched ? 0 : scrollTop;
        updatePlayerBarOnly();
      }

      updateSidebarActive();
      renderPlaylistList();
      updateTopbar();
      updateModals(fullRebuild ? '' : _lastModalKey);
      if (keepPanelTop !== null) {
        const newPanel = root.querySelector('.side-panel-inner');
        if (newPanel) newPanel.scrollTop = keepPanelTop;
      }
      _lastModalKey = modalKey;
      _lastLang = state.language;
      afterViewPatch(viewSwitched);
      if (state.eqOpen) drawEqCurve();
    } finally {
      state._rendering = false;
    }
  }

  function updateSidebarActive() {
    root.querySelectorAll('.nav-item').forEach((btn) => {
      btn.classList.toggle('active', state.view === btn.getAttribute('data-nav'));
    });
    root.querySelectorAll('.mobile-nav-item').forEach((btn) => {
      btn.classList.toggle('active', state.view === btn.getAttribute('data-nav'));
    });
    root.querySelectorAll('.desktop-nav [data-nav]').forEach((btn) => {
      btn.classList.toggle('active', state.view === btn.getAttribute('data-nav'));
    });
    root.querySelectorAll('[data-open-playlist].playlist-item').forEach((el) => {
      el.classList.toggle('active', state.view === 'playlist' && el.getAttribute('data-open-playlist') === state.currentPlaylistId);
    });
  }

  function userInitial() {
    const n = state.user && state.user.name ? String(state.user.name).trim() : '';
    return n ? n.charAt(0).toUpperCase() : '';
  }
  function userFirstName() {
    const n = state.user && state.user.name ? String(state.user.name).trim() : '';
    return n ? n.split(/\s+/)[0] : '';
  }

  function updateTopbar() {
    const mobileInput = root.querySelector('[data-mobile-search]');
    if (mobileInput && document.activeElement !== mobileInput) mobileInput.value = state.searchQuery || '';
    root.querySelectorAll('.style-pill [data-style]').forEach((b) => {
      b.classList.toggle('active', b.getAttribute('data-style') === state.style);
    });
    const av = root.querySelector('#avatar-badge');
    const ini = userInitial();
    const pic = state.user && state.user.avatar ? state.user.avatar : '';
    const key = pic || ini;
    if (av && _lastAvatar !== key) {
      _lastAvatar = key;
      av.innerHTML = pic
        ? `<img class="avatar-img" src="${esc(pic)}" alt="" />`
        : (ini ? esc(ini) : icon('user'));
    }
  }

  function removeWithAnim(el) {
    if (!el || el.classList.contains('leaving')) return;
    if (document.documentElement.classList.contains('no-enter')) { el.remove(); return; }
    el.classList.add('leaving');
    const done = () => { if (el.parentNode) el.remove(); };
    el.addEventListener('animationend', (e) => { if (e.target === el) done(); });
    setTimeout(done, el.id === 'modal-backdrop' ? 170 : 450);
  }
  function closeAllModals() {
    state.eqOpen = false;
    state.settingsOpen = false;
    state.createPlaylistOpen = false;
    state.addToPlaylistTrackId = null;
    state.fullOpen = false;
    renderAll();
  }
  const MODAL_KINDS = {
    eq: { sel: '.eq-panel', html: () => renderEqualizer(), wire: () => wireEqEvents() },
    settings: { sel: '.side-panel', html: () => { _lastDevice = state.audioDevice || ''; return renderSettings(); }, wire: () => wireSettingsEvents() },
    cp: { sel: '.mini-modal', html: () => renderCreatePlaylistModal(), wire: () => { wireCreatePlaylistEvents(); setTimeout(() => { const i = root.querySelector('#create-playlist-input'); if (i) i.focus(); }, 60); } },
    atp: { sel: '.mini-modal', html: () => renderAddToPlaylistModal(), wire: () => wireAddToPlaylistEvents() },
    full: { sel: '.fp', html: () => renderFullPlayer(), wire: () => wireFullPlayer() },
  };

  function updateModals(prevKey) {
    const curKey = modalKeyNow();
    document.documentElement.classList.toggle('modal-open', curKey !== '');
    const app = root.querySelector('.app');
    if (!app) return;

    if (prevKey === curKey) {
      if (state.settingsOpen) patchSettings();
      return;
    }

    const prev = new Set(prevKey ? prevKey.split(':') : []);
    const cur = new Set(curKey ? curKey.split(':') : []);
    const needBack = Array.from(cur).some((k) => k !== 'full');
    const back = root.querySelector('#modal-backdrop:not(.leaving)');
    if (needBack && !back) app.insertAdjacentHTML('beforeend', '<div class="backdrop" id="modal-backdrop"></div>');
    if (!needBack && back) removeWithAnim(back);

    prev.forEach((k) => { if (!cur.has(k)) removeWithAnim(root.querySelector(MODAL_KINDS[k].sel + ':not(.leaving)')); });
    cur.forEach((k) => {
      if (prev.has(k)) return;
      app.insertAdjacentHTML('beforeend', MODAL_KINDS[k].html());
      MODAL_KINDS[k].wire();
    });
  }

  function renderSidebar() {
    return `
      <aside class="sidebar">
        <div class="glass sidebar-logo">
          <div class="logo-badge"><img class="logo-img" src="images/Leaf.png" alt="" /></div>
          <div>
            <h1 class="sidebar-title font-display text-primary-c">${t('appName')}</h1>
            <p class="sidebar-subtitle text-muted-c">${t('tagline')}</p>
          </div>
        </div>
        <nav class="glass sidebar-nav">
          ${NAV_ITEMS.map((item) => `
            <button class="nav-item ${state.view === item.id ? 'active' : ''}" data-nav="${item.id}">
              <span class="nav-bar"></span>
              ${icon(item.icon, '', '', true)}
              <span>${t(item.key)}</span>
            </button>
          `).join('')}
        </nav>
        <div class="glass sidebar-playlists">
          <button class="create-playlist-btn" id="create-playlist-btn">
            <div class="dashed-box">${icon('plus')}</div>
            ${t('createPlaylist')}
          </button>
          <div class="playlist-list" id="playlist-list"></div>
        </div>
      </aside>
    `;
  }

  function renderTopbar() {
    return `
      <header class="topbar">
        <div class="glass topbar-inner">
          <div class="mobile-logo">
            <div class="logo-badge"><img class="logo-img" src="images/Leaf.png" alt="" /></div>
            <span class="font-display text-primary-c">${t('appName')}</span>
          </div>
          <div class="glass-subtle mobile-search">
            ${icon('search')}
            <input type="text" placeholder="${t('searchPlaceholder')}" data-mobile-search value="${esc(state.searchQuery)}" />
          </div>
          <div class="desktop-nav">
            <button class="icon-btn glass-subtle" data-nav="home" title="${t('navHome')}">${icon('home')}</button>
            <button class="icon-btn glass-subtle" data-nav="library" title="${t('navLibrary')}">${icon('library')}</button>
          </div>
          <div class="top-lyric" id="top-lyric"></div>
          <div class="right-actions">
            <button class="icon-btn glass-subtle" id="open-settings" title="${t('settings')}">${icon('settings')}</button>
            <div class="avatar-badge" id="avatar-badge"></div>
          </div>
        </div>
      </header>
    `;
  }

  function sectionHeader(iconName, title, subtitle) {
    return `
      <div class="section-header">
        <div class="glass-subtle section-icon">${icon(iconName)}</div>
        <div>
          <h2 class="font-display text-primary-c">${title}</h2>
          ${subtitle ? `<p>${subtitle}</p>` : ''}
        </div>
      </div>
    `;
  }

  function trackRowHtml(track, index, extra) {
    const id = esc(track.id);
    return `
      <div class="track-row" data-play-track="${id}" style="--i:${index}">
        <div class="track-index">
          <span class="idx-num">${index + 1}</span>
          <span class="idx-play">${filled(icon('play'))}</span>
          <span class="idx-pause">${filled(icon('pause'))}</span>
          <span class="eq-bars"><span></span><span></span><span></span><span></span></span>
        </div>
        <img class="track-cover cover-img" src="${esc(coverOf(track))}" alt="" loading="lazy" decoding="async" />
        <div class="track-meta">
          <p class="title truncate">${esc(track.title)}</p>
          <div class="artist-row">${sourceBadge(track)}<button class="artist-link" data-artist="${esc(track.artist)}">${esc(track.artist)}</button></div>
        </div>
        <span class="track-album">${esc(track.genre || '')}</span>
        <button class="track-add-btn" data-add-to-playlist="${id}" title="${t('addToPlaylist')}">${icon('plus')}</button>
        <button class="track-like-btn" data-like-track="${id}">${icon('heart')}</button>
        ${extra || ''}
        <span class="track-duration">${formatTime(track.duration)}</span>
      </div>
    `;
  }

  function sourceBadge(track) {
    const id = String(track.id);
    const f = /^yt_/.test(id) ? 'yt' : (/^ym_/.test(id) ? '' : 'sc');
    return f ? `<img class="track-src" src="images/${f}.png" alt="" title="${f === 'yt' ? 'YouTube Music' : 'SoundCloud'}" />` : '';
  }

  function skeletonRows(n) {
    return Array.from({ length: n }, () => `
      <div class="skeleton-row">
        <div class="sk sk-num"></div>
        <div class="sk sk-cover"></div>
        <div class="sk-lines"><div class="sk sk-line"></div><div class="sk sk-line short"></div></div>
        <div class="sk sk-dur"></div>
      </div>
    `).join('');
  }

  function renderView() {
    if (state.view === 'home') return renderHome();
    if (state.view === 'search') return renderSearch();
    if (state.view === 'library') return renderLibrary();
    if (state.view === 'liked') return renderLiked();
    if (state.view === 'artist') return renderArtistPage();
    if (state.view === 'playlist') return renderUserPlaylist();
    return renderHome();
  }

  function renderArtistPage() {
    const name = state.currentArtistName || '';
    const list = artistTracksLoading
      ? `<div>${skeletonRows(6)}</div>`
      : artistTracks.length === 0
        ? `<p class="empty-state">${t('noResults')}</p>`
        : artistTracks.map((track, i) => trackRowHtml(track, i)).join('');
    return `
      <div class="view-pad">
        ${sec('hero', `
          <div class="liked-hero">
            <div class="artist-photo glass" style="width:6rem;height:6rem;flex-shrink:0;">
              <img src="${DEFAULT_AVATAR}" alt="" />
            </div>
            <div>
              <p class="eyebrow">${t('tracksByArtist')}</p>
              <h1 class="font-display text-primary-c">${esc(name)}</h1>
              <p class="count">${artistTracksLoading ? '&nbsp;' : `${artistTracks.length} ${t('tracks')}`}</p>
            </div>
          </div>`, 'animate-fade-in-up')}
        ${sec('list', `<div class="glass tracklist">${list}</div>`, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function renderUserPlaylist() {
    const pl = userPlaylists.find((p) => p.id === state.currentPlaylistId);
    if (!pl) return `<div class="view-pad">${sec('empty', `<p class="empty-state">${t('noPlaylistsYet')}</p>`)}</div>`;
    const cover = playlistCover(pl);
    const plTracks = pl.trackIds.map((id) => allKnownTracks[id]).filter(isPlayableTrack);
    const rm = (track) => `<button class="track-add-btn" data-rm-from-playlist="${esc(track.id)}" title="${t('removeFromPlaylist')}">${icon('x')}</button>`;
    return `
      <div class="view-pad">
        ${sec('hero', `
          <div class="liked-hero">
            <div class="artist-photo glass" style="width:6rem;height:6rem;border-radius:0.75rem;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#52525b,#18181b);color:rgba(255,255,255,.75);">
              ${cover ? `<img class="cover-img" src="${esc(cover)}" alt="" />` : icon('music', 'big')}
            </div>
            <div style="min-width:0;flex:1;">
              <p class="eyebrow">${t('playlistWord')}</p>
              <h1 class="font-display text-primary-c truncate">${esc(pl.name)}</h1>
              <p class="count">${plTracks.length} ${t('tracks')}</p>
            </div>
            <button class="glass-subtle close-btn" data-del-playlist="${esc(pl.id)}" title="${t('deletePlaylist')}">${icon('trash')}</button>
          </div>`, 'animate-fade-in-up')}
        ${sec('list', `<div class="glass tracklist">${
          plTracks.length === 0
            ? `<p class="empty-state">${t('emptyPlaylist')}</p>`
            : plTracks.map((track, i) => trackRowHtml(track, i, rm(track))).join('')
        }</div>`, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function greetingKeyNow() {
    const h = new Date().getHours();
    if (h >= 5 && h < 12) return 'Morning';
    if (h >= 12 && h < 18) return 'Day';
    if (h >= 18 && h < 23) return 'Evening';
    return 'Night';
  }
  function greetingText() { return t('greeting' + greetingKeyNow()); }
  function todayLabel() {
    const loc = { ru: 'ru-RU', pl: 'pl-PL', en: 'en-US' }[state.language] || 'en-US';
    try { return new Date().toLocaleDateString(loc, { weekday: 'long', day: 'numeric', month: 'long' }); } catch (e) { return ''; }
  }

  function quickCardHtml(opts) {
    return `
      <button class="glass quick-card" ${opts.open}>
        <div class="quick-cover ${opts.liked ? 'liked' : ''}">
          ${opts.cover ? `<img class="cover-img" src="${esc(opts.cover)}" alt="" />` : icon(opts.icon, opts.liked ? 'solid' : '')}
        </div>
        <div class="quick-meta">
          <span class="name truncate text-primary-c">${esc(opts.name)}</span>
          <span class="sub truncate">${opts.count} ${t('tracks')}</span>
        </div>
        <span class="quick-play" data-play-collection="${esc(opts.collection)}">${filled(icon('play'))}</span>
      </button>
    `;
  }

  function renderHome() {
    const name = userFirstName();
    const hero = `
      <div class="hero">
        <p class="eyebrow">${esc(todayLabel())}</p>
        <h1 class="font-display text-primary-c">${esc(greetingText())}${name ? ', ' + esc(name) : ''}</h1>
      </div>`;

    const likedCount = likedList().filter(isPlayableTrack).length;
    let quick = '';
    if (likedCount || userPlaylists.length) {
      const cards = [];
      cards.push(quickCardHtml({ open: 'data-open-liked', liked: true, icon: 'heart', name: t('likedSongs'), count: likedCount, collection: 'liked', cover: LIKES_COVER }));
      userPlaylists.slice(0, 5).forEach((pl) => {
        cards.push(quickCardHtml({
          open: `data-open-playlist="${esc(pl.id)}"`, icon: 'music', name: pl.name,
          count: pl.trackIds.length, collection: pl.id, cover: playlistCover(pl),
        }));
      });
      quick = `<div class="quick-grid">${cards.join('')}</div>`;
    }

    let recent = '';
    if (recentView.length) {
      recent = sectionHeader('clock', t('recentlyPlayed'), t('recentSub')) + `
        <div class="recent-grid">
          ${recentView.map((tr) => `
            <button class="recent-card" data-play-recent="${esc(tr.id)}">
              <div class="recent-cover">
                <img class="cover-img" src="${esc(coverOf(tr))}" alt="" loading="lazy" decoding="async" />
                <span class="recent-play">${filled(icon('play'))}</span>
              </div>
              <p class="title truncate">${esc(tr.title)}</p>
              <p class="artist truncate">${esc(tr.artist)}</p>
            </button>
          `).join('')}
        </div>`;
    }

    let popular;
    if (!tracks.length && state.homeStatus === 'loading') {
      popular = `<div class="glass tracklist">${skeletonRows(8)}</div>`;
    } else if (!tracks.length) {
      popular = `<div class="glass tracklist"><p class="empty-state">${t('loadFailed')}<br><button class="glass-subtle retry-btn" data-retry-home>${t('retry')}</button></p></div>`;
    } else {
      const limit = state.homeExpanded ? tracks.length : Math.min(10, tracks.length);
      popular = `
        <div class="glass tracklist">${tracks.slice(0, limit).map((tr, i) => trackRowHtml(tr, i)).join('')}</div>
        ${tracks.length > 10 ? `<button class="show-more-btn glass-subtle" data-home-toggle>${state.homeExpanded ? t('showLess') : t('showAll')}</button>` : ''}`;
    }
    popular = sectionHeader('trendingUp', t('popularNow'), t('popularSub')) + popular;

    return `
      <div class="view-pad">
        ${sec('hero', hero, 'animate-fade-in-up')}
        ${sec('quick', quick, 'animate-fade-in-up', 'animation-delay:.06s')}
        ${sec('recent', recent, 'animate-fade-in-up', 'animation-delay:.12s')}
        ${sec('popular', popular, 'animate-fade-in-up', 'animation-delay:.18s')}
      </div>
    `;
  }

  function renderSearch() {
    let results;
    if (state.searchLoading && !searchResults.length) {
      results = `<div class="glass tracklist">${skeletonRows(8)}</div>`;
    } else if (searchResults.length) {
      results = `
        <h2 class="font-display text-primary-c results-title">${t('resultsFor')} «${esc(state.searchQuery)}»</h2>
        <div class="glass tracklist ${state.searchLoading ? 'list-loading' : ''}">${searchResults.map((track, i) => trackRowHtml(track, i)).join('')}</div>
        ${state.searchHasMore ? `
          <button class="show-more-btn glass-subtle" id="search-show-more" ${state.searchLoadingMore ? 'disabled' : ''}>
            ${state.searchLoadingMore ? t('loadingMore') : t('showMore')}
          </button>` : ''}`;
    } else if (state.searchQuery) {
      results = `<p class="empty-state">${t('noResults')}</p>`;
    } else {
      results = `<p class="empty-state">${t('searchHint')}</p>`;
    }
    return `
      <div class="view-pad">
        ${sec('head', `
          <h1 class="font-display text-primary-c page-title">${t('search')}</h1>
          <div class="glass search-box">
            ${icon('search')}
            <input type="text" id="search-input" placeholder="${t('searchPlaceholderFull')}" autocomplete="off" spellcheck="false" />
          </div>`, 'animate-fade-in-up')}
        ${sec('results', results, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function collectionCard(opts) {
    return `
      <button class="playlist-card glass" ${opts.open}>
        <div class="cover-wrap">
          ${opts.cover
            ? `<img class="cover-img" src="${esc(opts.cover)}" alt="" loading="lazy" decoding="async" />`
            : `<div class="cover-fallback ${opts.liked ? 'liked' : ''}">${icon(opts.icon, opts.liked ? 'solid' : '')}</div>`}
          <div class="grad"></div>
          <div class="info">
            <p class="name font-display truncate">${esc(opts.name)}</p>
            <p class="count">${opts.count} ${t('tracks')}</p>
          </div>
          <span class="play-fab" data-play-collection="${esc(opts.collection)}">${filled(icon('play'))}</span>
        </div>
      </button>
    `;
  }

  function renderLibrary() {
    const likedCount = likedList().filter(isPlayableTrack).length;
    const cards = [
      collectionCard({ open: 'data-open-liked', liked: true, icon: 'heart', name: t('likedSongs'), count: likedCount, collection: 'liked', cover: LIKES_COVER }),
      ...userPlaylists.map((pl) => collectionCard({
        open: `data-open-playlist="${esc(pl.id)}"`, icon: 'music', name: pl.name,
        count: pl.trackIds.length, collection: pl.id, cover: playlistCover(pl),
      })),
      `<button class="playlist-card create-card" data-create-playlist>${icon('plus')}<span>${t('createPlaylist')}</span></button>`,
    ];
    return `
      <div class="view-pad">
        ${sec('head', `<h1 class="font-display text-primary-c page-title" style="margin:0;">${t('yourLibrary')}</h1>`, 'animate-fade-in-up')}
        ${sec('grid', `<div class="card-grid">${cards.join('')}</div>`, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function renderLiked() {
    const liked = likedList().filter(isPlayableTrack);
    return `
      <div class="view-pad">
        ${sec('hero', `
          <div class="liked-hero">
            <div class="icon-box"><img class="cover-img" src="${LIKES_COVER}" alt="" /></div>
            <div>
              <p class="eyebrow">${t('playlistWord')}</p>
              <h1 class="font-display text-primary-c">${t('likedSongs')}</h1>
              <p class="count">${liked.length} ${t('tracks')}</p>
            </div>
          </div>`, 'animate-fade-in-up')}
        ${sec('list', `<div class="glass tracklist">${
          liked.length === 0
            ? `<p class="empty-state">${t('noLiked')}</p>`
            : liked.map((track, i) => trackRowHtml(track, i)).join('')
        }</div>`, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function renderPlayerBar() {
    const track = state.currentTrack;
    return `
      <div class="player-wrap">
        <div class="player-inner">

          <div class="cloud-player player-bar animate-fade-in-up">
            <div class="player-row">
              <div class="now-playing">
                <img src="${esc(track ? coverOf(track) : DEFAULT_TRACK_COVER)}" alt="" />
                <div class="meta">
                  <p class="title text-primary-c truncate">${track ? esc(track.title) : t('nothingPlaying')}</p>
                  ${track
                    ? `<div class="artist-row">${sourceBadge(track)}<button class="artist truncate artist-link" data-artist="${esc(track.artist)}">${esc(track.artist)}</button></div>`
                    : `<p class="artist truncate">—</p>`}
                </div>
                <button class="like-btn" id="player-like">${icon('heart')}</button>
              </div>

              <div class="player-center">
                <div class="transport">
                  <button class="shuffle-btn" id="btn-shuffle">${icon('shuffle')}</button>
                  <button id="btn-prev">${filled(icon('skipBack'))}</button>
                  <button class="play-btn" id="btn-playpause">${filled(icon('play'))}</button>
                  <button id="btn-next">${filled(icon('skipForward'))}</button>
                  <button class="repeat-btn" id="btn-repeat">${icon('repeat')}</button>
                </div>
                <div class="seek-row">
                  <span class="seek-time start">0:00</span>
                  <div class="seek-track" id="seek-track">
                    <div class="track-bg"><div class="track-fill"><span class="thumb"></span></div></div>
                  </div>
                  <span class="seek-time end">0:00</span>
                </div>
              </div>

              <div class="player-right">
                <button id="open-eq" title="${t('equalizerTitle')}">${icon('sliders')}</button>
                <div class="volume-group">
                  ${icon('volume2')}
                  <div class="volume-track" id="volume-track">
                    <div class="volume-bg"><div class="volume-fill"><span class="volume-thumb"></span></div></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderMobileNav() {
    return `
      <nav class="mobile-nav">
        <div class="glass mobile-nav-inner">
          ${NAV_ITEMS.map((item) => `
            <button class="mobile-nav-item ${state.view === item.id ? 'active' : ''}" data-nav="${item.id}">
              ${icon(item.icon, '', '', true)}
              <span>${t(item.key)}</span>
            </button>
          `).join('')}
        </div>
      </nav>
    `;
  }

  function toggleHtml(id, on) {
    return `<button class="toggle ${on ? 'on' : ''}" id="${id}"><span class="knob"></span></button>`;
  }

  function renderSettingsInner() {
    const colorThemeLabelKey = { green: 'themeGreen', blue: 'themeBlue', white: 'themeWhite', red: 'themeRed', purple: 'themePurple' };
    return `
        <div class="glass-strong side-panel-inner">
          <div class="panel-header">
            <div class="left">
              <div class="glass-subtle icon-box">${icon('sparkles')}</div>
              <div>
                <h2 class="font-display text-primary-c">${t('settings')}</h2>
                <p>${t('personalize')}</p>
              </div>
            </div>
            <button class="glass-subtle close-btn" id="close-settings">${icon('x')}</button>
          </div>

          <div class="settings-group">
            <p class="group-label">${t('appearance')}</p>
            <div class="glass-subtle settings-card">
              <div class="setting-row">
                <div class="row-icon">${icon(state.style === 'dark' ? 'moon' : 'sun')}</div>
                <div class="row-text">
                  <p class="label">${t('styleLabel')}</p>
                  <p class="desc">${state.style === 'dark' ? t('darkMode') : t('lightMode')}</p>
                </div>
                <div class="glass-subtle style-toggle-mini">
                  <button class="${state.style === 'light' ? 'active' : ''}" data-style="light">${icon('sun')} ${t('light')}</button>
                  <button class="${state.style === 'dark' ? 'active' : ''}" data-style="dark">${icon('moon')} ${t('dark')}</button>
                </div>
              </div>
              <div class="divider"></div>
              <div class="hr-block">
                <p class="label" style="font-size:.875rem;font-weight:500;margin:0 0 .25rem;color:var(--text-primary);">${t('colorTheme')}</p>
                <div class="color-swatches">
                  ${COLOR_THEMES.map((c) => `
                    <button class="swatch swatch-${c} ${state.colorTheme === c ? 'selected' : ''}" data-color-theme="${c}" title="${t(colorThemeLabelKey[c])}"></button>
                  `).join('')}
                </div>
              </div>
              <div class="divider"></div>
              <div class="hr-block">
                <div class="setting-row" style="padding:0 0 .5rem;">
                  <div class="row-icon">${icon('globe')}</div>
                  <div class="row-text"><p class="label">${t('language')}</p></div>
                </div>
                <div class="lang-options" style="padding-top:0;">
                  ${[['ru', 'langRu'], ['pl', 'langPl'], ['en', 'langEn']].map(([code, key]) => `
                    <button class="lang-option ${state.language === code ? 'active' : ''}" data-lang="${code}">
                      <span>${t(key)}</span>
                      <span class="check">${icon('check')}</span>
                    </button>
                  `).join('')}
                </div>
              </div>
            </div>
          </div>

          ${renderCustomizeBlock()}

          <div class="settings-group">
            <p class="group-label">${t('devices')}</p>
            <div class="glass-subtle settings-card">
              <div class="setting-row">
                <div class="row-icon">${icon('headphones')}</div>
                <div class="row-text">
                  <p class="label">${t('outputDevice')}</p>
                  <p class="desc">${esc(state.audioDevice || t('outputDeviceUnknown'))}</p>
                </div>
                ${state.audioDevice ? `<span class="text-muted-c" style="font-size:.75rem;">${t('connected')}</span>` : ''}
              </div>
            </div>
          </div>

          <div class="glass-subtle about-card">
            ${icon('info')}
            <div>
              <p class="name text-primary-c">${t('about')}</p>
              <p class="ver">${t('version')}</p>
            </div>
          </div>
        </div>
    `;
  }
  function renderSettings() {
    return `<div class="side-panel">${renderSettingsInner()}</div>`;
  }
  let _lastDevice = null;
  function patchSettings() {
    const panel = root.querySelector('.side-panel:not(.leaving)');
    if (!panel) return;
    if (_lastDevice !== null && _lastDevice !== (state.audioDevice || '')) {
      const html = renderSettingsInner();
      const inner = panel.querySelector('.side-panel-inner');
      const st = inner ? inner.scrollTop : 0;
      if (inner) inner.outerHTML = html;
      const ni = panel.querySelector('.side-panel-inner');
      if (ni) ni.scrollTop = st;
    } else {
      panel.querySelectorAll('[data-color-theme]').forEach((el) => el.classList.toggle('selected', el.getAttribute('data-color-theme') === state.colorTheme));
      panel.querySelectorAll('[data-lang]').forEach((el) => el.classList.toggle('active', el.getAttribute('data-lang') === state.language));
      panel.querySelectorAll('[data-style]').forEach((el) => el.classList.toggle('active', el.getAttribute('data-style') === state.style));
      const row = panel.querySelector('.settings-card .setting-row');
      if (row) {
        const ic = row.querySelector('.row-icon');
        const want = state.style === 'dark' ? 'moon' : 'sun';
        if (ic && ic.dataset.ico !== want) { ic.dataset.ico = want; ic.innerHTML = icon(want); }
        const d = row.querySelector('.desc');
        const txt = state.style === 'dark' ? t('darkMode') : t('lightMode');
        if (d && d.textContent !== txt) d.textContent = txt;
      }
    }
    _lastDevice = state.audioDevice || '';
  }

  function fmtDb(v) { return (v > 0 ? '+' : '') + v; }
  function sliderHtml(attrs, cls, min, max, step, value) {
    const p = max > min ? (value - min) / (max - min) : 0;
    return `<div class="eq-slider ${cls}" ${attrs} data-min="${min}" data-max="${max}" data-step="${step}" data-value="${value}" style="--p:${p}" tabindex="0" role="slider" aria-valuemin="${min}" aria-valuemax="${max}" aria-valuenow="${value}"><div class="eq-slider-track"><div class="eq-slider-fill"></div><div class="eq-slider-thumb"></div></div></div>`;
  }
  function setSlider(el, v) {
    const min = Number(el.dataset.min), max = Number(el.dataset.max);
    v = Math.max(min, Math.min(max, v));
    el.dataset.value = String(v);
    el.style.setProperty('--p', String(max > min ? (v - min) / (max - min) : 0));
    el.setAttribute('aria-valuenow', String(v));
  }
  function markCustomPreset() {
    if (eqState.activePreset === 'Custom') return;
    eqState.activePreset = 'Custom';
    root.querySelectorAll('[data-eq-preset], [data-eq-user]').forEach((el) => el.classList.remove('active'));
  }
  function onEqSlide(el, v) {
    if (el.hasAttribute('data-eq-band')) {
      const i = Number(el.getAttribute('data-eq-band'));
      if (eqState.bands[i] === v) return;
      eqState.bands[i] = v;
      markCustomPreset();
      const lab = root.querySelector(`[data-eq-db="${i}"]`);
      if (lab) lab.textContent = fmtDb(v);
    } else if (el.id === 'eq-bass-boost') {
      if (eqState.bassBoost === v) return;
      eqState.bassBoost = v;
      const bv = root.querySelector('#eq-bass-val');
      if (bv) bv.textContent = `+${v} dB`;
    } else if (el.id === 'eq-reverb') {
      if (eqState.reverb === v) return;
      eqState.reverb = v;
      const rv = root.querySelector('#eq-reverb-val');
      if (rv) rv.textContent = `${v}%`;
    } else return;
    applyEqToGraph();
    scheduleEqCurve();
  }
  function slideTo(el, ev) {
    const track = el.querySelector('.eq-slider-track');
    const r = track.getBoundingClientRect();
    const vertical = el.classList.contains('vertical');
    const len = vertical ? r.height : r.width;
    if (!len) return;
    const raw = vertical ? (r.bottom - ev.clientY) / len : (ev.clientX - r.left) / len;
    const p = Math.max(0, Math.min(1, raw));
    const min = Number(el.dataset.min), max = Number(el.dataset.max), step = Number(el.dataset.step) || 1;
    let v = Math.round((min + p * (max - min)) / step) * step;
    v = Math.max(min, Math.min(max, Number(v.toFixed(2))));
    setSlider(el, v);
    el.style.setProperty('--p', String(p));
    onEqSlide(el, v);
  }
  let _eqCurveRaf = 0;
  function scheduleEqCurve() {
    if (_eqCurveRaf) return;
    _eqCurveRaf = requestAnimationFrame(() => { _eqCurveRaf = 0; drawEqCurve(); });
  }
  function eqPresetPillsHtml() {
    const builtin = Object.keys(EQ_PRESETS).map((p) => `
      <button class="preset-pill glass-subtle ${eqState.activePreset === p ? 'active' : ''}" data-eq-preset="${esc(p)}">${esc(p)}</button>
    `).join('');
    const names = Object.keys(eqCustom);
    const mine = names.length
      ? `<p class="lbl eq-mine">${t('myPresets')}</p><div class="preset-pills">${names.map((n) => `
          <div class="preset-user">
            <button class="preset-pill glass-subtle ${eqState.activePreset === 'u:' + n ? 'active' : ''}" data-eq-user="${esc(n)}">${esc(n)}</button>
            <button class="preset-del" data-eq-del="${esc(n)}" title="${t('deletePreset')}">${icon('x')}</button>
          </div>
        `).join('')}</div>`
      : '';
    return `<div class="preset-pills">${builtin}</div>${mine}`;
  }
  function refreshPresetArea() {
    const area = root.querySelector('#eq-preset-area');
    if (area) area.innerHTML = eqPresetPillsHtml();
  }

  function renderEqualizer() {
    return `
      <div class="eq-panel">
        <div class="glass-strong eq-panel-inner">
          <div class="panel-header">
            <div class="left">
              <div class="glass-subtle icon-box">${icon('sliders')}</div>
              <div>
                <h2 class="font-display text-primary-c">${t('equalizer')}</h2>
                <p>${t('shapeSound')}</p>
              </div>
            </div>
            <div style="display:flex; align-items:center; gap:.5rem;">
              <button class="glass-subtle reset-btn" id="eq-reset">${icon('rotateCcw')}</button>
              <button class="glass-subtle close-btn" id="close-eq">${icon('x')}</button>
            </div>
          </div>

          <div class="glass-subtle eq-enable-row">
            <span class="text-primary-c">${t('equalizer')}</span>
            ${toggleHtml('eq-enable-toggle', eqState.enabled)}
          </div>

          <div class="glass-subtle eq-canvas-wrap">
            <canvas id="eq-canvas"></canvas>
          </div>

          <div class="eq-bands ${eqState.enabled ? '' : 'disabled'}">
            ${EQ_BANDS.map((_, i) => `
              <div class="eq-band-col">
                <span class="eq-db" data-eq-db="${i}">${fmtDb(eqState.bands[i])}</span>
                ${sliderHtml(`data-eq-band="${i}"`, 'vertical', -12, 12, 0.5, eqState.bands[i])}
                <span>${EQ_BAND_LABELS[i]}</span>
              </div>
            `).join('')}
          </div>

          <div class="eq-presets">
            <p class="lbl">${t('presets')}</p>
            <div id="eq-preset-area">${eqPresetPillsHtml()}</div>
            <form class="eq-save" id="eq-save-form">
              <input type="text" id="eq-save-name" class="eq-save-input" placeholder="${t('presetNamePlaceholder')}" maxlength="24" autocomplete="off" />
              <button type="submit" class="eq-save-btn">${t('savePreset')}</button>
            </form>
          </div>

          <div class="eq-effects ${eqState.enabled ? '' : 'disabled'}">
            <div class="glass-subtle eq-effect-card">
              <div class="head"><span class="label text-primary-c">${t('bassBoost')}</span><span class="val" id="eq-bass-val">+${eqState.bassBoost} dB</span></div>
              ${sliderHtml('id="eq-bass-boost"', 'horizontal', 0, 12, 0.5, eqState.bassBoost)}
            </div>
            <div class="glass-subtle eq-effect-card">
              <div class="head"><span class="label text-primary-c">${t('reverb')}</span><span class="val" id="eq-reverb-val">${eqState.reverb}%</span></div>
              ${sliderHtml('id="eq-reverb"', 'horizontal', 0, 100, 1, eqState.reverb)}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function syncEqPanel() {
    const panel = root.querySelector('.eq-panel:not(.leaving)');
    if (!panel) return;
    panel.querySelectorAll('[data-eq-band]').forEach((el) => {
      setSlider(el, eqState.bands[Number(el.getAttribute('data-eq-band'))]);
    });
    panel.querySelectorAll('[data-eq-preset]').forEach((el) => {
      el.classList.toggle('active', el.getAttribute('data-eq-preset') === eqState.activePreset);
    });
    panel.querySelectorAll('[data-eq-user]').forEach((el) => {
      el.classList.toggle('active', 'u:' + el.getAttribute('data-eq-user') === eqState.activePreset);
    });
    panel.querySelectorAll('[data-eq-db]').forEach((el) => {
      el.textContent = fmtDb(eqState.bands[Number(el.getAttribute('data-eq-db'))]);
    });
    const tog = panel.querySelector('#eq-enable-toggle');
    if (tog) tog.classList.toggle('on', eqState.enabled);
    const bands = panel.querySelector('.eq-bands');
    if (bands) bands.classList.toggle('disabled', !eqState.enabled);
    const fx = panel.querySelector('.eq-effects');
    if (fx) fx.classList.toggle('disabled', !eqState.enabled);
    const bass = panel.querySelector('#eq-bass-boost');
    if (bass) setSlider(bass, eqState.bassBoost);
    const reverb = panel.querySelector('#eq-reverb');
    if (reverb) setSlider(reverb, eqState.reverb);
    const bv = panel.querySelector('#eq-bass-val'); if (bv) bv.textContent = `+${eqState.bassBoost} dB`;
    const rv = panel.querySelector('#eq-reverb-val'); if (rv) rv.textContent = `${eqState.reverb}%`;
    drawEqCurve();
  }

  function drawEqCurve() {
    const canvas = document.getElementById('eq-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = { width: canvas.clientWidth, height: canvas.clientHeight };
    const bw = Math.round(rect.width * dpr), bh = Math.round(rect.height * dpr);
    if (canvas.width !== bw || canvas.height !== bh) { canvas.width = bw; canvas.height = bh; }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const w = rect.width, h = rect.height;
    ctx.clearRect(0, 0, w, h);

    ctx.strokeStyle = 'rgba(148,163,184,0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (h / 4) * i;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(148,163,184,0.2)';
    ctx.beginPath(); ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2); ctx.stroke();

    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
    const bands = eqState.bands;

    function curvePath() {
      ctx.beginPath();
      bands.forEach((gain, i) => {
        const x = (w / (bands.length - 1)) * i;
        const y = h / 2 - (gain / 12) * (h / 2);
        if (i === 0) ctx.moveTo(x, y);
        else {
          const prevX = (w / (bands.length - 1)) * (i - 1);
          const prevGain = bands[i - 1];
          const prevY = h / 2 - (prevGain / 12) * (h / 2);
          const cpX = (prevX + x) / 2;
          ctx.bezierCurveTo(cpX, prevY, cpX, y, x, y);
        }
      });
    }

    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    bands.forEach((gain, i) => {
      const x = (w / (bands.length - 1)) * i;
      const y = h / 2 - (gain / 12) * (h / 2);
      if (i === 0) ctx.lineTo(x, y);
      else {
        const prevX = (w / (bands.length - 1)) * (i - 1);
        const prevGain = bands[i - 1];
        const prevY = h / 2 - (prevGain / 12) * (h / 2);
        const cpX = (prevX + x) / 2;
        ctx.bezierCurveTo(cpX, prevY, cpX, y, x, y);
      }
    });
    ctx.lineTo(w, h / 2);
    ctx.closePath();
    let a1 = accent + '40', a0 = accent + '00';
    if (accent.startsWith('rgb')) { a1 = accent; a0 = accent; }
    const gradient = ctx.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, hexAlpha(accent, 0.25));
    gradient.addColorStop(1, hexAlpha(accent, 0));
    ctx.fillStyle = gradient;
    ctx.fill();

    curvePath();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = accent;
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;

    bands.forEach((gain, i) => {
      const x = (w / (bands.length - 1)) * i;
      const y = h / 2 - (gain / 12) * (h / 2);
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = accent;
      ctx.fill();
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    });
  }
  function hexAlpha(color, alpha) {
    if (/^#([0-9a-f]{6})$/i.test(color)) {
      const num = parseInt(color.slice(1), 16);
      const r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
      return `rgba(${r},${g},${b},${alpha})`;
    }
    return color;
  }


  function wireEvents() {
    wireNavEvents();
    wireStyleEvents();
    wirePlayerEvents();
    wireViewEvents();
    wireSidebarEvents();
  }

  function wireNavEvents() {
    root.querySelectorAll('[data-nav]').forEach((el) => {
      el.addEventListener('click', () => { state.view = el.getAttribute('data-nav'); renderAll(); });
    });
    const mobileSearch = root.querySelector('[data-mobile-search]');
    if (mobileSearch) {
      mobileSearch.addEventListener('focus', () => { if (state.view !== 'search') { state.view = 'search'; renderAll(); } });
      mobileSearch.addEventListener('keydown', (e) => { if (e.key === 'Enter') performSearch(mobileSearch.value); });
    }
  }

  function wireStyleEvents() {
    root.querySelectorAll('.style-pill [data-style]').forEach((el) => {
      el.addEventListener('click', () => { const v = el.getAttribute('data-style'); if (v !== state.style) fadeThen(() => { state.style = v; saveSettings(); renderAll(); }); });
    });
  }

  function wireSidebarEvents() {
    const createPlaylistBtn = root.querySelector('#create-playlist-btn');
    if (createPlaylistBtn) createPlaylistBtn.addEventListener('click', openCreatePlaylistModal);
    const list = root.querySelector('#playlist-list');
    if (list) list.addEventListener('click', (e) => {
      const el = e.target.closest('[data-open-playlist]');
      if (el) openUserPlaylist(el.getAttribute('data-open-playlist'));
    });
  }

  function playCollection(id) {
    let list;
    if (id === 'liked') list = likedList().filter(isPlayableTrack);
    else {
      const pl = userPlaylists.find((p) => p.id === id);
      list = pl ? pl.trackIds.map((tid) => allKnownTracks[tid]).filter(isPlayableTrack) : [];
    }
    if (list.length) playTrackById(list[0].id, list, true);
  }

  function onViewClick(e) {
    const q = (sel) => e.target.closest(sel);
    let el;
    if ((el = q('[data-like-track]'))) { e.stopPropagation(); toggleLike(el.getAttribute('data-like-track')); return; }
    if ((el = q('[data-add-to-playlist]'))) { e.stopPropagation(); openAddToPlaylist(el.getAttribute('data-add-to-playlist')); return; }
    if ((el = q('[data-artist]'))) { e.stopPropagation(); openArtistPage(el.getAttribute('data-artist')); return; }
    if ((el = q('[data-play-collection]'))) { e.stopPropagation(); playCollection(el.getAttribute('data-play-collection')); return; }
    if ((el = q('[data-play-recent]'))) { playTrackById(el.getAttribute('data-play-recent'), recentView); return; }
    if (q('[data-open-liked]')) { state.view = 'liked'; renderAll(); return; }
    if ((el = q('[data-open-playlist]'))) { openUserPlaylist(el.getAttribute('data-open-playlist')); return; }
    if (q('[data-create-playlist]')) { openCreatePlaylistModal(); return; }
    if (q('[data-retry-home]')) { loadHomeTracks(); return; }
    if (q('[data-home-toggle]')) { state.homeExpanded = !state.homeExpanded; state._animNext = false; renderAll(); return; }
    if (q('#search-show-more')) { loadMoreSearchResults(); return; }
    if ((el = q('[data-play-track]'))) { playTrackById(el.getAttribute('data-play-track')); return; }
  }
  function onViewKeydown(e) {
    if (e.target && e.target.id === 'search-input' && e.key === 'Enter') performSearch(e.target.value);
  }
  function wireViewEvents() {
    const vr = root.querySelector('#view-root');
    if (!vr) return;
    vr.addEventListener('click', onViewClick);
    vr.addEventListener('keydown', onViewKeydown);
  }

  function dragSlider(el, onMove, onStart, onEnd) {
    el.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      if (onStart && onStart() === false) return;
      el.classList.add('dragging');
      onMove(e.clientX);
      const move = (ev) => onMove(ev.clientX);
      const up = (ev) => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        el.classList.remove('dragging');
        if (onEnd) onEnd(ev.clientX);
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
      e.preventDefault();
    });
  }

  function wirePlayerEvents() {
    const btnPlayPause = root.querySelector('#btn-playpause');
    if (btnPlayPause) btnPlayPause.addEventListener('click', () => {
      if (!state.currentTrack) return;
      ensureAudioGraph();
      if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
      if (audioEl.paused) audioEl.play().catch(() => {});
      else audioEl.pause();
    });
    const btnNext = root.querySelector('#btn-next');
    if (btnNext) btnNext.addEventListener('click', handleNext);
    const btnPrev = root.querySelector('#btn-prev');
    if (btnPrev) btnPrev.addEventListener('click', handlePrev);
    const btnShuffle = root.querySelector('#btn-shuffle');
    if (btnShuffle) btnShuffle.addEventListener('click', () => { state.shuffle = !state.shuffle; updatePlayerBarOnly(); });
    const btnRepeat = root.querySelector('#btn-repeat');
    if (btnRepeat) btnRepeat.addEventListener('click', () => { state.repeat = !state.repeat; updatePlayerBarOnly(); });
    const playerLike = root.querySelector('#player-like');
    if (playerLike) playerLike.addEventListener('click', () => { if (state.currentTrack) toggleLike(state.currentTrack.id); });

    const nowPlaying = root.querySelector('.now-playing');
    if (nowPlaying) nowPlaying.addEventListener('click', (e) => {
      const a = e.target.closest('[data-artist]');
      if (a) { openArtistPage(a.getAttribute('data-artist')); return; }
      if (state.currentTrack && e.target.closest('img, .title')) { state.fullOpen = true; renderAll(); }
    });

    const seekTrack = root.querySelector('#seek-track');
    if (seekTrack) {
      const pctFrom = (x) => { const r = seekTrack.getBoundingClientRect(); return Math.max(0, Math.min(1, (x - r.left) / r.width)); };
      const durNow = () => (audioEl.duration && isFinite(audioEl.duration) ? audioEl.duration : (state.currentTrack && state.currentTrack.duration) || 0);
      dragSlider(seekTrack,
        (x) => {
          const p = pctFrom(x);
          state._seeking = true; state._seekPct = p;
          const fill = seekTrack.querySelector('.track-fill');
          if (fill) fill.style.width = (p * 100) + '%';
          const st = root.querySelector('.seek-time.start');
          if (st) st.textContent = formatTime(p * durNow());
        },
        () => { if (!state.currentTrack || !durNow()) return false; },
        (x) => {
          const d = durNow();
          if (d) { audioEl.currentTime = pctFrom(x) * d; state.progress = audioEl.currentTime; }
          state._seeking = false;
          updatePlayerBarOnly();
        });
    }

    const volumeTrack = root.querySelector('#volume-track');
    if (volumeTrack) {
      dragSlider(volumeTrack, (x) => {
        const r = volumeTrack.getBoundingClientRect();
        const pct = Math.max(0, Math.min(1, (x - r.left) / r.width));
        state.volume = Math.round(pct * 100);
        audioEl.volume = state.volume / 100;
        updatePlayerBarOnly();
      });
      volumeTrack.addEventListener('touchstart', (e) => { if (e.touches[0]) setVolumeFromX(volumeTrack, e.touches[0].clientX); }, { passive: true });
      volumeTrack.addEventListener('touchmove', (e) => { if (e.touches[0]) setVolumeFromX(volumeTrack, e.touches[0].clientX); }, { passive: true });
    }

    const openEq = root.querySelector('#open-eq');
    if (openEq) openEq.addEventListener('click', () => { state.eqOpen = true; renderAll(); });
    const openSettings = root.querySelector('#open-settings');
    if (openSettings) openSettings.addEventListener('click', () => { state.settingsOpen = true; renderAll(); });
  }
  function setVolumeFromX(track, x) {
    const r = track.getBoundingClientRect();
    state.volume = Math.round(Math.max(0, Math.min(1, (x - r.left) / r.width)) * 100);
    audioEl.volume = state.volume / 100;
    updatePlayerBarOnly();
  }

  function wireEqEvents() {
    const panel = root.querySelector('.eq-panel:not(.leaving)');
    if (!panel) return;
    syncEqPanel();
    panel.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = panel.querySelector('#eq-save-name');
      const name = input ? input.value.trim().slice(0, 24) : '';
      if (!name) { if (input) input.focus(); return; }
      eqCustom[name] = { bands: [...eqState.bands], bass: eqState.bassBoost, reverb: eqState.reverb };
      saveEqCustom();
      eqState.activePreset = 'u:' + name;
      saveEqState();
      if (input) input.value = '';
      refreshPresetArea();
      syncEqPanel();
    });
    panel.addEventListener('pointerdown', (e) => {
      const el = e.target.closest('.eq-slider');
      if (!el || (e.button !== undefined && e.button > 0)) return;
      e.preventDefault();
      try { el.setPointerCapture(e.pointerId); } catch (err) {  }
      el.classList.add('dragging');
      el.focus({ preventScroll: true });
      slideTo(el, e);
      const move = (ev) => slideTo(el, ev);
      const up = () => {
        el.classList.remove('dragging');
        el.removeEventListener('pointermove', move);
        el.removeEventListener('pointerup', up);
        el.removeEventListener('pointercancel', up);
        setSlider(el, Number(el.dataset.value));
      };
      el.addEventListener('pointermove', move);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
    });
    panel.addEventListener('dblclick', (e) => {
      const el = e.target.closest('.eq-slider');
      if (!el) return;
      setSlider(el, 0);
      onEqSlide(el, 0);
    });
    panel.addEventListener('keydown', (e) => {
      const el = e.target.closest && e.target.closest('.eq-slider');
      if (!el) return;
      const step = Number(el.dataset.step) || 1;
      let d = 0;
      if (e.key === 'ArrowUp' || e.key === 'ArrowRight') d = step;
      else if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') d = -step;
      else return;
      e.preventDefault();
      const v = Math.max(Number(el.dataset.min), Math.min(Number(el.dataset.max), Number(el.dataset.value) + d));
      setSlider(el, v);
      onEqSlide(el, v);
    });
    panel.addEventListener('click', (e) => {
      const del = e.target.closest('[data-eq-del]');
      if (del) {
        const n = del.getAttribute('data-eq-del');
        delete eqCustom[n];
        if (eqState.activePreset === 'u:' + n) eqState.activePreset = 'Custom';
        saveEqCustom(); saveEqState();
        refreshPresetArea(); syncEqPanel();
        return;
      }
      const user = e.target.closest('[data-eq-user]');
      if (user) {
        const n = user.getAttribute('data-eq-user');
        const p = eqCustom[n];
        if (p && Array.isArray(p.bands)) {
          eqState.bands = p.bands.map((v) => Number(v) || 0);
          eqState.bassBoost = Number(p.bass) || 0;
          eqState.reverb = Number(p.reverb) || 0;
          eqState.activePreset = 'u:' + n;
          applyEqToGraph(); syncEqPanel();
        }
        return;
      }
      const preset = e.target.closest('[data-eq-preset]');
      if (preset) {
        const p = preset.getAttribute('data-eq-preset');
        eqState.bands = [...EQ_PRESETS[p]];
        eqState.activePreset = p;
        applyEqToGraph(); syncEqPanel();
        return;
      }
      if (e.target.closest('#eq-reset')) {
        eqState.bands = [...EQ_PRESETS.Flat]; eqState.activePreset = 'Flat'; eqState.bassBoost = 0; eqState.reverb = 0;
        applyEqToGraph(); syncEqPanel();
        return;
      }
      if (e.target.closest('#eq-enable-toggle')) {
        eqState.enabled = !eqState.enabled;
        applyEqToGraph(); syncEqPanel();
        return;
      }
      if (e.target.closest('#close-eq')) { state.eqOpen = false; renderAll(); }
    });
  }

  function wireSettingsEvents() {
    const panel = root.querySelector('.side-panel:not(.leaving)');
    if (!panel) return;
    wireCustomizeEvents(panel);
    panel.addEventListener('click', (e) => {
      let el;
      if ((el = e.target.closest('[data-color-theme]'))) { const v = el.getAttribute('data-color-theme'); if (v !== state.colorTheme || cz.accent) fadeThen(() => { state.colorTheme = v; czClearAccent(); saveSettings(); renderAll(); }); return; }
      if ((el = e.target.closest('[data-lang]'))) { const v = el.getAttribute('data-lang'); if (v !== state.language) fadeThen(() => { state.language = v; saveSettings(); renderAll(); }); return; }
      if ((el = e.target.closest('[data-style]'))) { const v = el.getAttribute('data-style'); if (v !== state.style) fadeThen(() => { state.style = v; saveSettings(); renderAll(); }); return; }
      if (e.target.closest('#close-settings')) { state.settingsOpen = false; renderAll(); }
    });
  }

  function wireCreatePlaylistEvents() {
    const modal = root.querySelector('.mini-modal:not(.leaving)');
    if (!modal) return;
    const cpClose = modal.querySelector('#create-playlist-close');
    if (cpClose) cpClose.addEventListener('click', closeCreatePlaylistModal);
    const cpForm = modal.querySelector('#create-playlist-form');
    if (cpForm) cpForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = modal.querySelector('#create-playlist-input');
      const pl = await createUserPlaylist(input ? input.value : '');
      state.createPlaylistOpen = false;
      if (pl && state._pendingTrackForNewPlaylist) { addTrackToPlaylist(pl.id, state._pendingTrackForNewPlaylist); state._pendingTrackForNewPlaylist = null; }
      if (pl) openUserPlaylist(pl.id); else renderAll();
    });
  }

  function wireAddToPlaylistEvents() {
    const modal = root.querySelector('.mini-modal:not(.leaving)');
    if (!modal) return;
    const atpClose = modal.querySelector('#add-to-playlist-close');
    if (atpClose) atpClose.addEventListener('click', closeAddToPlaylist);
    modal.querySelectorAll('[data-atp-target]').forEach((el) => {
      el.addEventListener('click', () => { addTrackToPlaylist(el.getAttribute('data-atp-target'), state.addToPlaylistTrackId); state.addToPlaylistTrackId = null; renderAll(); });
    });
    const atpNewBtn = modal.querySelector('#add-to-playlist-new');
    if (atpNewBtn) atpNewBtn.addEventListener('click', () => {
      const pendingTrackId = state.addToPlaylistTrackId; state.addToPlaylistTrackId = null; state.createPlaylistOpen = true;
      state._pendingTrackForNewPlaylist = pendingTrackId; renderAll();
    });
  }

  function renderPlaylistList() {
    const listEl = document.getElementById('playlist-list');
    if (!listEl) return;
    if (!userPlaylists.length) {
      if (_lastPlaylistsHtml === 'empty') return;
      _lastPlaylistsHtml = 'empty';
      listEl.innerHTML = `<p class="empty-state" style="padding:.75rem 0;font-size:.8rem;">${t('noPlaylistsYet')}</p>`;
      return;
    }
    const html = userPlaylists.map((pl) => {
      const cover = playlistCover(pl);
      return `
        <button class="playlist-item" data-open-playlist="${esc(pl.id)}">
          ${cover ? `<img class="playlist-thumb" src="${esc(cover)}" alt="" />` : `<div class="playlist-thumb">${icon('music', '', '', true)}</div>`}
          <span class="truncate">${esc(pl.name)}</span>
        </button>
      `;
    }).join('');
    if (html === _lastPlaylistsHtml) return;
    _lastPlaylistsHtml = html;
    listEl.innerHTML = html;
    updateSidebarActive();
  }

  function renderCreatePlaylistModal() {
    return `
      <div class="mini-modal">
        <div class="glass-strong mini-modal-inner">
          <div class="panel-header">
            <h2 class="font-display text-primary-c" style="font-size:1.1rem;">${t('createPlaylistTitle')}</h2>
            <button class="glass-subtle close-btn" id="create-playlist-close">${icon('x')}</button>
          </div>
          <form id="create-playlist-form">
            <input type="text" id="create-playlist-input" class="mini-modal-input" placeholder="${t('playlistNamePlaceholder')}" autocomplete="off" />
            <button type="submit" class="mini-modal-submit">${t('create')}</button>
          </form>
        </div>
      </div>
    `;
  }

  function renderAddToPlaylistModal() {
    return `
      <div class="mini-modal">
        <div class="glass-strong mini-modal-inner">
          <div class="panel-header">
            <h2 class="font-display text-primary-c" style="font-size:1.1rem;">${t('addToPlaylist')}</h2>
            <button class="glass-subtle close-btn" id="add-to-playlist-close">${icon('x')}</button>
          </div>
          <div class="atp-list">
            ${userPlaylists.length === 0 ? `<p class="empty-state" style="padding:1rem 0;">${t('noPlaylistsYet')}</p>` : userPlaylists.map((pl) => {
              const cover = playlistCover(pl);
              return `
                <button class="playlist-item" data-atp-target="${esc(pl.id)}">
                  ${cover ? `<img class="playlist-thumb" src="${esc(cover)}" alt="" />` : `<div class="playlist-thumb">${icon('music', '', '', true)}</div>`}
                  <span class="truncate">${esc(pl.name)}</span>
                </button>
              `;
            }).join('')}
          </div>
          <button class="mini-modal-submit" id="add-to-playlist-new" style="margin-top:.75rem;">${icon('plus')} ${t('newPlaylist')}</button>
        </div>
      </div>
    `;
  }


  let _fading = false;
  let _veilEl = null;
  function veilEl() {
    if (!_veilEl) {
      _veilEl = document.createElement('div');
      _veilEl.className = 'theme-veil';
      document.body.appendChild(_veilEl);
    }
    return _veilEl;
  }
  function fadeThen(fn) {
    if (_fading) { fn(); return; }
    _fading = true;
    const v = veilEl();
    v.classList.add('on');
    setTimeout(() => {
      try { fn(); } finally {
        requestAnimationFrame(() => requestAnimationFrame(() => {
          v.classList.remove('on');
          setTimeout(() => { _fading = false; }, 300);
        }));
      }
    }, 170);
  }

  const lyr = { key: null, lines: [], synced: false, active: -1, status: 'idle' };
  let _fpTrackId = null;
  let _fpBgToken = 0;

  const FP_SVG = {
    close: '<svg viewBox="0 0 16 16" fill="none"><path d="M3.5 6 8 10.5 12.5 6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    lyrics: '<svg viewBox="0 0 16 16" fill="none"><path d="M3 3.5h10M3 7h10M3 10.5h6.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
    vinyl: '<svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.2" stroke="currentColor" stroke-width="1.3"/><circle cx="8" cy="8" r="1.7" fill="currentColor"/></svg>',
  };

  function renderFullPlayer() {
    return `
      <div class="fp ${state.lyricsOpen ? 'lyrics-open' : ''}" id="full-player">
        <canvas class="fp-bg" id="fp-bg" width="128" height="128"></canvas>
        <div class="fp-shade"></div>
        <button class="fp-top fp-close" data-fp="close" title="${t('collapse')}">${FP_SVG.close}</button>
        <button class="fp-top fp-vinyl-toggle ${state.vinyl ? 'active' : ''}" data-fp="vinyl" title="${t('vinylView')}">${FP_SVG.vinyl}</button>
        <button class="fp-top fp-lyrics-toggle ${state.lyricsOpen ? 'active' : ''}" data-fp="lyrics" title="${t('lyricsTitle')}">${FP_SVG.lyrics}</button>

        <div class="fp-content">
          <div class="fp-art ${state.vinyl ? 'vinyl' : ''}" id="fp-art"><div class="fp-cover" id="fp-cover"></div></div>
          <div class="fp-title" id="fp-title"></div>
          <div class="fp-artist" id="fp-artist"></div>
          <div class="fp-timeline">
            <span class="fp-time" id="fp-cur">0:00</span>
            <div class="fp-progress" id="fp-progress"><div class="fp-fill" id="fp-fill"></div></div>
            <span class="fp-time" id="fp-tot">0:00</span>
          </div>
          <div class="fp-controls">
            <button class="fp-btn fp-mode" id="fp-repeat" data-fp="repeat">${icon('repeat')}</button>
            <button class="fp-btn" data-fp="prev">${icon('skipBack')}</button>
            <button class="fp-btn fp-play" id="fp-play" data-fp="play"></button>
            <button class="fp-btn" data-fp="next">${icon('skipForward')}</button>
            <button class="fp-btn fp-mode" id="fp-shuffle" data-fp="shuffle">${icon('shuffle')}</button>
          </div>
        </div>

        <div class="fp-lyrics">
          <div class="fp-lyrics-scroll" id="fp-lyr-scroll">
            <div class="fp-lyrics-state" id="fp-lyr-state"></div>
            <div class="fp-lyrics-lines" id="fp-lyr-lines"></div>
          </div>
        </div>
      </div>
    `;
  }

  function togglePlay() {
    if (!state.currentTrack) return;
    ensureAudioGraph();
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    if (audioEl.paused) audioEl.play().catch(() => {});
    else audioEl.pause();
  }

  function paintFpBg(src) {
    const cv = root.querySelector('#fp-bg');
    if (!cv) return;
    const token = ++_fpBgToken;
    const img = new Image();
    img.onload = () => {
      if (token !== _fpBgToken) return;
      try {
        const ctx = cv.getContext('2d');
        ctx.clearRect(0, 0, 128, 128);
        ctx.filter = 'blur(10px)';
        ctx.drawImage(img, -16, -16, 160, 160);
        ctx.filter = 'none';
        cv.classList.remove('fade');
        void cv.offsetWidth;
        cv.classList.add('fade');
      } catch (e) {  }
    };
    img.src = src;
  }

  function lyrMessage(text) {
    const st = root.querySelector('#fp-lyr-state');
    const ln = root.querySelector('#fp-lyr-lines');
    if (!st || !ln) return;
    ln.style.display = 'none'; ln.innerHTML = '';
    st.style.display = 'block'; st.textContent = text;
  }
  function lyrRender() {
    const st = root.querySelector('#fp-lyr-state');
    const ln = root.querySelector('#fp-lyr-lines');
    if (!st || !ln) return;
    st.style.display = 'none';
    ln.style.display = 'block';
    const first = lyr.synced ? lyr.lines.find((l) => typeof l.time === 'number') : null;
    const gap = first && first.time >= 5
      ? '<div class="fp-gap" id="fp-gap"><span class="fp-dots"><i></i><i></i><i></i></span><span class="fp-count"></span></div>'
      : '';
    ln.innerHTML = gap + lyr.lines
      .map((l, i) => `<div class="fp-line${lyr.synced ? ' synced' : ''}" data-i="${i}">${esc(l.text || '')}</div>`)
      .join('');
  }
  function updateGap(gap, now) {
    const first = lyr.lines.find((l) => typeof l.time === 'number');
    if (!first) return;
    const remain = first.time - now;
    const counting = remain > 0 && remain <= 3;
    gap.classList.toggle('counting', counting);
    if (!counting) return;
    const c = gap.querySelector('.fp-count');
    const n = String(Math.ceil(remain));
    if (c && c.textContent !== n) {
      c.textContent = n;
      c.classList.remove('pop');
      void c.offsetWidth;
      c.classList.add('pop');
    }
  }
  async function loadLyrics() {
    const tr = state.currentTrack;
    if (!tr) return;
    const key = String(tr.id);
    if (lyr.key === key) return;
    lyr.key = key; lyr.lines = []; lyr.synced = false; lyr.active = -1; lyr.status = 'loading';
    lyrMessage(t('lyricsLoading'));
    updateTopLyric();
    try {
      const params = new URLSearchParams({ title: tr.title || '', artist: tr.artist || '' });
      if (tr.duration) params.set('duration', String(Math.round(tr.duration)));
      const res = await fetch('/api/lyrics?' + params.toString());
      if (lyr.key !== key) return;
      const data = await res.json();
      if (lyr.key !== key) return;
      if (!data.found || !data.lines || !data.lines.length) { lyr.status = 'none'; lyrMessage(t('lyricsNotFound')); return; }
      lyr.lines = data.lines; lyr.synced = !!data.synced; lyr.status = 'found';
      lyrRender();
      if (lyr.synced) updateActiveLyric(true);
      updateTopLyric();
    } catch (e) {
      if (lyr.key === key) { lyr.status = 'none'; lyrMessage(t('lyricsNotFound')); }
    }
  }
  function syncLyricsPanel() {
    if (!root.querySelector('#fp-lyr-lines')) return;
    if (lyr.status === 'found') { lyrRender(); updateActiveLyric(true); }
    else if (lyr.status === 'none') lyrMessage(t('lyricsNotFound'));
    else if (lyr.status === 'loading') lyrMessage(t('lyricsLoading'));
    else loadLyrics();
  }
  function updateTopLyric() {
    const box = root.querySelector('#top-lyric');
    if (!box) return;
    let idx = -1;
    if (lyr.status === 'found' && lyr.synced && state.currentTrack) {
      const now = audioEl.currentTime || 0;
      for (let i = 0; i < lyr.lines.length; i++) {
        if (lyr.lines[i].time !== null && lyr.lines[i].time <= now) idx = i; else break;
      }
    }
    const tag = String(lyr.key) + ':' + idx;
    if (box.dataset.tag === tag) return;
    box.dataset.tag = tag;
    const text = idx >= 0 ? String(lyr.lines[idx].text || '').trim() : '';
    const prev = box.querySelector('.tl-line:not(.leave)');
    if (prev) {
      prev.classList.add('leave');
      prev.addEventListener('animationend', () => prev.remove(), { once: true });
      setTimeout(() => prev.remove(), 700);
    }
    if (text) {
      const el = document.createElement('span');
      el.className = 'tl-line enter';
      el.textContent = text;
      box.appendChild(el);
    }
  }
  function updateActiveLyric(force) {
    if (!state.lyricsOpen || !lyr.synced || !lyr.lines.length) return;
    const now = audioEl.currentTime || 0;
    let idx = -1;
    for (let i = 0; i < lyr.lines.length; i++) {
      if (lyr.lines[i].time !== null && lyr.lines[i].time <= now) idx = i; else break;
    }
    const gap = root.querySelector('#fp-gap');
    if (gap && idx === -1) updateGap(gap, now);
    if (idx === lyr.active && !force) return;
    lyr.active = idx;
    const nodes = root.querySelectorAll('#fp-lyr-lines .fp-line');
    nodes.forEach((n, i) => n.classList.toggle('active', i === idx));
    const scroll = root.querySelector('#fp-lyr-scroll');
    if (gap) {
      gap.classList.toggle('active', idx === -1);
      if (idx === -1 && scroll && scroll.scrollTo) {
        scroll.scrollTo({ top: gap.offsetTop - scroll.clientHeight / 2 + gap.offsetHeight / 2, behavior: 'smooth' });
      }
    }
    if (idx >= 0 && nodes[idx] && scroll) {
      if (scroll.scrollTo) scroll.scrollTo({ top: nodes[idx].offsetTop - scroll.clientHeight / 2 + nodes[idx].offsetHeight / 2, behavior: 'smooth' });
    }
  }

  function softSwap(fp) {
    ['#fp-art', '#fp-title', '#fp-artist'].forEach((s) => {
      const el = fp.querySelector(s);
      if (!el) return;
      el.classList.remove('swap');
      void el.offsetWidth;
      el.classList.add('swap');
    });
  }

  function updateFullPlayer() {
    const fp = root.querySelector('#full-player:not(.leaving)');
    if (!fp) return;
    const tr = state.currentTrack;
    const id = tr ? String(tr.id) : null;
    const prevId = _fpTrackId;
    const changed = id !== _fpTrackId;
    _fpTrackId = id;

    if (changed) {
      const cov = tr ? coverOf(tr) : DEFAULT_TRACK_COVER;
      fp.querySelector('#fp-title').textContent = tr ? tr.title : t('nothingPlaying');
      fp.querySelector('#fp-artist').innerHTML = tr ? `${sourceBadge(tr)}<span>${esc(tr.artist)}</span>` : '';
      fp.querySelector('#fp-cover').style.backgroundImage = `url("${cov}")`;
      paintFpBg(cov);
      syncLyricsPanel();
      if (prevId !== null) softSwap(fp);
    }

    const play = fp.querySelector('#fp-play');
    if (play) {
      const k = state.isPlaying ? 'pause' : 'play';
      if (play.dataset.ico !== k) { play.dataset.ico = k; play.innerHTML = icon(k); }
    }
    const cover = fp.querySelector('#fp-cover');
    if (cover) cover.classList.toggle('spinning', state.isPlaying);
    fp.querySelector('#fp-repeat').classList.toggle('on', state.repeat);
    fp.querySelector('#fp-shuffle').classList.toggle('on', state.shuffle);

    const dur = tr ? tr.duration : 0;
    const pct = dur ? Math.min(100, Math.max(0, (state.progress / dur) * 100)) : 0;
    if (!state._seeking) {
      const fill = fp.querySelector('#fp-fill');
      const w = pct.toFixed(1) + '%';
      if (fill && fill.style.width !== w) fill.style.width = w;
      const cur = fp.querySelector('#fp-cur'); const txt = formatTime(state.progress);
      if (cur && cur.textContent !== txt) cur.textContent = txt;
    }
    const tot = fp.querySelector('#fp-tot'); const tt = formatTime(dur);
    if (tot && tot.textContent !== tt) tot.textContent = tt;
    updateActiveLyric(false);
  }

  function wireFullPlayer() {
    const fp = root.querySelector('#full-player:not(.leaving)');
    if (!fp) return;
    fp.addEventListener('click', (e) => {
      const b = e.target.closest('[data-fp]');
      if (b) {
        const a = b.getAttribute('data-fp');
        if (a === 'close') { state.fullOpen = false; renderAll(); }
        else if (a === 'lyrics') {
          state.lyricsOpen = !state.lyricsOpen;
          fp.classList.toggle('lyrics-open', state.lyricsOpen);
          b.classList.toggle('active', state.lyricsOpen);
          if (state.lyricsOpen) syncLyricsPanel();
        } else if (a === 'vinyl') {
          state.vinyl = !state.vinyl;
          try { localStorage.setItem('leaf-vinyl', state.vinyl ? '1' : '0'); } catch (err) {  }
          fp.querySelector('#fp-art').classList.toggle('vinyl', state.vinyl);
          b.classList.toggle('active', state.vinyl);
        } else if (a === 'prev') handlePrev();
        else if (a === 'next') handleNext();
        else if (a === 'play') togglePlay();
        else if (a === 'shuffle') { state.shuffle = !state.shuffle; updatePlayerBarOnly(); }
        else if (a === 'repeat') { state.repeat = !state.repeat; updatePlayerBarOnly(); }
        return;
      }
      const line = e.target.closest('.fp-line.synced');
      if (line) {
        const l = lyr.lines[Number(line.getAttribute('data-i'))];
        if (l && typeof l.time === 'number') { audioEl.currentTime = l.time; if (audioEl.paused) audioEl.play().catch(() => {}); }
      }
    });

    const prog = fp.querySelector('#fp-progress');
    const pctFrom = (x) => { const r = prog.getBoundingClientRect(); return Math.max(0, Math.min(1, (x - r.left) / r.width)); };
    const durNow = () => (audioEl.duration && isFinite(audioEl.duration) ? audioEl.duration : (state.currentTrack && state.currentTrack.duration) || 0);
    dragSlider(prog,
      (x) => {
        const p = pctFrom(x);
        state._seeking = true;
        fp.querySelector('#fp-fill').style.width = (p * 100) + '%';
        fp.querySelector('#fp-cur').textContent = formatTime(p * durNow());
      },
      () => { if (!state.currentTrack || !durNow()) return false; },
      (x) => {
        const d = durNow();
        if (d) { audioEl.currentTime = pctFrom(x) * d; state.progress = audioEl.currentTime; }
        state._seeking = false;
        updatePlayerBarOnly();
      });

    _fpTrackId = null;
    updateFullPlayer();
  }

  document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'modal-backdrop') closeAllModals();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalKeyNow()) closeAllModals();
  });
  document.addEventListener('load', (e) => {
    const el = e.target;
    if (el && el.tagName === 'IMG') el.classList.add('loaded');
  }, true);
  document.addEventListener('error', (e) => {
    const el = e.target;
    if (!el || el.tagName !== 'IMG') return;
    if (el.classList.contains('avatar-img')) {
      if (state.user) state.user.avatar = '';
      _lastAvatar = null; updateTopbar();
      return;
    }
    if (!el.dataset.fb) { el.dataset.fb = '1'; el.src = DEFAULT_TRACK_COVER; }
    else el.classList.add('loaded');
  }, true);
  const _idle = (on) => document.documentElement.classList.toggle('window-idle', on);
  window.addEventListener('blur', () => _idle(true));
  window.addEventListener('focus', () => _idle(false));
  document.addEventListener('visibilitychange', () => _idle(document.hidden));

  /* ==========================================================================
     Кастомизация: фоны, свой акцент, эффекты (снег/дождь), библиотека тем.
     Хранение: localStorage 'leaf-custom' (настройки) и 'leaf-bg-image' (свой фон).
     Сервер (через локальный адаптер): GET /api/themes, POST /api/settings/theme,
     POST/DELETE /api/account/background, background_url из /api/me.
     ========================================================================== */
  const CZ_PRESETS = {
    aurora:   { name: 'Aurora',   css: 'radial-gradient(60% 55% at 18% 18%, rgba(34,211,238,.55), transparent 62%), radial-gradient(55% 60% at 82% 28%, rgba(168,85,247,.5), transparent 62%), radial-gradient(70% 60% at 50% 105%, rgba(34,197,94,.45), transparent 62%), #050d14' },
    sunset:   { name: 'Sunset',   css: 'radial-gradient(70% 60% at 80% 10%, rgba(251,113,133,.6), transparent 60%), radial-gradient(70% 70% at 10% 90%, rgba(251,146,60,.5), transparent 62%), #1a0b14' },
    ocean:    { name: 'Ocean',    css: 'linear-gradient(160deg, #0b3a5b 0%, #0a1f3a 55%, #050b18 100%)' },
    forest:   { name: 'Forest',   css: 'radial-gradient(70% 60% at 20% 15%, rgba(34,197,94,.45), transparent 62%), radial-gradient(60% 60% at 85% 85%, rgba(132,204,22,.3), transparent 62%), #06140c' },
    sakura:   { name: 'Sakura',   css: 'radial-gradient(60% 55% at 15% 20%, rgba(244,114,182,.5), transparent 62%), radial-gradient(60% 60% at 85% 80%, rgba(196,181,253,.55), transparent 62%), #fdf2f8' },
    frost:    { name: 'Frost',    css: 'linear-gradient(170deg, #1e3a5f 0%, #0f1f38 60%, #08111f 100%)' },
    midnight: { name: 'Midnight', css: 'radial-gradient(60% 60% at 75% 15%, rgba(99,102,241,.45), transparent 62%), radial-gradient(60% 60% at 15% 90%, rgba(168,85,247,.35), transparent 62%), #07070f' },
    graphite: { name: 'Graphite', css: 'linear-gradient(145deg, #2a2a2e 0%, #141416 60%, #0a0a0b 100%)' },
    paper:    { name: 'Paper',    css: 'linear-gradient(145deg, #fafaf9 0%, #e7e5e4 100%)' },
  };
  const CZ_LIBRARY = [
    { id: 'classic',  name: 'Leaf Classic', style: 'dark',  colorTheme: 'green',  accent: null,      bg: { type: 'none' },                      dim: 35, blur: 0, particles: 'none' },
    { id: 'aurora',   name: 'Aurora',       style: 'dark',  colorTheme: 'green',  accent: '#2dd4bf', bg: { type: 'preset', preset: 'aurora' },   dim: 25, blur: 0, particles: 'none' },
    { id: 'sunset',   name: 'Sunset',       style: 'dark',  colorTheme: 'red',    accent: '#fb7185', bg: { type: 'preset', preset: 'sunset' },   dim: 30, blur: 0, particles: 'none' },
    { id: 'ocean',    name: 'Ocean',        style: 'dark',  colorTheme: 'blue',   accent: null,      bg: { type: 'preset', preset: 'ocean' },    dim: 20, blur: 0, particles: 'none' },
    { id: 'forest',   name: 'Forest',       style: 'dark',  colorTheme: 'green',  accent: null,      bg: { type: 'preset', preset: 'forest' },   dim: 25, blur: 0, particles: 'none' },
    { id: 'winter',   name: 'Winter',       style: 'dark',  colorTheme: 'blue',   accent: '#93c5fd', bg: { type: 'preset', preset: 'frost' },    dim: 20, blur: 0, particles: 'snow' },
    { id: 'rainy',    name: 'Rainy Night',  style: 'dark',  colorTheme: 'purple', accent: null,      bg: { type: 'preset', preset: 'midnight' }, dim: 30, blur: 0, particles: 'rain' },
    { id: 'sakura',   name: 'Sakura',       style: 'light', colorTheme: 'red',    accent: '#ec4899', bg: { type: 'preset', preset: 'sakura' },   dim: 15, blur: 0, particles: 'none' },
    { id: 'mono',     name: 'Mono',         style: 'light', colorTheme: 'white',  accent: '#18181b', bg: { type: 'preset', preset: 'paper' },    dim: 0,  blur: 0, particles: 'none' },
  ];
  const CZ_FX = ['none', 'snow', 'rain'];
  const CZ_DEFAULT = { bg: { type: 'none', preset: 'aurora' }, dim: 35, blur: 0, accent: null, particles: 'none', themeId: null, syncBg: false, bgTouched: false };
  const czHex = (v) => (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v.trim()) ? v.trim().toLowerCase() : null);
  const czClamp = (v, a, b, d) => { v = Number(v); return Number.isFinite(v) ? Math.max(a, Math.min(b, Math.round(v))) : d; };

  function czLoad() {
    let o = null;
    try { o = JSON.parse(localStorage.getItem('leaf-custom') || 'null'); } catch (e) {  }
    o = o && typeof o === 'object' ? o : {};
    const bg = o.bg && typeof o.bg === 'object' ? o.bg : {};
    return {
      bg: {
        type: ['none', 'preset', 'image', 'account'].includes(bg.type) ? bg.type : 'none',
        preset: CZ_PRESETS[bg.preset] ? bg.preset : 'aurora',
      },
      dim: czClamp(o.dim, 0, 90, CZ_DEFAULT.dim),
      blur: czClamp(o.blur, 0, 30, 0),
      accent: czHex(o.accent),
      particles: CZ_FX.includes(o.particles) ? o.particles : 'none',
      themeId: typeof o.themeId === 'string' ? o.themeId : null,
      syncBg: o.syncBg === true,
      bgTouched: o.bgTouched === true,
    };
  }
  const cz = czLoad();
  let czImage = '';
  try { czImage = localStorage.getItem('leaf-bg-image') || ''; } catch (e) {  }
  let czAccountBg = '';
  let czServerThemes = [];
  let czServerState = 'idle';
  let czMsg = { text: '', kind: '' };
  let _czSaveTimer = null;
  function czSave() { try { localStorage.setItem('leaf-custom', JSON.stringify(cz)); } catch (e) {  } }
  function czSaveSoon() { clearTimeout(_czSaveTimer); _czSaveTimer = setTimeout(czSave, 250); }

  function czApplyAccent() {
    const s = document.documentElement.style;
    const hex = czHex(cz.accent);
    if (!hex) { ['--accent', '--accent-fg', '--accent-glow', '--accent-soft'].forEach((k) => s.removeProperty(k)); return; }
    const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    s.setProperty('--accent', hex);
    s.setProperty('--accent-fg', lum > 0.6 ? '#111111' : '#ffffff');
    s.setProperty('--accent-glow', 'rgba(' + r + ',' + g + ',' + b + ',.35)');
    s.setProperty('--accent-soft', 'rgba(' + r + ',' + g + ',' + b + ',.14)');
  }

  function czBgCss() {
    if (cz.bg.type === 'preset' && CZ_PRESETS[cz.bg.preset]) return CZ_PRESETS[cz.bg.preset].css;
    const u = cz.bg.type === 'image' ? czImage : cz.bg.type === 'account' ? czAccountBg : '';
    return u ? 'center / cover no-repeat url("' + u.replace(/"/g, '%22') + '")' : '';
  }
  function czApplyBgVars() {
    const el = document.getElementById('leaf-bg');
    if (!el) return;
    el.style.setProperty('--cz-dim', String(cz.dim / 100));
    el.style.setProperty('--cz-blur', cz.blur + 'px');
    el.classList.toggle('blurred', cz.blur > 0);
  }
  function czApplyBg() {
    const html = document.documentElement;
    let el = document.getElementById('leaf-bg');
    const css = czBgCss();
    if (!css) { if (el) el.remove(); html.classList.remove('has-bg'); return; }
    if (!el) {
      el = document.createElement('div');
      el.id = 'leaf-bg';
      el.innerHTML = '<div class="cz-layer"></div>';
      document.body.insertBefore(el, document.body.firstChild);
    }
    el.firstChild.style.background = css;
    html.classList.add('has-bg');
    czApplyBgVars();
  }

  let czFx = null;
  function czStopFx() {
    if (!czFx) return;
    czFx.stop();
    czFx = null;
  }
  function czApplyParticles() {
    const kind = cz.particles;
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (kind === 'none' || reduced) { czStopFx(); return; }
    if (czFx && czFx.kind === kind) return;
    czStopFx();
    const canvas = document.createElement('canvas');
    canvas.id = 'leaf-fx';
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d');
    let w = 0, h = 0;
    const resize = () => { w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);
    const n = kind === 'snow' ? 70 : 110;
    let flake = null;
    if (kind === 'snow') {
      const img = new Image();
      img.onload = () => {
        const make = (color) => {
          const c = document.createElement('canvas');
          c.width = c.height = 64;
          const g = c.getContext('2d');
          g.drawImage(img, 0, 0, 64, 64);
          if (color) { g.globalCompositeOperation = 'source-in'; g.fillStyle = color; g.fillRect(0, 0, 64, 64); }
          return c;
        };
        flake = { dark: make(null), light: make('rgb(110,140,185)') };
      };
      img.src = 'images/snow.png';
    }
    const ps = Array.from({ length: n }, () => ({
      x: Math.random() * w, y: Math.random() * h, ph: Math.random() * Math.PI * 2,
      a: Math.random() * Math.PI * 2, spin: (Math.random() - 0.5) * 0.03, o: 0.5 + Math.random() * 0.5,
      r: kind === 'snow' ? 1 + Math.random() * 2.2 : 0.8 + Math.random() * 0.8,
      v: kind === 'snow' ? 0.5 + Math.random() * 1.1 : 9 + Math.random() * 6,
      l: 8 + Math.random() * 10,
    }));
    let alive = true, last = 0, raf = 0, timer = 0;
    const tick = (ts) => {
      if (!alive) return;
      const cl = document.documentElement.classList;
      if (cl.contains('modal-open') || cl.contains('window-idle') || document.hidden) {
        timer = setTimeout(() => { raf = requestAnimationFrame(tick); }, 300);
        return;
      }
      raf = requestAnimationFrame(tick);
      const dt = Math.min(3, (ts - last) / 16.7 || 1);
      last = ts;
      ctx.clearRect(0, 0, w, h);
      const dark = cl.contains('dark');
      if (kind === 'snow') {
        const sprite = flake ? (dark ? flake.dark : flake.light) : null;
        if (sprite) {
          for (const p of ps) {
            p.y += p.v * dt; p.ph += 0.02 * dt; p.x += Math.sin(p.ph) * 0.6 * dt; p.a += p.spin * dt;
            if (p.y > h + 12) { p.y = -12; p.x = Math.random() * w; }
            const sz = p.r * 5;
            ctx.globalAlpha = p.o * (dark ? 0.9 : 0.8);
            ctx.setTransform(Math.cos(p.a), Math.sin(p.a), -Math.sin(p.a), Math.cos(p.a), p.x, p.y);
            ctx.drawImage(sprite, -sz / 2, -sz / 2, sz, sz);
          }
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.globalAlpha = 1;
        } else {
          ctx.fillStyle = dark ? 'rgba(255,255,255,.8)' : 'rgba(110,140,185,.7)';
          ctx.beginPath();
          for (const p of ps) {
            p.y += p.v * dt; p.ph += 0.02 * dt; p.x += Math.sin(p.ph) * 0.6 * dt;
            if (p.y > h + 4) { p.y = -4; p.x = Math.random() * w; }
            ctx.moveTo(p.x + p.r, p.y); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          }
          ctx.fill();
        }
      } else {
        ctx.strokeStyle = dark ? 'rgba(180,200,255,.38)' : 'rgba(70,100,150,.45)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (const p of ps) {
          p.y += p.v * dt; p.x -= 1.6 * dt;
          if (p.y > h + 12) { p.y = -12; p.x = Math.random() * w + 40; }
          ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + 1.6, p.y - p.l);
        }
        ctx.stroke();
      }
    };
    raf = requestAnimationFrame(tick);
    czFx = {
      kind,
      stop() { alive = false; cancelAnimationFrame(raf); clearTimeout(timer); window.removeEventListener('resize', resize); canvas.remove(); },
    };
  }

  function czApplyAll() { czApplyAccent(); czApplyBg(); czApplyParticles(); }
  function czInit() { czApplyAll(); }

  function czSetMsg(text, kind) {
    czMsg = { text: text || '', kind: kind || '' };
    const el = document.getElementById('cz-msg');
    if (el) { el.textContent = czMsg.text; el.className = 'cz-msg ' + czMsg.kind; }
  }
  function czClearAccent() {
    cz.accent = null; cz.themeId = null;
    czSave(); czApplyAccent(); czRefresh();
  }
  function czSetAccountBg(url) {
    czAccountBg = typeof url === 'string' && url.indexOf('/remote-static/') === 0 ? url : '';
    if (czAccountBg && cz.bg.type === 'none' && !cz.bgTouched) { cz.bg.type = 'account'; czSave(); }
    czApplyBg();
    czRefresh();
  }

  function czDownscale(file, max, q) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        try {
          const k = Math.min(1, max / Math.max(img.width, img.height));
          const c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(img.width * k));
          c.height = Math.max(1, Math.round(img.height * k));
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', q));
        } catch (e) { reject(e); } finally { URL.revokeObjectURL(url); }
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('image')); };
      img.src = url;
    });
  }
  async function czUploadAccountBg(blob, name) {
    if (blob.size > 10 * 1024 * 1024) { czSetMsg(t('czFileOver10'), 'err'); return; }
    const fd = new FormData();
    fd.append('file', blob, name || 'background');
    try {
      const res = await fetch('/api/account/background', { method: 'POST', body: fd });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error('http ' + res.status);
      if (d.background_url) czAccountBg = String(d.background_url) + '?v=' + Date.now();
      czSetMsg(t('czSynced'), 'ok');
    } catch (e) { czSetMsg(t('czSyncFail'), 'err'); }
  }
  async function czPickImage(file) {
    if (!file) return;
    if (!/^image\/(jpeg|png|gif|webp)$/.test(file.type)) { czSetMsg(t('czBadType'), 'err'); return; }
    let dataUrl;
    try { dataUrl = await czDownscale(file, 1920, 0.85); } catch (e) { czSetMsg(t('czUploadFail'), 'err'); return; }
    try { localStorage.setItem('leaf-bg-image', dataUrl); } catch (e) { czSetMsg(t('czImageTooBig'), 'err'); return; }
    czImage = dataUrl;
    cz.bg.type = 'image'; cz.bgTouched = true; cz.themeId = null;
    czSave(); czApplyBg(); czSetMsg('', ''); czRefresh();
    if (cz.syncBg) czUploadAccountBg(file, file.name);
  }
  async function czRemoveBg() {
    const wasType = cz.bg.type;
    const deleteRemote = wasType === 'account' || (wasType === 'image' && cz.syncBg);
    cz.bg.type = 'none'; cz.bgTouched = true; cz.themeId = null;
    czImage = '';
    try { localStorage.removeItem('leaf-bg-image'); } catch (e) {  }
    if (deleteRemote) {
      try { await fetch('/api/account/background', { method: 'DELETE' }); czAccountBg = ''; } catch (e) {  }
    }
    czSave(); czApplyBg(); czRefresh();
  }

  function czApplyLibrary(th) {
    fadeThen(() => {
      state.style = th.style;
      if (COLOR_THEMES.includes(th.colorTheme)) state.colorTheme = th.colorTheme;
      cz.accent = czHex(th.accent);
      cz.bg = { type: th.bg.type, preset: th.bg.preset || cz.bg.preset };
      cz.dim = th.dim; cz.blur = th.blur; cz.particles = th.particles;
      cz.themeId = 'local:' + th.id; cz.bgTouched = true;
      saveSettings(); czSave(); czApplyAll(); renderAll(); czRefresh();
    });
  }
  function czNormServerTheme(o) {
    if (!o || typeof o !== 'object') return null;
    const id = o.id !== undefined && o.id !== null ? o.id : (o.slug !== undefined ? o.slug : o.name);
    if (id === undefined || id === null || id === '') return null;
    const prev = String(o.preview_url || o.preview || o.preview_path || '');
    return {
      id: String(id),
      name: String(o.name || o.title || id),
      description: String(o.description || ''),
      accent: czHex(o.accent_color || o.accent),
      particles: CZ_FX.includes(o.particles_type) ? o.particles_type : 'none',
      tier: String(o.required_tier || ''),
      preview: prev.indexOf('/remote-static/') === 0 || prev.indexOf('data:image/') === 0 ? prev : '',
    };
  }
  async function czLoadServerThemes() {
    czServerState = 'loading'; czRefresh();
    try {
      const d = await apiJson('/api/themes');
      czServerThemes = (Array.isArray(d.themes) ? d.themes : []).map(czNormServerTheme).filter(Boolean);
      czServerState = 'ok';
    } catch (e) { czServerState = 'error'; }
    czRefresh();
  }
  async function czApplyServerTheme(id) {
    const th = czServerThemes.find((x) => x.id === id);
    if (!th) return;
    try {
      await apiJson('/api/settings/theme', 'POST', { theme: th.id, theme_color: th.accent || undefined });
    } catch (e) {
      czSetMsg(e.status === 402 || e.status === 403 ? t('czNeedTier') : e.status === 429 ? t('czRateLimited') : t('czThemeFail'), 'err');
      return;
    }
    fadeThen(() => {
      if (th.accent) cz.accent = th.accent;
      cz.particles = th.particles;
      cz.themeId = 'srv:' + th.id;
      czSave(); czApplyAll(); czRefresh();
      czSetMsg(t('czApplied'), 'ok');
    });
  }

  function czAccentNow() {
    const c = czHex(cz.accent);
    if (c) return c;
    const v = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
    return czHex(v) || '#22c55e';
  }
  function czTileBg(th) {
    if (th.bg && th.bg.type === 'preset' && CZ_PRESETS[th.bg.preset]) return CZ_PRESETS[th.bg.preset].css;
    return th.style === 'light' ? '#f8f8f8' : '#0c0c0c';
  }
  function renderCustomizeBlock() { return '<div id="cz-root">' + renderCustomizeInner() + '</div>'; }
  function renderCustomizeInner() {
    const sel = (c) => (c ? ' selected' : '');
    const presetTiles = Object.keys(CZ_PRESETS).map((id) =>
      '<button class="cz-tile' + sel(cz.bg.type === 'preset' && cz.bg.preset === id) + '" data-cz-preset="' + id + '">'
      + '<span class="cz-prev" style="background:' + esc(CZ_PRESETS[id].css) + '"></span><span class="cz-name">' + esc(CZ_PRESETS[id].name) + '</span></button>').join('');
    const hasBg = cz.bg.type !== 'none';
    const libTiles = CZ_LIBRARY.map((th) =>
      '<button class="cz-tile' + sel(cz.themeId === 'local:' + th.id) + '" data-cz-theme="' + th.id + '">'
      + '<span class="cz-prev" style="background:' + esc(czTileBg(th)) + '"><i class="cz-dot" style="background:' + esc(th.accent || ({ green: '#22c55e', blue: '#3b82f6', white: '#f2f2f2', red: '#ef4444', purple: '#a855f7' })[th.colorTheme]) + '"></i></span>'
      + '<span class="cz-name">' + esc(th.name) + '</span></button>').join('');
    let srv = '';
    if (czServerState === 'loading' || czServerState === 'idle') srv = '<p class="cz-note">' + t('czServerLoading') + '</p>';
    else if (czServerState === 'error') srv = '<p class="cz-note">' + t('czServerError') + ' <button class="cz-link" data-cz-retry>' + t('czRetry') + '</button></p>';
    else if (!czServerThemes.length) srv = '<p class="cz-note">' + t('czServerEmpty') + '</p>';
    else srv = '<div class="cz-grid">' + czServerThemes.map((th) =>
      '<button class="cz-tile' + sel(cz.themeId === 'srv:' + th.id) + '" data-cz-srv="' + esc(th.id) + '" title="' + esc(th.description) + '">'
      + '<span class="cz-prev"' + (th.preview ? ' style="background:center / cover no-repeat url(\'' + esc(th.preview) + '\')"' : ' style="background:' + esc(th.accent || '#27272a') + '"') + '>'
      + (th.accent ? '<i class="cz-dot" style="background:' + esc(th.accent) + '"></i>' : '') + (th.tier && th.tier !== 'free' ? '<b class="cz-tier">' + esc(th.tier) + '</b>' : '') + '</span>'
      + '<span class="cz-name">' + esc(th.name) + '</span></button>').join('') + '</div>';
    const fxBtn = (k, label) => '<button class="cz-chip' + sel(cz.particles === k) + '" data-cz-fx="' + k + '">' + label + '</button>';
    return `
          <div class="settings-group">
            <p class="group-label">${t('czBackground')}</p>
            <div class="glass-subtle settings-card cz-card">
              <div class="cz-grid">
                <button class="cz-tile${sel(cz.bg.type === 'none')}" data-cz-none><span class="cz-prev cz-prev-none"></span><span class="cz-name">${t('czNone')}</span></button>
                ${presetTiles}
                <button class="cz-tile${sel(cz.bg.type === 'image')}" data-cz-pick><span class="cz-prev cz-prev-add"${czImage ? ' style="background:center / cover no-repeat url(\'' + czImage.replace(/'/g, '%27') + '\')"' : ''}>${czImage ? '' : '+'}</span><span class="cz-name">${t('czCustomImage')}</span></button>
                ${czAccountBg ? '<button class="cz-tile' + sel(cz.bg.type === 'account') + '" data-cz-account><span class="cz-prev" style="background:center / cover no-repeat url(\'' + esc(czAccountBg) + '\')"></span><span class="cz-name">' + t('czAccountBg') + '</span></button>' : ''}
              </div>
              <input type="file" id="cz-file" accept="image/jpeg,image/png,image/gif,image/webp" hidden>
              <label class="cz-range-row"><span>${t('czDim')}</span><input type="range" class="cz-range" data-cz-range="dim" min="0" max="90" value="${cz.dim}"><b id="cz-dim-v">${cz.dim}%</b></label>
              <label class="cz-range-row"><span>${t('czBlur')}</span><input type="range" class="cz-range" data-cz-range="blur" min="0" max="30" value="${cz.blur}"><b id="cz-blur-v">${cz.blur}px</b></label>
              <label class="cz-check"><input type="checkbox" id="cz-sync" ${cz.syncBg ? 'checked' : ''}><span>${t('czSyncBg')}</span></label>
              ${hasBg ? '<button class="cz-link" data-cz-remove>' + t('czRemoveBg') + '</button>' : ''}
              <p id="cz-msg" class="cz-msg ${czMsg.kind}">${esc(czMsg.text)}</p>
            </div>
          </div>
          <div class="settings-group">
            <p class="group-label">${t('czAccent')}</p>
            <div class="glass-subtle settings-card cz-card">
              <div class="cz-accent-row">
                <input type="color" id="cz-accent" value="${czAccentNow()}">
                <span class="cz-hex" id="cz-accent-hex">${czAccentNow()}</span>
                ${cz.accent ? '<button class="cz-link" data-cz-accent-reset>' + t('czAccentReset') + '</button>' : ''}
              </div>
              <p class="group-label cz-sub">${t('czEffects')}</p>
              <div class="cz-chips">${fxBtn('none', t('czOff'))}${fxBtn('snow', t('czSnow'))}${fxBtn('rain', t('czRain'))}</div>
            </div>
          </div>
          <div class="settings-group">
            <p class="group-label">${t('czLibrary')}</p>
            <div class="glass-subtle settings-card cz-card">
              <p class="group-label cz-sub">${t('czLibraryLocal')}</p>
              <div class="cz-grid">${libTiles}</div>
              <p class="group-label cz-sub">${t('czLibraryServer')}</p>
              ${srv}
            </div>
          </div>
    `;
  }
  function czRefresh() {
    const host = document.getElementById('cz-root');
    if (!host) return;
    const sc = host.closest('.side-panel-inner');
    const top = sc ? sc.scrollTop : 0;
    host.innerHTML = renderCustomizeInner();
    if (sc) sc.scrollTop = top;
  }

  function wireCustomizeEvents(panel) {
    if (czServerState === 'idle') czLoadServerThemes();
    const setBg = (type, preset) => {
      cz.bg.type = type; if (preset) cz.bg.preset = preset;
      cz.bgTouched = true; cz.themeId = null;
      czSave(); czApplyBg(); czRefresh();
    };
    panel.addEventListener('click', (e) => {
      let el;
      if ((el = e.target.closest('[data-cz-none]'))) { setBg('none'); return; }
      if ((el = e.target.closest('[data-cz-preset]'))) { setBg('preset', el.getAttribute('data-cz-preset')); return; }
      if ((el = e.target.closest('[data-cz-account]'))) { setBg('account'); return; }
      if ((el = e.target.closest('[data-cz-pick]'))) {
        if (czImage && cz.bg.type !== 'image') { setBg('image'); return; }
        const f = panel.querySelector('#cz-file'); if (f) f.click();
        return;
      }
      if (e.target.closest('[data-cz-remove]')) { czRemoveBg(); return; }
      if (e.target.closest('[data-cz-accent-reset]')) { czClearAccent(); return; }
      if ((el = e.target.closest('[data-cz-fx]'))) {
        const k = el.getAttribute('data-cz-fx');
        if (CZ_FX.includes(k) && k !== cz.particles) { cz.particles = k; cz.themeId = null; czSave(); czApplyParticles(); czRefresh(); }
        return;
      }
      if ((el = e.target.closest('[data-cz-theme]'))) {
        const th = CZ_LIBRARY.find((x) => x.id === el.getAttribute('data-cz-theme'));
        if (th) czApplyLibrary(th);
        return;
      }
      if ((el = e.target.closest('[data-cz-srv]'))) { czApplyServerTheme(el.getAttribute('data-cz-srv')); return; }
      if (e.target.closest('[data-cz-retry]')) { czLoadServerThemes(); return; }
    });
    panel.addEventListener('input', (e) => {
      const r = e.target.closest('[data-cz-range]');
      if (r) {
        const key = r.getAttribute('data-cz-range');
        if (key === 'dim') { cz.dim = czClamp(r.value, 0, 90, 35); const v = document.getElementById('cz-dim-v'); if (v) v.textContent = cz.dim + '%'; }
        else { cz.blur = czClamp(r.value, 0, 30, 0); const v = document.getElementById('cz-blur-v'); if (v) v.textContent = cz.blur + 'px'; }
        cz.themeId = null; czApplyBgVars(); czSaveSoon();
        return;
      }
      if (e.target.id === 'cz-accent') {
        cz.accent = czHex(e.target.value); cz.themeId = null;
        const hx = document.getElementById('cz-accent-hex'); if (hx) hx.textContent = cz.accent || '';
        czApplyAccent(); czSaveSoon();
      }
    });
    panel.addEventListener('change', async (e) => {
      if (e.target.id === 'cz-file') {
        const f = e.target.files && e.target.files[0];
        e.target.value = '';
        await czPickImage(f);
        return;
      }
      if (e.target.id === 'cz-sync') {
        cz.syncBg = !!e.target.checked; czSave();
        if (cz.syncBg && cz.bg.type === 'image' && czImage) {
          try { const b = await (await fetch(czImage)).blob(); czUploadAccountBg(b, 'background.jpg'); } catch (err) {  }
        }
        return;
      }
      if (e.target.id === 'cz-accent') { czSave(); czRefresh(); }
    });
  }

  czInit();
  renderAll();
  loadHomeTracks();
  syncLibrary();
  let _lastSync = Date.now();
  window.addEventListener('focus', () => {
    if (state.homeStatus === 'error') loadHomeTracks();
    if (Date.now() - _lastSync < 30000) return;
    _lastSync = Date.now();
    syncLibrary();
  });
  loadTelemetry();
})();
