/* Плашка обновления, встроенная в окно плеера.
   Python (upd.py) шлёт события через window.__leafUpdOn(name, payload),
   а действия пользователя уходят в pywebview.api.upd_* (см. WebBridge в client.py). */
(function () {
  'use strict';

  var L = {
    ru: { title: 'Доступно обновление', size: 'Размер', mandatory: 'Обязательное',
          hintM: 'Без этого обновления продолжить нельзя', hintO: 'Можно обновиться сейчас или позже',
          go: 'Обновить', skip: 'Пропустить', cancel: 'Отмена', quit: 'Закрыть приложение', inst: 'Запускаем установщик…',
          retry: 'Повторить', fail: 'Ошибка', cancelled: 'Загрузка отменена' },
    en: { title: 'Update available', size: 'Size', mandatory: 'Required',
          hintM: "You can't continue without this update", hintO: 'Update now or later',
          go: 'Update', skip: 'Skip', cancel: 'Cancel', quit: 'Close the app', inst: 'Starting the installer…',
          retry: 'Retry', fail: 'Error', cancelled: 'Download cancelled' },
    pl: { title: 'Dostępna aktualizacja', size: 'Rozmiar', mandatory: 'Wymagana',
          hintM: 'Bez tej aktualizacji nie można kontynuować', hintO: 'Zaktualizuj teraz lub później',
          go: 'Aktualizuj', skip: 'Pomiń', cancel: 'Anuluj', quit: 'Zamknij aplikację', inst: 'Uruchamianie instalatora…',
          retry: 'Spróbuj ponownie', fail: 'Błąd', cancelled: 'Pobieranie anulowane' }
  };

  var T = L.ru, root = null, info = null, busy = false, q = null;

  function lang() {
    try {
      var s = JSON.parse(localStorage.getItem('leaf-settings') || '{}');
      if (L[s.language]) return s.language;
    } catch (e) {}
    return 'ru';
  }
  function api() { return window.pywebview && window.pywebview.api; }
  function call(name) {
    var a = api();
    if (!a || typeof a[name] !== 'function') return Promise.resolve('');
    try { return Promise.resolve(a[name]()); } catch (e) { return Promise.resolve(''); }
  }
  function mb(n) { return (n / 1048576).toFixed(n >= 104857600 ? 0 : 1) + ' MB'; }
  function $(sel) { return root.querySelector(sel); }
  function show(sel, on) { $(sel).classList.toggle('lupd-hidden', !on); }

  function build() {
    root = document.createElement('div');
    root.id = 'lupd-scrim';
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-modal', 'true');
    root.innerHTML =
      '<div class="lupd-card">' +
        '<div><h1 data-r="title"></h1>' +
          '<p class="lupd-ver"><span data-r="cur"></span><span class="lupd-sep">→</span><b data-r="new"></b></p></div>' +
        '<div class="lupd-txt lupd-hidden" data-r="msg"></div>' +
        '<div class="lupd-foot" data-r="foot"><span data-r="meta"></span><span data-r="hint"></span></div>' +
        '<div class="lupd-prog" data-r="prog">' +
          '<div class="lupd-prog-top"><div class="lupd-pct"><span data-r="pct">0</span><small>%</small></div><div data-r="speed"></div></div>' +
          '<div class="lupd-bar"><i data-r="bar"></i></div><div data-r="left"></div></div>' +
        '<div class="lupd-err" data-r="err"></div>' +
        '<div class="lupd-btns">' +
          '<button class="lupd-btn ghost lupd-hidden" data-r="skipb"></button>' +
          '<button class="lupd-btn ghost lupd-hidden" data-r="cancelb"></button>' +
          '<button class="lupd-btn primary" data-r="gob"></button></div>' +
        '<button class="lupd-quit lupd-hidden" data-r="quitb"></button>' +
      '</div>';
    // короткие селекторы по data-r
    var map = {};
    Array.prototype.forEach.call(root.querySelectorAll('[data-r]'), function (el) { map[el.getAttribute('data-r')] = el; });
    q = map;
    q.gob.addEventListener('click', onGo);
    q.skipb.addEventListener('click', function () { call('upd_skip'); });
    q.cancelb.addEventListener('click', function () { call('upd_cancel'); });
    q.quitb.addEventListener('click', function () { call('upd_quit'); });
    // клики мимо карточки ничего не закрывают — окно модальное
    document.body.appendChild(root);
  }

  function buildNotes(text) {
    var box = q.msg, ul = null;
    box.textContent = '';
    text.split(/\r?\n/).forEach(function (raw) {
      var l = raw.trim();
      if (!l) { ul = null; return; }
      var m = l.match(/^[-•*–]\s+(.*)$/);
      if (m) {
        if (!ul) { ul = document.createElement('ul'); box.appendChild(ul); }
        var li = document.createElement('li'); li.textContent = m[1]; ul.appendChild(li);
      } else {
        ul = null;
        var p = document.createElement('p'); p.textContent = l; box.appendChild(p);
      }
    });
  }

  function render() {
    T = L[lang()];
    q.title.textContent = T.title;
    q.cur.textContent = 'v' + info.current;
    q.new.textContent = 'v' + info.latest;
    var msg = (info.message || '').trim();
    buildNotes(msg);
    q.msg.classList.toggle('lupd-hidden', !msg);
    var meta = [];
    if (info.mandatory) meta.push(T.mandatory);
    if (info.size) meta.push(T.size + ' ' + mb(info.size));
    q.meta.textContent = meta.join(' · ');
    q.meta.classList.toggle('lupd-warn', !!info.mandatory);
    q.meta.style.display = meta.length ? '' : 'none';
    q.hint.textContent = info.mandatory ? T.hintM : T.hintO;
    q.gob.textContent = T.go;
    q.skipb.textContent = T.skip;
    q.cancelb.textContent = T.cancel;
    q.quitb.textContent = T.quit;
    q.skipb.classList.toggle('lupd-hidden', !!info.mandatory);
    q.quitb.classList.toggle('lupd-hidden', !info.mandatory);
  }

  function setBusy(on) {
    busy = on;
    q.prog.style.display = on ? 'flex' : 'none';
    q.foot.classList.toggle('lupd-hidden', on);
    q.gob.disabled = on;
    q.skipb.classList.toggle('lupd-hidden', on || !!info.mandatory);
    q.cancelb.classList.toggle('lupd-hidden', !(on && !info.mandatory));
  }

  function onGo() {
    if (busy) return;
    q.err.style.display = 'none';
    q.bar.style.width = '0'; q.pct.textContent = '0';
    q.left.textContent = ''; q.speed.textContent = '';
    setBusy(true);
    call('upd_start');
  }

  function open(data) {
    if (!data) return;
    info = data;
    if (!root) build();
    render();
    setBusy(false);
    root.classList.remove('lupd-out');
    root.style.display = 'flex';
    document.documentElement.classList.add('modal-open'); // ставит на паузу снег/дождь под плашкой
  }

  function close() {
    if (!root) return;
    root.classList.add('lupd-out');
    var r = root;
    setTimeout(function () {
      if (r.classList.contains('lupd-out')) r.style.display = 'none';
    }, 200);
    document.documentElement.classList.remove('modal-open');
  }

  function onProgress(raw) {
    if (!root) return;
    var p = typeof raw === 'string' ? JSON.parse(raw) : raw;
    var pct = p.total ? Math.min(100, p.done / p.total * 100) : 0;
    q.bar.style.width = pct.toFixed(1) + '%';
    q.pct.textContent = Math.floor(pct);
    q.left.textContent = p.total ? mb(p.done) + ' / ' + mb(p.total) : mb(p.done);
    q.speed.textContent = p.speed ? mb(p.speed) + '/s' : '';
  }

  function onFailed(msg) {
    if (!root) return;
    setBusy(false);
    q.err.textContent = msg === 'cancelled' ? T.cancelled : (T.fail + ': ' + msg);
    q.err.style.display = 'block';
    q.gob.textContent = T.retry;
  }

  function onInstalling() {
    if (!root) return;
    q.speed.textContent = T.inst;
    q.gob.disabled = true;
    q.cancelb.classList.add('lupd-hidden');
  }

  window.__leafUpdOn = function (name, payload) {
    try {
      if (name === 'available') open(typeof payload === 'string' ? JSON.parse(payload) : payload);
      else if (name === 'progress') onProgress(payload);
      else if (name === 'failed') onFailed(payload);
      else if (name === 'installing') onInstalling();
      else if (name === 'hide') close();
    } catch (e) { console.error('leaf-upd', e); }
  };

  // Если обновление нашлось ещё до загрузки страницы (или страница перезагрузилась) — спрашиваем у Python.
  var asked = false;
  function ask() {
    if (asked || !api()) return;
    asked = true;
    call('upd_get_info').then(function (raw) {
      if (!raw) return;
      try { open(JSON.parse(raw)); } catch (e) {}
    });
  }
  if (api()) ask();
  window.addEventListener('pywebviewready', ask);
})();
