(async function () {
  'use strict';
const CFG_KEYS = ['leaf-game', 'leaf-privacy', 'leaf-settings', 'leaf-eq', 'leaf-eq-custom', 'leaf-custom', 'leaf-search-source', 'leaf-vinyl', 'leaf-safe-audio'];
let _cfgTimer = 0;

function cfgLsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function cfgLsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

async function cfgLoadFromDisk() {
  if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.get_config) return;
  try {
    const raw = await window.pywebview.api.get_config();
    const obj = JSON.parse(raw || '{}');
    if (!obj || typeof obj !== 'object') return;
    CFG_KEYS.forEach((k) => {
      if (obj[k] !== undefined && obj[k] !== null) {
        cfgLsSet(k, typeof obj[k] === 'string' ? obj[k] : JSON.stringify(obj[k]));
      }
    });
  } catch (e) {}
}

function cfgFlushToDisk() {
  if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.set_config) return;
  clearTimeout(_cfgTimer);
  _cfgTimer = setTimeout(() => {
    const out = {};
    CFG_KEYS.forEach((k) => {
      const v = cfgLsGet(k);
      if (v !== null) { try { out[k] = JSON.parse(v); } catch (e) { out[k] = v; } }
    });
    try { window.pywebview.api.set_config(JSON.stringify(out)); } catch (e) {}
  }, 400);
}

const _origSetItem = Storage.prototype.setItem;
Storage.prototype.setItem = function (key, value) {
  _origSetItem.call(this, key, value);
  if (CFG_KEYS.indexOf(key) > -1) cfgFlushToDisk();
};
let _lastOnline = true;
async function pollOnline() {
  if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.get_online) return;
  try {
    const raw = await window.pywebview.api.get_online();
    const st = JSON.parse(raw || '{}');
    const online = !!st.online;
    if (online === _lastOnline) return;
    _lastOnline = online;
    if (online) {
      window.dispatchEvent(new Event('leaf-online'));
      const nc = document.getElementById('leaf-offline-bar');
      if (nc) nc.remove();
      if (location.pathname.endsWith('/not-network.html')) location.href = '/';
    } else {
      window.dispatchEvent(new Event('leaf-offline'));
      const since = Number(st.offline_since) || (Date.now() / 1000);
      const timeout = Number(st.timeout) || 10;
      const tick = () => {
        if (_lastOnline) return;
        const el = document.getElementById('leaf-offline-bar');
        const left = Math.max(0, timeout - (Date.now() / 1000 - since));
        if (el) el.textContent = left > 0
          ? `Переподключение к серверу… (${Math.ceil(left)} с)`
          : 'Сервер недоступен';
        setTimeout(tick, 1000);
      };
      tick();
    }
  } catch (e) {}
}
setInterval(() => { if (!document.hidden) pollOnline(); }, 3000);
pollOnline();
  let _lastRpcSig = '';
  function pushNowPlayingToDiscord() {
    const tr = state.currentTrack;
    const sig = tr
      ? [tr.id, !!state.isPlaying, Math.floor(state.progress || 0), Math.floor(tr.duration || 0), tr.cover || ''].join('|')
      : 'none';
    if (sig === _lastRpcSig) return;
    _lastRpcSig = sig;

    const body = tr ? {
      title: (tr.title || '').replace(new RegExp('\\s*[-–—]\\s*' + (tr.artist || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$', 'i'), '').trim(),
      artist: tr.artist || '',
      cover: tr.cover || '',
      duration: tr.duration || 0,
      position: state.progress || 0,
      is_playing: !!state.isPlaying,
    } : { title: '', is_playing: false };

    fetch('/api/telemetry/now-playing', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).catch(() => {});
  }
  const ICON_PATHS = {
    home: '<path d="M3 9.5 12 3l9 6.5V21a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    library: '<path d="M4 4h4v16H4zM10 4h4v16h-4zM17 4l4 1v15l-4-1z"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/>',
    radio: '<circle cx="12" cy="12" r="2"/><path d="M4.9 19.1a10 10 0 0 1 0-14.2M19.1 4.9a10 10 0 0 1 0 14.2M7.8 16.2a5.5 5.5 0 0 1 0-8.4M16.2 7.8a5.5 5.5 0 0 1 0 8.4"/>',
    leaf: '<path d="M11 20A7 7 0 0 1 4 13c0-4 4-11 15-11 0 11-7 15-11 15Z"/><path d="M4 20 15 9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.2a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.2a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.6V3a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.6 1H21a2 2 0 1 1 0 4h-.2a1.7 1.7 0 0 0-1.6 1Z"/>',
    play: '<path d="M6 4.5v15l13-7.5Z"/>',
    pause: '<path d="M6 4h4v16H6zM14 4h4v16h-4z"/>',
    skipBack: '<path d="M19 5v14L8 12ZM5 5v14"/>',
    skipForward: '<path d="M5 5v14l11-7ZM19 5v14"/>',
    shuffle: '<path d="M2 5h4l10 14h6M2 19h4l4-5.5M18 5h4v4M22 5l-6 7M22 19l-6-7"/>',
    repeat: '<path d="M17 2l4 4-4 4M3 12v-2a4 4 0 0 1 4-4h14M7 22l-4-4 4-4M21 12v2a4 4 0 0 1-4 4H3"/>',
    volume2: '<path d="M5 9v6h4l5 5V4L9 9Z"/><path d="M16 8a5 5 0 0 1 0 8M18.5 5.5a9 9 0 0 1 0 13"/>',
    volume1: '<path d="M5 9v6h4l5 5V4L9 9Z"/><path d="M16 8a5 5 0 0 1 0 8"/>',
    volumeX: '<path d="M5 9v6h4l5 5V4L9 9Z"/><path d="M17 9l5 6M22 9l-5 6"/>',
    mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 19v3"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M2 14h4M10 8h4M18 12h4"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    rotateCcw: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    volumeIcon: '<path d="M5 9v6h4l5 5V4L9 9Z"/>',
    trendingUp: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
    sparkles: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8"/>',
    headphones: '<path d="M3 14v-2a9 9 0 0 1 18 0v2"/><rect x="3" y="14" width="5" height="7" rx="1.5"/><rect x="16" y="14" width="5" height="7" rx="1.5"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7Z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    gamepad: '<rect x="2" y="7" width="20" height="11" rx="4"/><path d="M7 10v5M4.5 12.5h5M15.5 11h.01M18 14h.01"/>',
    zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7Z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v5h1"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.8-.8 1.8-1.7 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-.9.8-1.7 1.7-1.7H17a4 4 0 0 0 4-4C21 7 17 3 12 3Z"/><circle cx="7.5" cy="11.5" r="1.1" fill="currentColor" stroke="none"/><circle cx="10" cy="7.5" r="1.1" fill="currentColor" stroke="none"/><circle cx="14.5" cy="7.5" r="1.1" fill="currentColor" stroke="none"/><circle cx="17" cy="11" r="1.1" fill="currentColor" stroke="none"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    chevronLeft: '<path d="m15 18-6-6 6-6"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="1.8"/><path d="m21 15-5-5L5 21"/>',
    pipette: '<path d="m2 22 1-1h3l9-9"/><path d="M3 21v-3l9-9"/><path d="m15 6 3.4-3.4a2.1 2.1 0 1 1 3 3L18 9l.4.4a2.1 2.1 0 1 1-3 3l-3.8-3.8a2.1 2.1 0 1 1 3-3l.4.4Z"/>',
    snowflake: '<path d="M12 2v20M4.9 7l14.2 10M19.1 7 4.9 17M9.5 3.5 12 6l2.5-2.5M9.5 20.5 12 18l2.5 2.5"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5Z"/><path d="m3 13 9 5 9-5"/>',
    monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
    contrast: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18a9 9 0 0 0 0-18Z"/>',
  };
  const LIKES_COVER = 'images/Likes.png';
  const PNG_ICONS = {
    play: 'Wave', pause: 'Pause', skipBack: 'Previous', skipForward: 'Next', shuffle: 'Shuffle', repeat: 'Repeat',
    heart: 'Heart', volume2: 'Volume', volume1: 'VolumeLow', volumeX: 'Mute',
    home: 'Home', search: 'Search', library: 'Book Shelf', settings: 'Settings',
    music: 'Music', trash: 'trash', leaf: 'Leaf', user: 'User',
  };
  function icon(name, cls, attrs, svgOnly) {
    if (PNG_ICONS[name] && !svgOnly) return `<span class="pic pic-${name} ico ${cls || ''}" ${attrs || ''}></span>`;
    return `<svg class="ico ${cls || ''}" ${attrs || ''} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICON_PATHS[name] || ''}</svg>`;
  }

  const I18N = {
    ru: {
      czPeekHint: 'Наведите на тему, чтобы увидеть анимированное превью',
      appName: 'Leaf', tagline: 'Музыка для души',
      navHome: 'Главная', navSearch: 'Поиск', navLibrary: 'Моя медиатека', navLiked: 'Любимые треки',
      createPlaylist: 'Создать плейлист',
      searchPlaceholder: 'Поиск...', searchPlaceholderFull: 'Треки, исполнители, альбомы...', searchHint: 'Введите запрос и нажмите Enter',
      light: 'Светлая', dark: 'Тёмная',
      tracks: 'треков',
      search: 'Поиск', yourLibrary: 'Моя медиатека',
      playlistWord: 'Плейлист', likedSongs: 'Любимые треки', noLiked: 'Пока нет любимых треков. Нажмите на сердечко у трека.',
      recentlyPlayed: 'Недавно слушали', recentSub: 'Продолжите с того места, где остановились',
      popularNow: 'Популярное сейчас', popularSub: 'Подборка популярных треков',
      showAll: 'Показать все', showLess: 'Свернуть', retry: 'Повторить', loadFailed: 'Не удалось загрузить треки',
      deletePlaylist: 'Удалить плейлист', removeFromPlaylist: 'Удалить из плейлиста',
      nothingPlaying: 'Ничего не играет', equalizerTitle: 'Эквалайзер',
      settings: 'Настройки', personalize: 'Настройте Leaf под себя',
      appearance: 'Внешний вид', styleLabel: 'Стиль', darkMode: 'Тёмный режим', lightMode: 'Светлый режим',
      colorTheme: 'Цветовая тема',
      myPresets: 'Мои пресеты', presetNamePlaceholder: 'Название пресета', savePreset: 'Сохранить', deletePreset: 'Удалить пресет',
      themeGreen: 'Зелёная', themeBlue: 'Синяя', themeWhite: 'Белая', themeRed: 'Красная', themePurple: 'Фиолетовая',
      language: 'Язык',
      langRu: 'Русский', langPl: 'Polski', langEn: 'English',
      devices: 'Устройства', outputDevice: 'Устройство вывода', connected: 'Подключено',
      externalDeviceConnected: 'Внешнее аудиоустройство', systemDefaultDevice: 'Системное устройство по умолчанию',
      about: 'Leaf Music', version: 'Версия 1.0.0 — сделано с любовью',
      equalizer: 'Эквалайзер', shapeSound: 'Настройте звучание',
      presets: 'Пресеты', bassBoost: 'Усиление баса', reverb: 'Реверберация',
      noResults: 'Ничего не найдено. Попробуйте другой запрос.', resultsFor: 'Результаты по запросу',
      showMore: 'Показать больше', loadingMore: 'Загрузка...',
      greetingMorning: 'Доброе утро', greetingDay: 'Добрый день', greetingEvening: 'Добрый вечер', greetingNight: 'Доброй ночи',
      createPlaylistTitle: 'Новый плейлист', playlistNamePlaceholder: 'Название плейлиста', create: 'Создать', cancel: 'Отмена',
      addToPlaylist: 'Добавить в плейлист', newPlaylist: 'Новый плейлист', noPlaylistsYet: 'У вас пока нет плейлистов',
      emptyPlaylist: 'В этом плейлисте пока нет треков', tracksByArtist: 'Треки',
      outputDeviceUnknown: 'Не удалось определить устройство',
      collapse: 'Свернуть', vinylView: 'Вид пластинки', lyricsTitle: 'Текст песни', lyricsLoading: 'Загружаем текст…', lyricsNotFound: 'Текст песни не найден',
    },
    pl: {
      czPeekHint: 'Najedź na motyw, aby zobaczyć animowany podgląd',
      appName: 'Leaf', tagline: 'Muzyka dla duszy',
      navHome: 'Strona główna', navSearch: 'Szukaj', navLibrary: 'Twoja biblioteka', navLiked: 'Ulubione utwory',
      createPlaylist: 'Utwórz playlistę',
      searchPlaceholder: 'Szukaj...', searchPlaceholderFull: 'Utwory, artyści, albumy...', searchHint: 'Wpisz zapytanie i naciśnij Enter',
      light: 'Jasny', dark: 'Ciemny',
      tracks: 'utworów',
      search: 'Szukaj', yourLibrary: 'Twoja biblioteka',
      playlistWord: 'Playlista', likedSongs: 'Ulubione utwory', noLiked: 'Brak ulubionych utworów. Kliknij serce przy utworze.',
      recentlyPlayed: 'Ostatnio słuchane', recentSub: 'Wróć do tego, co grało',
      popularNow: 'Popularne teraz', popularSub: 'Wybór popularnych utworów',
      showAll: 'Pokaż wszystko', showLess: 'Zwiń', retry: 'Spróbuj ponownie', loadFailed: 'Nie udało się załadować utworów',
      deletePlaylist: 'Usuń playlistę', removeFromPlaylist: 'Usuń z playlisty',
      nothingPlaying: 'Nic nie jest odtwarzane', equalizerTitle: 'Korektor',
      settings: 'Ustawienia', personalize: 'Dostosuj Leaf do siebie',
      appearance: 'Wygląd', styleLabel: 'Styl', darkMode: 'Tryb ciemny', lightMode: 'Tryb jasny',
      colorTheme: 'Motyw kolorystyczny',
      myPresets: 'Moje ustawienia', presetNamePlaceholder: 'Nazwa ustawienia', savePreset: 'Zapisz', deletePreset: 'Usuń ustawienie',
      themeGreen: 'Zielony', themeBlue: 'Niebieski', themeWhite: 'Biały', themeRed: 'Czerwony', themePurple: 'Fioletowy',
      language: 'Język',
      langRu: 'Rosyjski', langPl: 'Polski', langEn: 'Angielski',
      devices: 'Urządzenia', outputDevice: 'Urządzenie wyjściowe', connected: 'Połączono',
      externalDeviceConnected: 'Zewnętrzne urządzenie audio', systemDefaultDevice: 'Domyślne urządzenie systemowe',
      about: 'Leaf Music', version: 'Wersja 1.0.0 — stworzone z troską',
      equalizer: 'Korektor', shapeSound: 'Ukształtuj swój dźwięk',
      presets: 'Ustawienia wstępne', bassBoost: 'Wzmocnienie basu', reverb: 'Pogłos',
      noResults: 'Brak wyników. Spróbuj innego zapytania.', resultsFor: 'Wyniki dla',
      showMore: 'Pokaż więcej', loadingMore: 'Ładowanie...',
      greetingMorning: 'Dzień dobry', greetingDay: 'Dzień dobry', greetingEvening: 'Dobry wieczór', greetingNight: 'Dobranoc',
      createPlaylistTitle: 'Nowa playlista', playlistNamePlaceholder: 'Nazwa playlisty', create: 'Utwórz', cancel: 'Anuluj',
      addToPlaylist: 'Dodaj do playlisty', newPlaylist: 'Nowa playlista', noPlaylistsYet: 'Nie masz jeszcze playlist',
      emptyPlaylist: 'Ta playlista jest jeszcze pusta', tracksByArtist: 'Utwory',
      outputDeviceUnknown: 'Nie udało się wykryć urządzenia',
      collapse: 'Zwiń', vinylView: 'Widok płyty', lyricsTitle: 'Tekst piosenki', lyricsLoading: 'Ładowanie tekstu…', lyricsNotFound: 'Nie znaleziono tekstu piosenki',
    },
    en: {
      czPeekHint: 'Hover a theme to see its animated preview',
      appName: 'Leaf', tagline: 'Music for the soul',
      navHome: 'Home', navSearch: 'Search', navLibrary: 'Your Library', navLiked: 'Liked Songs',
      createPlaylist: 'Create Playlist',
      searchPlaceholder: 'Search...', searchPlaceholderFull: 'Songs, artists, albums...', searchHint: 'Type a query and press Enter',
      light: 'Light', dark: 'Dark',
      tracks: 'tracks',
      search: 'Search', yourLibrary: 'Your Library',
      playlistWord: 'Playlist', likedSongs: 'Liked Songs', noLiked: 'No liked songs yet. Tap the heart on any track.',
      recentlyPlayed: 'Recently played', recentSub: 'Pick up where you left off',
      popularNow: 'Popular right now', popularSub: 'A selection of popular tracks',
      showAll: 'Show all', showLess: 'Show less', retry: 'Retry', loadFailed: 'Could not load tracks',
      deletePlaylist: 'Delete playlist', removeFromPlaylist: 'Remove from playlist',
      nothingPlaying: 'Nothing playing', equalizerTitle: 'Equalizer',
      settings: 'Settings', personalize: 'Personalize your Leaf',
      appearance: 'Appearance', styleLabel: 'Style', darkMode: 'Dark mode', lightMode: 'Light mode',
      colorTheme: 'Color Theme',
      myPresets: 'My presets', presetNamePlaceholder: 'Preset name', savePreset: 'Save', deletePreset: 'Delete preset',
      themeGreen: 'Green', themeBlue: 'Blue', themeWhite: 'White', themeRed: 'Red', themePurple: 'Purple',
      language: 'Language',
      langRu: 'Russian', langPl: 'Polish', langEn: 'English',
      devices: 'Devices', outputDevice: 'Output Device', connected: 'Connected',
      externalDeviceConnected: 'External audio device', systemDefaultDevice: 'System default device',
      about: 'Leaf Music', version: 'Version 1.0.0 — Crafted with care',
      equalizer: 'Equalizer', shapeSound: 'Shape your sound',
      presets: 'Presets', bassBoost: 'Bass Boost', reverb: 'Reverb',
      noResults: 'No results found. Try a different query.', resultsFor: 'Results for',
      showMore: 'Show more', loadingMore: 'Loading...',
      greetingMorning: 'Good morning', greetingDay: 'Good afternoon', greetingEvening: 'Good evening', greetingNight: 'Good night',
      createPlaylistTitle: 'New Playlist', playlistNamePlaceholder: 'Playlist name', create: 'Create', cancel: 'Cancel',
      addToPlaylist: 'Add to playlist', newPlaylist: 'New playlist', noPlaylistsYet: "You don't have any playlists yet",
      emptyPlaylist: 'This playlist has no tracks yet', tracksByArtist: 'Tracks',
      outputDeviceUnknown: 'Could not detect a device',
      collapse: 'Collapse', vinylView: 'Vinyl view', lyricsTitle: 'Lyrics', lyricsLoading: 'Loading lyrics…', lyricsNotFound: 'Lyrics not found',
    },
  };
  function t(key) { return (I18N[state.language] && I18N[state.language][key]) || I18N.en[key] || key; }
  Object.assign(I18N.ru, {
    czBackground: 'Фон', czNone: 'Без фона', czCustomImage: 'Свой файл', czAccountBg: 'Фон аккаунта',
    czDim: 'Затемнение', czBlur: 'Размытие', czRemoveBg: 'Убрать фон', czSyncBg: 'Сохранять фон в аккаунте (синхронизация)',
    czAccent: 'Свой цвет акцента', czAccentReset: 'Сбросить', czEffects: 'Эффекты', czOff: 'Выкл', czSnow: 'Снег', czRain: 'Дождь',
    czLibrary: 'Библиотека тем', czLibraryLocal: 'Встроенные', czLibraryServer: 'Темы сервера',
    czServerLoading: 'Загрузка тем…', czServerEmpty: 'На сервере пока нет тем', czServerError: 'Не удалось загрузить темы сервера', czRetry: 'Повторить',
    czNeedTier: 'Эта тема требует другой тариф', czRateLimited: 'Слишком часто меняете тему — попробуйте позже',
    czThemeFail: 'Не удалось применить тему на сервере', czBadType: 'Поддерживаются JPG, PNG, GIF и WEBP',
    czUploadFail: 'Не удалось обработать изображение', czImageTooBig: 'Изображение слишком большое для локального хранилища',
    czFileOver10: 'Файл больше 10 МБ — в аккаунт не загружен', czSynced: 'Фон сохранён в аккаунте', czSyncFail: 'Не удалось сохранить фон в аккаунте',
    czApplied: 'Тема применена',
  });
  Object.assign(I18N.en, {
    czBackground: 'Background', czNone: 'No background', czCustomImage: 'Your image', czAccountBg: 'Account background',
    czDim: 'Dimming', czBlur: 'Blur', czRemoveBg: 'Remove background', czSyncBg: 'Save background to account (sync)',
    czAccent: 'Custom accent color', czAccentReset: 'Reset', czEffects: 'Effects', czOff: 'Off', czSnow: 'Snow', czRain: 'Rain',
    czLibrary: 'Theme library', czLibraryLocal: 'Built-in', czLibraryServer: 'Server themes',
    czServerLoading: 'Loading themes…', czServerEmpty: 'No themes on the server yet', czServerError: 'Could not load server themes', czRetry: 'Retry',
    czNeedTier: 'This theme requires a different plan', czRateLimited: 'Changing themes too often — try again later',
    czThemeFail: 'Could not apply the theme on the server', czBadType: 'Only JPG, PNG, GIF and WEBP are supported',
    czUploadFail: 'Could not process the image', czImageTooBig: 'Image is too large for local storage',
    czFileOver10: 'File is over 10 MB — not uploaded to the account', czSynced: 'Background saved to your account', czSyncFail: 'Could not save the background to your account',
    czApplied: 'Theme applied',
  });

  Object.assign(I18N.ru, {
    stTabAppearance: 'Оформление', stTabBackground: 'Фон', stTabAccent: 'Акцент и эффекты', stTabThemes: 'Темы', stTabDevices: 'Устройства', stTabAbout: 'О программе',
    glassBlur: 'Размытие стекла', glassBlurDesc: 'Может вызывать мерцание в некоторых окружениях',
  });
  Object.assign(I18N.en, {
    stTabAppearance: 'Appearance', stTabBackground: 'Background', stTabAccent: 'Accent & effects', stTabThemes: 'Themes', stTabDevices: 'Devices', stTabAbout: 'About',
    glassBlur: 'Glass blur', glassBlurDesc: 'May cause flicker in some environments',
  });
  Object.assign(I18N.pl, {
    stTabAppearance: 'Wygląd', stTabBackground: 'Tło', stTabAccent: 'Akcent i efekty', stTabThemes: 'Motywy', stTabDevices: 'Urządzenia', stTabAbout: 'O programie',
    glassBlur: 'Rozmycie szkła', glassBlurDesc: 'Może powodować migotanie w niektórych środowiskach',
  });
  Object.assign(I18N.ru, {
    stGroupLook: 'Оформление', stGroupLookDesc: 'Режим, цвета, фон, эффекты, темы',
    stGroupThemes: 'Библиотека тем', stGroupThemesDesc: 'Встроенные темы и темы сервера',
    stGroupClient: 'Настройки клиента', stGroupClientDesc: 'Язык, устройства',
    stSubMode: 'Режим', stSubColors: 'Цвета', stSubInterface: 'Интерфейс',
  });
  Object.assign(I18N.en, {
    stGroupLook: 'Appearance', stGroupLookDesc: 'Mode, colors, background, effects, themes',
    stGroupThemes: 'Theme library', stGroupThemesDesc: 'Built-in and server themes',
    stGroupClient: 'Client settings', stGroupClientDesc: 'Language, devices',
    stSubMode: 'Mode', stSubColors: 'Colors', stSubInterface: 'Interface',
  });
  Object.assign(I18N.pl, {
    stGroupLook: 'Wygląd', stGroupLookDesc: 'Tryb, kolory, tło, efekty, motywy',
    stGroupThemes: 'Biblioteka motywów', stGroupThemesDesc: 'Wbudowane motywy i motywy serwera',
    stGroupClient: 'Ustawienia klienta', stGroupClientDesc: 'Język, urządzenia',
    stSubMode: 'Tryb', stSubColors: 'Kolory', stSubInterface: 'Interfejs',
  });

  Object.assign(I18N.ru, {
    srcAll: 'Все', srcLockedYt: 'YouTube Music доступен на тарифах Standard и Family',
    srcLoginYt: 'Войдите в аккаунт, чтобы искать в YouTube Music',
    artistsWord: 'Артисты', artistTop: 'Популярные треки', artistAll: 'Все треки',
    artistExpand: 'Показать все', artistCollapse: 'Свернуть', artistBack: 'Назад',
    artistEmpty: 'У этого артиста пока нет треков', artistLoadFail: 'Не удалось загрузить профиль артиста',
    followers: 'подписчиков',
    leafHintPre: 'Введите', leafHintPost: 'в поиске — покажем всех пользователей сервиса',
    leafUsersEmpty: 'Пользователи не найдены', leafUsersError: 'Не удалось загрузить пользователей',
    usrTabLibrary: 'Библиотека', usrTabOther: 'Прочее', usrFavSong: 'Любимая песня', usrTopTracks: 'Любимые треки',
    usrPlaylists: 'Плейлисты', usrEmpty: 'Здесь пока пусто', usrNoTracks: 'Треков нет',
    usrLoadFail: 'Не удалось загрузить профиль', usrListFail: 'Не удалось загрузить список',
    usrOnline: 'В сети', usrOnlineIn: 'В сети:', usrLastSeen: 'Был(а) в сети:',
    usrTotalPlays: 'Всего прослушиваний', usrRegistered: 'Дата регистрации', usrTier: 'Тариф',
    usrVerifiedRow: 'Аккаунт подтверждён', usrYes: 'Да', usrNo: 'Нет',
    leafVerified: 'Аккаунт подтверждён',
  });
  Object.assign(I18N.en, {
    srcAll: 'All', srcLockedYt: 'YouTube Music is available on Standard and Family plans',
    srcLoginYt: 'Sign in to search YouTube Music',
    artistsWord: 'Artists', artistTop: 'Popular tracks', artistAll: 'All tracks',
    artistExpand: 'Show all', artistCollapse: 'Collapse', artistBack: 'Back',
    artistEmpty: 'This artist has no tracks yet', artistLoadFail: 'Could not load the artist profile',
    followers: 'followers',
    leafHintPre: 'Type', leafHintPost: 'in search to list all service users',
    leafUsersEmpty: 'No users found', leafUsersError: 'Could not load users',
    usrTabLibrary: 'Library', usrTabOther: 'Other', usrFavSong: 'Favorite song', usrTopTracks: 'Top tracks',
    usrPlaylists: 'Playlists', usrEmpty: 'Nothing here yet', usrNoTracks: 'No tracks',
    usrLoadFail: 'Could not load the profile', usrListFail: 'Could not load the list',
    usrOnline: 'Online', usrOnlineIn: 'Online in', usrLastSeen: 'Last seen:',
    usrTotalPlays: 'Total plays', usrRegistered: 'Registered', usrTier: 'Plan',
    usrVerifiedRow: 'Verified account', usrYes: 'Yes', usrNo: 'No',
    leafVerified: 'Verified account',
  });
  Object.assign(I18N.pl, {
    srcAll: 'Wszystkie', srcLockedYt: 'YouTube Music jest dostępny w planach Standard i Family',
    srcLoginYt: 'Zaloguj się, aby szukać w YouTube Music',
    artistsWord: 'Artyści', artistTop: 'Popularne utwory', artistAll: 'Wszystkie utwory',
    artistExpand: 'Pokaż wszystkie', artistCollapse: 'Zwiń', artistBack: 'Wstecz',
    artistEmpty: 'Ten artysta nie ma jeszcze utworów', artistLoadFail: 'Nie udało się wczytać profilu artysty',
    followers: 'obserwujących',
    leafHintPre: 'Wpisz', leafHintPost: 'w wyszukiwarce, aby zobaczyć wszystkich użytkowników serwisu',
    leafUsersEmpty: 'Nie znaleziono użytkowników', leafUsersError: 'Nie udało się wczytać użytkowników',
    usrTabLibrary: 'Biblioteka', usrTabOther: 'Inne', usrFavSong: 'Ulubiona piosenka', usrTopTracks: 'Ulubione utwory',
    usrPlaylists: 'Playlisty', usrEmpty: 'Na razie pusto', usrNoTracks: 'Brak utworów',
    usrLoadFail: 'Nie udało się wczytać profilu', usrListFail: 'Nie udało się wczytać listy',
    usrOnline: 'Online', usrOnlineIn: 'Online w', usrLastSeen: 'Ostatnio online:',
    usrTotalPlays: 'Łącznie odtworzeń', usrRegistered: 'Data rejestracji', usrTier: 'Plan',
    usrVerifiedRow: 'Konto zweryfikowane', usrYes: 'Tak', usrNo: 'Nie',
    leafVerified: 'Konto zweryfikowane',
  });

  function svgDataUri(svg) { return 'data:image/svg+xml,' + encodeURIComponent(svg); }
  // Заглушка обложки: ноту (images/MusicNote.png) встраиваем в SVG как data URI — SVG-картинка не может грузить внешние файлы
  const MUSIC_NOTE_B64 = 'iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAABd0lEQVR4nO3arWtXYRTA8SMqqHmwIFptsmSyzAWzQcG/QKtlwpxBrBoWVk0LJkFsVgWLUbsG32ADkb0EcR/5sZu2gbv3DuQ8v/P5C+6X53IvD+dElFJKKb3gFOZwF8/wERtYjhbgIm7hCd5gy+G2IxucxjUs4SW+6SEywW187xOYNhjXsTsmNlvw27Gx2YI3py34WEQWjsdGTFnwUmRhmJ3uY/d08u+OTBzNV7zCfVzFmcjKQZvd6a3gJmajJQ46GS2zT7ROBTdOBTdOBTdOBTdOBTdOBTdOBTcMZ6cmGCfwqPlgXO4GZh/2xzYTjCtYxafDIpsJxnzf2VFkhYdDpoKRkb2VhEEiG8yMmAjuRjZYHHq6kx2OyAavRwT/iGzwZUTw+8jG3mRvqLXIBusjgu9ENng3MPYPzkc2eDww+HlkhAuTVcCesZOVwkuRFe71fJVvRHZ4gN//iP2MhWjs7rva3X1/4We38vui268897+fsZRSSiTwF439zcM3f+kQAAAAAElFTkSuQmCC';
  const MUSIC_ICON_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAOdEVYdFNvZnR3YXJlAEZpZ21hnrGWYwAADAlJREFUeAHtXW1sVFkZPjN32k4/pi0U2IKloYDWltJti1AQ2QXXgKzoboLEaGLWVdforj9cU7LGNSFKdI3+8CNRf5iYGKNZYE1c5aOwbCgmsMWFLdTwoVQpCVC2pV/Tj5l25s71eTp3sLR32tuZuXPvtOdJTu6d6Z17z3mf97znfd97zqkQEhISEhISEhISEhISEhISEvMZLpEE3EIiYWia5tq+fbtn1apV3urq6oLBwcHFfX19hSJJUiRM4MCBA+4NGzZkUfi1tbX5AwMDi8bHxxuGh4e/NDQ09Eu/398Kgt7nZ5IkEkTCP5zP2Ldvn9LW1uYZGRlRCgsLlUuXLuXl5ORUNjU1VblcrqpIJNLg8/mqcKk3KytLEVE5sgTx96SszoImhCZnx44dyp07dxRoOU2P0tLSUgKBr1dVtRqXUOj1+fn55TgqBQUFFH6MAHece2oiCSwYQmhyjh49qvT29ip5eXmeq1evemByVh4/fryKwoccG1DqvF5vkXhU6DymbUyYl4SYMTm4rCo7O9srokKPEaAIm5HRhFhhcuxGxhBCk3PkyBEPvJkJrbfJ5HB8UPWSLSwwZY4kZKrJuXHjRn4wGKyCyamF0GtxCctqmJwsERW+FSYnopcwC54bRi+8rSjKZfTA6+htL8P8PSZSDFsJMWtyUMqh+TGBx4SfSu2MaT2Fr6JeAcQTnW63+zo+XwYJ74XD4etbtmwJoFeGSkpKck6dOvUClCXjCXGVlZV5YdM9Fy5coMkps9HkUOtVCL4Pmv5vfL6OYxviijb0vNsbN26MoIeGIXT12rVrJCoSuwkJwbVJubfxkFZCoGHeY8eO/RyN3gZSStGoqVpvucnBM9uh+e0ej6cdPfFaQ0ODH26wirFJhaBVeGS83hJhm0FaCYEAwEXWU7C/q4VNJoeCp9avW7dOhZOgTr5JZ2enqYchbWIZYWkfQ/RANlEyUmJyCHwnEgUUys3xT1gAOwZ1s9rlBJPjgsfnpscXczqam5tL8LzHQbxPWACnuL0xzR8XaTA5RjCKc/D1stHRUUb29brT8Tj+ViyicssVFsAphFCr3wwEAodzc3OvwEa/D+FbZnIY50DgSn9/vyeWWgHplbE4h4JHWYPemI3eEPP00pJacQwhEP7xTZs2vQlBj4vUYZrJQZyzGIL+UCgUmshp4fxhakX839tLa0JxMpwUqWvLli2LJKr5NDlnz551w2x5YtlcYWByEOfQ5ChINloVZCYFJxFiWigGqZVcmLtV+/fvr4LQGdkzm/thFG+6TU6ycAwhsOFGntE0k3Py5Mkl8HDWQesnclrUehxLMfbEBG9FNveROAclgLIIJUukGI4hBOkTF3NaEPqMJkf3ciZH9qlsg5k45xLinG787Tw+rxEphlMIcWNgrWlvb38BxKwHAXVp8HISjnMaGxt9SC5qUA6RajiFkByUl2B2qKG2ZnPNxjkgTlgBJw3qOSJ5kNCY1lPwYTtSK8kgk1/hTjM5EH43zm/ogn8PJucyTM6Ak7K5syFTCDFlcqD1QcQXETgC4fr6+nAqUyvpgtMISZnJ6ejoEJkIxyQXYV5GIeC7IsNNTrJwCiFBkPGtzZs3vw53U8tkk5MsHGOyMB6E4WoGYiRkqslJFk6aLObq6elZ8NP45foQh0ES4jBIQhwGSYjDIAlxGCQhDoMkxGGQhDgMkhCHIaOXtFkBrjFH2iYrFAq5i4uLJxR2YGAggreZKjLMIaZ25tVka6cCr29zz58/X4wk51PIMn8cqf+VXCGFc86I4aSGy0j7v3348OHWiooKZqeFFVjwhHB3hnPnzpWPj4+/go+fzc/P58rc2DSimEmn9LehfIO7NeD9y6+8Xi9fObOnpDT/tqAJYa9obm5+Hm8ZD6AsFvHlEZvlmI1eswrm64ciOidrYSz6TAeg6T68jfxRQUHBl/Exbw4/JQmpmJBhiAVJCMxUXiAQeBVkfFVYKNxEsODcXnpRp0+f3osx4CURJcPI7HBsGBPRKaNBlJBIExZaD3GdOXOmBObqIMaCgjjXkID/cnmEqqq3udtPOByu8fl8n8T3y0R0wwDLsKAIWbt2bTbGja/BVJUa/R1E9eB9/ivwtN6oqanhevSJ18ncsObWrVt0ib+dl5f3IsjMFxYhpYTE1mh0d3dPmEKu92hpaWGjJgIpNEzYCa4vR/zwRTFdy1m/3rGxsb179ux5B3XmzJbJkypCIOH+zp07v3/o0KGuoqKi1/DZUWPPQ+g7reVxezsMlNuhgc/5/f4mlP3cXQ3+PSdOF0M7cyorK334/qY2HaO49vlkdmIzARfqUg9C/AbPD+L532EdZ7sJSMlHG05wzphN7YgLl+6tPDk0NPQ6KnMfZZiVYgP1wnM/hNCJir4WDAY/iPMOOxpSXV2djed/nbMepz4cdWIkXmrmPlwshPvs1Nua8nYk5GWxV6BSa9G1/4CA6jhs8l58zX0/aFu5OjVHLzz3oXuXwy6/jGvfwXmZsAHoHS7kp1aI6V5VBAr1z9LS0iEz92EuC21/F8JP5VrIh5gzIWS/qanpCeR1ToOIZyBgCn02jYgFUyXCJr9/6dKlbCu9pKltVt1udxeK6YThrl27VJBoSGAkySTXnAhhdz1x4sST0PYj1HoRTSdkxFyqrq4umhS/mD4NlbsyFK9YscL0vVpbWxW4wUbr1CNQ1B5YjoSzwXOxdS5kOrmE63coS2a5llriEg4iC+5qBL3gnpgyKVtEd5qru3jxYpbJRTg0fWsQnxgSgmfcNXiGaZjuIVu3bi3AgPVrnK6Mcwnd2xGUO+jNrfBE2qB5XK8xKhwwORoZWhVjWLuI1vMRgIhFaNvTZgZj7mgE9/grYrrpZQ8MgCiSbnl7FQj404hcjTwLYgym8xQ05wmcF3KXZxacL0VDv4C/3YjjJqbNyyLwnCLU5W6cOtD7m3GXItYPXuUncF0/nbMpvw9BEf+8fPnyuSQqEwOFi4e9bVCJCa0AUT/B0Ufvy+DnHvxtBcpbM5CSFkKYbkc7fkPhGdRBBVlXoP01ZWVluRwv8ROXpm8nThcfkfozuOZ+nDYMI8r/XDpiEFaqDBXpM6gEBfwXlFn3O8c1H8A9/mMnIQTddTzvQZx6RKBcvSDttxD+Z0DOem4njl7xHOp3DH8fifc74CKOxcJqUEg0O1o0yJtai0FW2sx9+GYOjXxRMwjM0knI7t27cyDwg1o0cI2HcS0a+Pn1wrbHNbmQQz/qv1OkI3vOdALGj+8aNCCCdMllpkPM3quvr68cvxuwkxACzytCOabNPK6ZBfRs5FUzaRczmJVR2FOarFKDa1V4Jze51EyYBLRzACSOCJuBeg/iwJdTrSK5dx1cfPp7uNS/6OjoSEnkPisheJALvjVPp7lyc92ZkwtycC+jsYbOgl+kEah7Fw7Pwnz9EUdTaZNJYDZ4oL+//wfo1U24F5UsPa49uyK6pJHJUmmy6IGZvNWEc6BFXcapGILL/FFhQyDJ/wWC9j2LOlzRouMGxw8jb5LfBTFeDMMq/I1ZbCYs015n2nVo0ec1Yw/Dj0G91kylOKjjPt/UjLOtJMmWpKMOBc8vhgf2NN1iKNq/UB7QacH3NLM9IOFdHA+CvI/QBRZ2ZiHgX8fT7BAq/VccZx3YtajrfMtA+yJo7D/m4hxYCIUxyJIlS3x1dXXFrDPGiMcaGxsLWT994LY/HaQHhvECuzGUn2pRH3xaZdnDtGhgeBpFNfg9l0R/T+/+EmZAoUJon9LiB0YcX97iyyoSQwKpUTgvQe9i6uR6HDJoru7p5kr+I625AO+a+Zr2VDzB6t8PQcB3cN15FO7E0KOTGInzmwB9eNk7EoMLtr6Sr2O12aHOQMLDa3CvszguFhKJgQk3uKc7IMRuLTmouhkrFxLJQSdlm+4xJZJ6oBPwd5QKIceN1IBpdgh0NUzYG8iOMvkWMknEA7iRP9akmbIGjHLhRX0MQv4TegxfWg9p0UE8oBeec6DvAHk/4zSgVCXh5itSYTI4Uc6Ld9K5EHgNPpej13B2B2dz3PN4PB14rXmzoqIi1NnZGRQSMyLVNpzkKIhHXNxh1OfzaZOnkkpISEhISEhISEhISEhISEhISCSB/wFSC23k+pvVoAAAAABJRU5ErkJggg=='; // images/Music.png
  const DEFAULT_TRACK_COVER = svgDataUri(
    '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 200 200">' +
    '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
    '<stop offset="0" stop-color="#34343b"/><stop offset="1" stop-color="#0c0c0f"/></linearGradient>' +
    '<radialGradient id="r" cx="0.5" cy="0.42" r="0.6"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>' +
    '<linearGradient id="n" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#9a9aa6"/></linearGradient>' +
    '<mask id="m"><image x="38" y="36" width="124" height="124" xlink:href="data:image/png;base64,' + MUSIC_ICON_B64 + '"/></mask></defs>' +
    '<rect width="200" height="200" fill="url(#g)"/>' +
    '<rect width="200" height="200" fill="url(#r)"/>' +
    '<rect x="38" y="36" width="124" height="124" fill="url(#n)" mask="url(#m)" opacity="0.95"/>' +
    '</svg>'
  );
  const DEFAULT_AVATAR = svgDataUri(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">' +
    '<defs><linearGradient id="a" x1="0" y1="0" x2="1" y2="1">' +
    '<stop offset="0" stop-color="#71717a"/><stop offset="1" stop-color="#27272a"/></linearGradient></defs>' +
    '<rect width="200" height="200" fill="url(#a)"/>' +
    '<circle cx="100" cy="80" r="34" fill="rgba(255,255,255,0.5)"/>' +
    '<path d="M40 176c8-42 40-62 60-62s52 20 60 62" fill="rgba(255,255,255,0.5)"/>' +
    '</svg>'
  );
  const STOCK_COVER_RE = /pexels\.com\/photos\/1370545/;
  function coverOf(tr) {
    const c = tr && tr.cover;
    return (c && !STOCK_COVER_RE.test(c)) ? c : DEFAULT_TRACK_COVER;
  }

  function isScTrack(tr) { return !!tr && /^\d+$/.test(String(tr.id)) && (tr.source || 'soundcloud') === 'soundcloud'; }
  function isYtTrack(tr) { return !!tr && /^yt_[A-Za-z0-9_-]{11}$/.test(String(tr.id)); }
  function isServerTrack(tr) { return isScTrack(tr) || isYtTrack(tr); }
  function isPlayableTrack(tr) { return !!(tr && (tr.streamSrc || isServerTrack(tr))); }
  let safeAudio = false;
  try { safeAudio = localStorage.getItem('leaf-safe-audio') === '1'; } catch (e) {  }
  function streamUrlFor(tr) {
    const q = [];
    if (isServerTrack(tr)) q.push('id=' + encodeURIComponent(tr.id));
    if (tr.streamSrc) q.push('url=' + encodeURIComponent(tr.streamSrc));
    if (safeAudio) q.push('safe=1');
    return '/stream?' + q.join('&');
  }

  let tracks = [];
  let searchResults = [];
  let allKnownTracks = {};
  function registerTracks(list) {
    (list || []).forEach((tr) => { if (tr && tr.id) allKnownTracks[tr.id] = tr; });
  }

  function formatTime(seconds) {
    if (!seconds || !isFinite(seconds)) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  const NAV_ITEMS = [
    { id: 'home', icon: 'home', key: 'navHome' },
    { id: 'search', icon: 'search', key: 'navSearch' },
    { id: 'library', icon: 'library', key: 'navLibrary' },
    { id: 'liked', icon: 'heart', key: 'navLiked' },
  ];

  const COLOR_THEMES = ['green', 'blue', 'white', 'red', 'purple'];

  const EQ_BANDS = [60, 170, 310, 600, 1000, 3000, 6000, 12000, 14000, 16000];
  const EQ_BAND_LABELS = ['60', '170', '310', '600', '1K', '3K', '6K', '12K', '14K', '16K'];
  const EQ_PRESETS = {
    Flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    Bass: [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
    Treble: [0, 0, 0, 0, 0, 2, 4, 5, 6, 6],
    Vocal: [-2, 0, 2, 4, 4, 2, 0, -1, -2, -2],
    Rock: [4, 3, 0, -2, -1, 2, 4, 5, 5, 4],
    Jazz: [3, 2, 1, 2, -1, -1, 0, 1, 2, 3],
    Classical: [3, 2, 1, 0, 0, 0, -1, -2, -2, -2],
    Electronic: [5, 4, 1, 0, -2, 2, 3, 4, 4, 5],
    Pop: [-1, 1, 3, 4, 3, 0, -1, -1, -2, -2],
    'Hip-Hop': [5, 4, 2, 3, -1, -1, 2, -1, 2, 3],
    Dance: [6, 5, 3, 0, 0, -3, -4, -4, 0, 0],
    Acoustic: [4, 4, 3, 1, 2, 2, 3, 3, 3, 2],
    Metal: [5, 4, 1, 0, -2, 0, 3, 5, 6, 5],
    Lounge: [-3, -1, 2, 3, 1, -1, -2, 0, 1, 2],
    Piano: [2, 1, 0, 2, 3, 2, 3, 4, 3, 3],
    'R&B': [3, 6, 5, 1, -2, -1, 2, 2, 2, 3],
    Latin: [3, 2, 0, 0, -1, -1, -1, 0, 3, 4],
    Podcast: [-4, -3, 0, 3, 5, 5, 3, 0, -2, -3],
    Loudness: [6, 4, 1, 0, -1, 0, 1, 3, 5, 5],
    'Late Night': [-3, -1, 0, 2, 3, 2, 1, -1, -3, -4],
    'Bass Reducer': [-6, -5, -4, -2, 0, 0, 0, 0, 0, 0],
    'Treble Reducer': [0, 0, 0, 0, 0, 0, -2, -4, -5, -6],
  };

  function loadSettings() {
    try {
      const raw = localStorage.getItem('leaf-settings');
      if (raw) return JSON.parse(raw);
    } catch (e) {  }
    return {};
  }
  function saveSettings() {
    try {
      localStorage.setItem('leaf-settings', JSON.stringify({
        style: state.style,
        colorTheme: state.colorTheme,
        language: state.language,
        glassBlur: state.glassBlur,
      }));
    } catch (e) {  }
  }

await cfgLoadFromDisk();
const saved = loadSettings();

  function loadLikes() {
    try {
      const raw = localStorage.getItem('leaf-likes');
      if (raw) return JSON.parse(raw);
    } catch (e) {  }
    return {};
  }
  function saveLikes() {
    try { localStorage.setItem('leaf-likes', JSON.stringify(likedTracksData)); } catch (e) {  }
  }
  let likedTracksData = loadLikes();
  function likedList() {
    return Object.values(likedTracksData).sort((a, b) => (b._ord || 0) - (a._ord || 0));
  }
  function nextLikedOrd() {
    let m = 0;
    Object.values(likedTracksData).forEach((t) => { if ((t._ord || 0) > m) m = t._ord; });
    return m + 1;
  }

  function loadCachedUser() {
    try { const u = JSON.parse(localStorage.getItem('leaf-user') || 'null'); return u && u.name ? u : null; } catch (e) { return null; }
  }
  function loadRecents() {
    try {
      const a = JSON.parse(localStorage.getItem('leaf-recent') || '[]');
      return Array.isArray(a) ? a.filter(isPlayableTrack) : [];
    } catch (e) { return []; }
  }
  let recents = loadRecents();
  registerTracks(recents);
  function pushRecent(tr) {
    const slim = { id: tr.id, source: tr.source, title: tr.title, artist: tr.artist, cover: tr.cover,
      duration: tr.duration, genre: tr.genre, streamSrc: tr.streamSrc };
    recents = [slim].concat(recents.filter((x) => x.id !== tr.id)).slice(0, 12);
    try { localStorage.setItem('leaf-recent', JSON.stringify(recents)); } catch (e) {  }
  }

  const state = {
    style: saved.style === 'light' ? 'light' : 'dark',
    colorTheme: COLOR_THEMES.includes(saved.colorTheme) ? saved.colorTheme : 'green',
    language: I18N[saved.language] ? saved.language : 'ru',
    glassBlur: saved.glassBlur === true,
    settingsTab: 'appearance',
    stOpen: { look: true, themes: false, client: false, privacy: false, game: false },
    view: 'home',
    currentTrack: null,
    isPlaying: false,
    progress: 0,
    volume: 70,
    shuffle: false,
    repeat: false,
    likedTracks: new Set(Object.keys(likedTracksData)),
    eqOpen: false,
    settingsOpen: false,
    searchQuery: '',
    searchSource: (() => { try { const v = localStorage.getItem('leaf-search-source'); return ['all', 'soundcloud', 'ytmusic'].includes(v) ? v : 'all'; } catch (e) { return 'all'; } })(),
    searchError: '',
    leafMode: false,
    leafQuery: '',
    subscription: null,
    searchLoading: false,
    searchLoadingMore: false,
    searchLimit: 50,
    searchHasMore: false,
    queue: [],
    queueIndex: -1,
    user: loadCachedUser(),
    homeStatus: 'loading',
    homeExpanded: false,
    fullOpen: false,
    lyricsOpen: false,
    vinyl: (() => { try { return localStorage.getItem('leaf-vinyl') === '1'; } catch (e) { return false; } })(),
    _animNext: false,
    _seeking: false,
    _seekPct: 0,
    audioDevice: null,
    currentArtistName: null,
    currentPlaylistId: null,
    addToPlaylistTrackId: null,
    createPlaylistOpen: false,
    accountOpen: false,
    _rendering: false,
  };

  function loadEqState() {
    const st = { bands: [...EQ_PRESETS.Flat], activePreset: 'Flat', enabled: true, bassBoost: 0, reverb: 0 };
    try {
      const raw = JSON.parse(localStorage.getItem('leaf-eq') || 'null');
      if (raw && Array.isArray(raw.bands) && raw.bands.length === EQ_BANDS.length) {
        st.bands = raw.bands.map((n) => Math.max(-12, Math.min(12, Number(n) || 0)));
        st.activePreset = typeof raw.activePreset === 'string' ? raw.activePreset : 'Custom';
        st.enabled = raw.enabled !== false;
        st.bassBoost = Math.max(0, Math.min(12, Number(raw.bassBoost) || 0));
        st.reverb = Math.max(0, Math.min(100, Number(raw.reverb) || 0));
      }
    } catch (e) {  }
    return st;
  }
  const eqState = loadEqState();
  let _eqSaveTimer = null;
  function saveEqState() {
    clearTimeout(_eqSaveTimer);
    _eqSaveTimer = setTimeout(() => {
      try { localStorage.setItem('leaf-eq', JSON.stringify(eqState)); } catch (e) {  }
    }, 250);
  }
  function loadEqCustom() {
    try {
      const o = JSON.parse(localStorage.getItem('leaf-eq-custom') || '{}');
      return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
    } catch (e) { return {}; }
  }
  let eqCustom = loadEqCustom();
  function saveEqCustom() {
    try { localStorage.setItem('leaf-eq-custom', JSON.stringify(eqCustom)); } catch (e) {  }
  }

  let _appliedLook = null;
  function applyRootClasses() {
    const html = document.documentElement;
    const look = state.style + '|' + state.colorTheme + '|' + state.language + '|' + state.glassBlur;
    if (_appliedLook === look) return;
    if (_appliedLook !== null) {
      html.classList.add('theme-switching');
      clearTimeout(window._themeTimer);
      window._themeTimer = setTimeout(() => html.classList.remove('theme-switching'), 300);
    }
    _appliedLook = look;
    html.classList.toggle('dark', state.style === 'dark');
    html.classList.toggle('glass-blur', state.glassBlur);
    COLOR_THEMES.forEach((c) => html.classList.toggle('theme-' + c, c === state.colorTheme));
    html.lang = state.language;
  }

  const audioEl = document.getElementById('audio-el');
  let audioCtx = null;
  let eqFilterNodes = [];
  let bassFilterNode = null;
  let convolverNode = null;
  let dryGainNode = null;
  let wetGainNode = null;

  function buildImpulseResponse(ctx, duration, decay) {
    const rate = ctx.sampleRate;
    const length = Math.max(1, Math.floor(rate * duration));
    const impulse = ctx.createBuffer(2, length, rate);
    for (let ch = 0; ch < 2; ch++) {
      const data = impulse.getChannelData(ch);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
      }
    }
    return impulse;
  }

  function ensureAudioGraph() {
    if (audioCtx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    audioCtx = new AC();
    const source = audioCtx.createMediaElementSource(audioEl);

    eqFilterNodes = EQ_BANDS.map((freq, i) => {
      const f = audioCtx.createBiquadFilter();
      f.type = 'peaking';
      f.frequency.value = freq;
      f.Q.value = 1;
      f.gain.value = eqState.enabled ? eqState.bands[i] : 0;
      return f;
    });

    bassFilterNode = audioCtx.createBiquadFilter();
    bassFilterNode.type = 'lowshelf';
    bassFilterNode.frequency.value = 120;
    bassFilterNode.gain.value = eqState.enabled ? eqState.bassBoost : 0;

    convolverNode = audioCtx.createConvolver();
    convolverNode.buffer = buildImpulseResponse(audioCtx, 2, 2.5);

    dryGainNode = audioCtx.createGain();
    wetGainNode = audioCtx.createGain();

    let node = source;
    eqFilterNodes.forEach((f) => { node.connect(f); node = f; });
    node.connect(bassFilterNode);
    bassFilterNode.connect(dryGainNode);
    bassFilterNode.connect(convolverNode);
    convolverNode.connect(wetGainNode);
    dryGainNode.connect(audioCtx.destination);
    wetGainNode.connect(audioCtx.destination);

    updateReverbMix();
  }

  function updateReverbMix() {
    if (!dryGainNode || !wetGainNode) return;
    const wet = eqState.enabled ? eqState.reverb / 100 : 0;
    wetGainNode.gain.value = wet * 0.6;
    dryGainNode.gain.value = 1 - wet * 0.4;
  }

  function applyEqToGraph() {
    saveEqState();
    if (!audioCtx) return;
    eqFilterNodes.forEach((f, i) => { f.gain.value = eqState.enabled ? eqState.bands[i] : 0; });
    if (bassFilterNode) bassFilterNode.gain.value = eqState.enabled ? eqState.bassBoost : 0;
    updateReverbMix();
  }

  let _pbTrackId = null;
  let _justLiked = null;

  function loadAndPlay(track) {
    if (!track) return;
    ensureAudioGraph();
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    state.currentTrack = track;
    state.progress = 0;
    pushRecent(track);
    audioEl.src = streamUrlFor(track);
    audioEl.volume = state.volume / 100;
    audioEl.play().catch(() => {  });
    renderAll();
    pushNowPlayingToDiscord();
  }

  function updatePlayerBarOnly() {
    const wrap = document.querySelector('.player-wrap');
    if (!wrap) return;
    const track = state.currentTrack;
    const trackId = track ? String(track.id) : null;
    const liked = track ? state.likedTracks.has(track.id) : false;
    const dur = track ? track.duration : 0;
    const pct = dur ? Math.min(100, Math.max(0, (state.progress / dur) * 100)) : 0;
    const volIcon = state.volume === 0 ? 'volumeX' : state.volume < 50 ? 'volume1' : 'volume2';
    const trackChanged = trackId !== _pbTrackId;
    _pbTrackId = trackId;
    const _setText = (el, v) => { if (el && el.textContent !== v) el.textContent = v; };
    if (trackChanged) {
      if (track) loadLyrics();
      else { lyr.key = null; lyr.lines = []; lyr.synced = false; lyr.status = 'idle'; }
    }
    updateTopLyric();

    if (trackChanged) {
      const winLabel = root.querySelector('#win-title-label');
      if (winLabel) winLabel.textContent = track ? `${track.title} — ${track.artist}` : 'Leaf Music';
      const meta = wrap.querySelector('.now-playing .meta');
      if (meta) {
        meta.innerHTML = `<p class="title text-primary-c truncate">${track ? esc(track.title) : t('nothingPlaying')}</p>`
          + (track
            ? `<div class="artist-row">${sourceBadge(track)}<button class="artist truncate artist-link" data-artist="${esc(track.artist)}" data-artist-source="${esc(track.source || '')}">${esc(track.artist)}</button></div>`
            : `<p class="artist truncate">—</p>`);
      }
      const img = wrap.querySelector('.now-playing img');
      if (img) {
        const src = track ? coverOf(track) : DEFAULT_TRACK_COVER;
        if (img.getAttribute('src') !== src) {
          delete img.dataset.fb;
          img.onload = () => { img.onload = null; img.classList.remove('swap'); void img.offsetWidth; img.classList.add('swap'); };
          img.src = src;
        }
      }
    }

    const playBtn = wrap.querySelector('.play-btn');
    if (playBtn) {
      const k = state.isPlaying ? 'pause' : 'play';
      if (playBtn.dataset.ico !== k) {
        const first = playBtn.dataset.ico === undefined;
        playBtn.dataset.ico = k;
        playBtn.innerHTML = filled(icon(k));
        if (!first) { playBtn.classList.remove('swap'); void playBtn.offsetWidth; playBtn.classList.add('swap'); }
      }
    }

    const seekFill = wrap.querySelector('.track-fill');
    if (seekFill && !state._seeking) {
      if (trackChanged) {
        seekFill.classList.add('snap');
        seekFill.style.width = pct + '%';
        void seekFill.offsetWidth;
        seekFill.classList.remove('snap');
      } else {
        const w = pct.toFixed(1) + '%';
        if (seekFill.style.width !== w) seekFill.style.width = w;
      }
    }
    if (!state._seeking) _setText(wrap.querySelector('.seek-time.start'), formatTime(state.progress));
    _setText(wrap.querySelector('.seek-time.end'), formatTime(dur));

    const likeBtn = wrap.querySelector('#player-like');
    if (likeBtn) {
      if (trackId) setLikedClass(likeBtn, liked, trackId);
      else likeBtn.classList.remove('liked');
    }
    const shuffleBtn = wrap.querySelector('#btn-shuffle');
    if (shuffleBtn) shuffleBtn.classList.toggle('toggle-on', state.shuffle);
    const repeatBtn = wrap.querySelector('#btn-repeat');
    if (repeatBtn) repeatBtn.classList.toggle('toggle-on', state.repeat);

    const volumeIconEl = wrap.querySelector('.volume-group > .ico');
    if (volumeIconEl && volumeIconEl.dataset.ico !== volIcon) {
      volumeIconEl.outerHTML = icon(volIcon, '', `data-ico="${volIcon}"`);
    }
    const volumeFill = wrap.querySelector('.volume-fill');
    if (volumeFill) volumeFill.style.width = state.volume + '%';
    if (state.fullOpen) updateFullPlayer();
    pushNowPlayingToDiscord();
  }

  function enableSafeAudio(reason) {
    if (safeAudio) return false;
    safeAudio = true;
    try { localStorage.setItem('leaf-safe-audio', '1'); } catch (e) {  }
    fetch('/api/client-log', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event: 'safe-audio-enabled', reason }) }).catch(() => {});
    return true;
  }
  try {
    const aac = audioEl.canPlayType('audio/mp4; codecs="mp4a.40.2"');
    if (!aac) enableSafeAudio('canPlayType(aac) is empty');
  } catch (e) {  }
  audioEl.addEventListener('error', () => {
    const err = audioEl.error || {};
    fetch('/api/client-log', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event: 'audio-error', code: err.code, message: err.message, src: audioEl.src,
        canPlay: { aac: audioEl.canPlayType('audio/mp4; codecs="mp4a.40.2"'), mp3: audioEl.canPlayType('audio/mpeg'),
          opus: audioEl.canPlayType('audio/ogg; codecs="opus"') }, safeAudio }) }).catch(() => {});
    const tr = state.currentTrack;
    if ((err.code === 3 || err.code === 4) && tr && isServerTrack(tr) && enableSafeAudio('media error ' + err.code)) {
      audioEl.src = streamUrlFor(tr);
      audioEl.play().catch(() => {});
    }
  });
  audioEl.addEventListener('play', () => { state.isPlaying = true; updatePlayerBarOnly(); syncTrackRows(); });
  audioEl.addEventListener('pause', () => { state.isPlaying = false; updatePlayerBarOnly(); syncTrackRows(); });
  audioEl.addEventListener('timeupdate', () => {
    state.progress = audioEl.currentTime;
    updatePlayerBarOnly();
  });
  audioEl.addEventListener('loadedmetadata', () => {
    if (state.currentTrack && audioEl.duration && isFinite(audioEl.duration)) {
      state.currentTrack.duration = audioEl.duration;
    }
    updatePlayerBarOnly();
  });
  audioEl.addEventListener('ended', () => {
    if (state.repeat) { audioEl.currentTime = 0; audioEl.play(); return; }
    handleNext();
  });

  function queueForView() {
    if (state.view === 'search') return searchResults;
    if (state.view === 'liked') return likedList();
    if (state.view === 'artist') return artistTracks;
    if (state.view === 'user') return userTracks;
    if (state.view === 'playlist') {
      const pl = userPlaylists.find((p) => p.id === state.currentPlaylistId);
      return pl ? pl.trackIds.map((id) => allKnownTracks[id]).filter(Boolean) : [];
    }
    return tracks;
  }
  function playTrackById(id, queue, force) {
    if (!force && state.currentTrack && String(state.currentTrack.id) === String(id) && audioEl.src) {
      if (audioEl.paused) audioEl.play().catch(() => {  });
      else audioEl.pause();
      return;
    }
    const list = queue || queueForView();
    const idx = list.findIndex((tr) => tr.id === id);
    if (idx === -1) return;
    state.queue = list;
    state.queueIndex = idx;
    loadAndPlay(list[idx]);
  }
  function handleNext() {
    if (!state.queue || state.queue.length === 0) return;
    let idx;
    if (state.shuffle) idx = Math.floor(Math.random() * state.queue.length);
    else idx = (state.queueIndex + 1) % state.queue.length;
    state.queueIndex = idx;
    loadAndPlay(state.queue[idx]);
  }
  function handlePrev() {
    if (!state.queue || state.queue.length === 0) return;
    if (audioEl.currentTime > 3) { audioEl.currentTime = 0; return; }
    const idx = (state.queueIndex - 1 + state.queue.length) % state.queue.length;
    state.queueIndex = idx;
    loadAndPlay(state.queue[idx]);
  }
  function toggleLike(trackId) {
    let removed = false;
    let tr = null;
    if (state.likedTracks.has(trackId)) {
      tr = likedTracksData[trackId];
      state.likedTracks.delete(trackId);
      delete likedTracksData[trackId];
      removed = true;
    } else {
      tr = allKnownTracks[trackId]
        || (state.currentTrack && state.currentTrack.id === trackId ? state.currentTrack : null);
      if (!tr) return;
      state.likedTracks.add(trackId);
      tr = Object.assign({}, tr, { _ord: nextLikedOrd() });
      likedTracksData[trackId] = tr;
    }
    saveLikes();
    _justLiked = removed ? null : trackId;
    renderAll();
    if (serverMode && isServerTrack(tr || { id: trackId })) {
      const req = removed
        ? apiJson('/api/user/liked/' + encodeURIComponent(trackId), 'DELETE')
        : apiJson('/api/user/liked', 'POST', tr);
      req.catch(() => {
        if (removed) { state.likedTracks.add(trackId); if (tr) likedTracksData[trackId] = tr; }
        else { state.likedTracks.delete(trackId); delete likedTracksData[trackId]; }
        saveLikes(); renderAll();
      });
    }
  }

  const SEARCH_PAGE_SIZE = 50;
  const SEARCH_PAGE_STEP = 20;

  const LEAF_PREFIX = 'leaf:';
  const LEAF_THEME_COLORS = { green: '#24B966', blue: '#247CB9', red: '#B92430', purple: '#7B24B9', pink: '#9561ba', white: '#E4E7EC' };
  const LEAF_THEME_BACK = { green: '#298059', blue: '#295380', red: '#802B29', purple: '#652980', pink: '#70537e', white: '#D8DCE3' };
  const SEARCH_SOURCES = ['all', 'soundcloud', 'ytmusic'];
  let searchArtists = [];
  let leafUsers = [];
  let leafStatus = 'idle';
  let _leafToken = 0;
  let _leafTimer = 0;

  function ytSourceLocked() {
    const sub = state.subscription;
    return !!(sub && sub.ytmusic_enabled === false);
  }
  function searchErrorText(err) {
    if (!err) return '';
    if (err.status === 401) return t('srcLoginYt');
    if (err.status === 402 || err.status === 403) return t('srcLockedYt');
    return err.message || t('noResults');
  }
  function leafQueryOf(value) {
    const v = String(value || '').trim();
    return v.toLowerCase().startsWith(LEAF_PREFIX) ? v.slice(LEAF_PREFIX.length).trim() : null;
  }

  let _searchSeq = 0;
  async function performSearch(query, options) {
    options = options || {};
    query = (query || '').trim();
    if (leafQueryOf(query) !== null) { onSearchTyping(query); return; }
    state.leafMode = false;
    state.searchQuery = query;
    state.searchError = '';
    const seq = ++_searchSeq;
    if (!query) {
      searchResults = []; searchArtists = []; state.searchLimit = SEARCH_PAGE_SIZE; state.searchHasMore = false;
      state.searchLoading = false; state.searchLoadingMore = false;
      renderAll();
      return;
    }
    if (!options.loadMore) { state.searchLimit = SEARCH_PAGE_SIZE; searchArtists = []; }
    state.view = 'search';
    const src = state.searchSource;
    if (src === 'ytmusic' && ytSourceLocked()) {
      searchResults = []; state.searchHasMore = false;
      state.searchLoading = false; state.searchLoadingMore = false;
      state.searchError = t('srcLockedYt');
      renderAll();
      return;
    }
    if (options.loadMore) state.searchLoadingMore = true;
    else state.searchLoading = true;
    renderAll();
    if (!options.loadMore) loadSearchArtists(query, src, seq);
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&limit=${state.searchLimit}&source=${src}`);
      const data = await res.json();
      if (seq !== _searchSeq) return;
      if (data.source_error) {
        searchResults = [];
        state.searchHasMore = false;
        state.searchError = searchErrorText(data.source_error);
      } else {
        searchResults = (data.tracks || []).filter(isPlayableTrack);
        registerTracks(searchResults);
        state.searchHasMore = searchResults.length >= state.searchLimit;
      }
    } catch (e) {
      if (seq !== _searchSeq) return;
      searchResults = [];
      state.searchHasMore = false;
    }
    state.searchLoading = false;
    state.searchLoadingMore = false;
    state._animNext = !options.loadMore;
    renderAll();
  }

  /* Профили артистов — отдельной полосой над треками. Грузим параллельно с треками
     и не ждём их: поиск каналов YouTube заметно медленнее. */
  async function loadSearchArtists(query, src, seq) {
    let list = [];
    try {
      const res = await fetch(`/api/search/artists?q=${encodeURIComponent(query)}&source=${src}`);
      if (res.ok) list = (await res.json()).artists || [];
    } catch (e) {  }
    if (seq !== _searchSeq) return;
    searchArtists = list;
    state._animNext = false;
    renderAll();
  }

  function setSearchSource(src) {
    if (!SEARCH_SOURCES.includes(src) || src === state.searchSource) return;
    state.searchSource = src;
    try { localStorage.setItem('leaf-search-source', src); } catch (e) {  }
    // Берём текст прямо из поля: он мог быть набран, но ещё не отправлен по Enter —
    // иначе перерисовка затирает его значением state.searchQuery.
    const si = root.querySelector('#search-input');
    const typed = si ? si.value.trim() : '';
    if (!state.leafMode && leafQueryOf(typed) === null && (typed || state.searchQuery)) performSearch(typed || state.searchQuery);
    else renderAll();
  }

  /* Режим «leaf:» — вместо треков показываем пользователей сервиса. */
  function loadLeafUsers(query) {
    clearTimeout(_leafTimer);
    leafStatus = 'loading';
    _leafTimer = setTimeout(async () => {
      const token = ++_leafToken;
      try {
        const d = await apiJson('/api/users/search?q=' + encodeURIComponent(query));
        if (token !== _leafToken) return;
        leafUsers = Array.isArray(d.users) ? d.users : [];
        leafStatus = 'ok';
      } catch (e) {
        if (token !== _leafToken) return;
        leafUsers = [];
        leafStatus = 'error';
      }
      renderAll();
    }, 200);
  }
  function onSearchTyping(value) {
    const lq = leafQueryOf(value);
    if (lq === null) {
      if (state.leafMode) { state.leafMode = false; _leafToken++; clearTimeout(_leafTimer); renderAll(); }
      return;
    }
    ++_searchSeq;
    state.searchLoading = false; state.searchLoadingMore = false;
    state.leafMode = true;
    state.leafQuery = lq;
    state.view = 'search';
    loadLeafUsers(lq);
    renderAll();
  }

  function loadMoreSearchResults() {
    if (!state.searchQuery || state.searchLoadingMore) return;
    state.searchLimit += SEARCH_PAGE_STEP;
    performSearch(state.searchQuery, { loadMore: true });
  }

  async function loadHomeTracks() {
    state.homeStatus = 'loading';
    if (!tracks.length) renderAll();
    try {
      const res = await fetch('/api/home');
      if (!res.ok) throw new Error('http ' + res.status);
      const data = await res.json();
      const list = (data.tracks || []).filter(isPlayableTrack);
      if (list.length) { tracks = list; registerTracks(tracks); }
    } catch (e) {  }
    state.homeStatus = tracks.length ? 'ready' : 'error';
    state._animNext = true;
    renderAll();
  }

  const HEADPHONE_HINT = /headphone|headset|airpods|buds|earbud|bluetooth|беспровод|наушник|гарнитур/i;

  function getAudioOutputDevice() {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        return navigator.mediaDevices.enumerateDevices()
          .then(devices => {
            const outputs = devices.filter(d => d.kind === 'audiooutput' && d.label);
            if (outputs.length > 0) {
              const headphone = outputs.find(d => HEADPHONE_HINT.test(d.label));
              return headphone ? headphone.label : outputs[0].label;
            }

            const allOutputs = devices.filter(d => d.kind === 'audiooutput');
            if (allOutputs.length > 1) {
              return t('externalDeviceConnected');
            }
            return null;
          })
          .catch(() => null);
      }
      return Promise.resolve(null);
    } catch (e) {
      return Promise.resolve(null);
    }
  }

  async function loadTelemetry() {
    try {
      const res = await fetch('/api/telemetry/status');
      const data = await res.json();

      if (data.audioDevice && data.audioDevice !== 'Default Audio Device') {
        state.audioDevice = data.audioDevice;
      } else {
        const device = await getAudioOutputDevice();
        state.audioDevice = device || t('outputDeviceUnknown');
      }
    } catch (e) {
      state.audioDevice = t('outputDeviceUnknown');
    }
    renderAll();
  }

  let artistTracks = [];
  let artistPage = null;
  let _artistSeq = 0;
  const ARTIST_COLLAPSED = 10;

  function artistQueueOf(p) {
    const seen = new Set(p.top.map((tr) => tr.id));
    return p.top.concat(p.all.filter((tr) => !seen.has(tr.id)));
  }
  function startArtistPage(init) {
    const prev = state.view === 'artist' && artistPage ? artistPage.prevView : state.view;
    artistPage = Object.assign({
      key: '', name: '', source: '', id: '', avatar: '', followers: 0,
      top: [], all: [], loading: true, error: '', expanded: false, prevView: prev || 'search',
    }, init);
    artistTracks = [];
    state.view = 'artist';
    state.currentArtistName = artistPage.key;
    state._animNext = true;
    renderAll();
  }
  function refreshArtistView(animate) {
    if (state.view !== 'artist') return;
    state._animNext = !!animate;
    renderAll();
  }

  /* Клик по артисту в полосе поиска: источник и id уже известны. */
  async function openArtistById(source, id, hint) {
    hint = hint || {};
    const seq = ++_artistSeq;
    startArtistPage({ key: source + ':' + id, source, id, name: hint.name || '', avatar: hint.avatar_url || '' });
    await fillArtistPage(seq, source, id);
  }
  /* Клик по имени артиста у трека / в плеере: ищем профиль в том же источнике,
     что и трек, и берём точное совпадение имени (иначе первый результат). */
  async function openArtistByName(name, source) {
    if (!name) return;
    const src = source === 'ytmusic' || source === 'soundcloud' ? source : 'all';
    const seq = ++_artistSeq;
    startArtistPage({ key: 'name:' + src + ':' + name, source: src === 'all' ? '' : src, name });
    let pick = null;
    try {
      const d = await apiJson(`/api/search/artists?q=${encodeURIComponent(name)}&source=${src}`);
      if (seq !== _artistSeq) return;
      const list = d.artists || [];
      pick = list.find((a) => String(a.name).toLowerCase() === name.toLowerCase()) || list[0] || null;
    } catch (e) {
      if (seq !== _artistSeq) return;
      artistPage.loading = false;
      artistPage.error = e.status === 402 || e.status === 403 ? 'tier' : 'fail';
      refreshArtistView(false);
      return;
    }
    if (!pick) { artistPage.loading = false; refreshArtistView(false); return; }
    Object.assign(artistPage, { source: pick.source, id: pick.id, name: pick.name || name, avatar: pick.avatar_url || '', followers: pick.followers_count || 0 });
    refreshArtistView(false);
    await fillArtistPage(seq, pick.source, pick.id);
  }
  function openArtistPage(name, source) { return openArtistByName(name, source); }

  async function fillArtistPage(seq, source, id) {
    try {
      const d = await apiJson(`/api/artist/${encodeURIComponent(source)}/${encodeURIComponent(id)}`);
      if (seq !== _artistSeq) return;
      const a = d.artist || {};
      artistPage.name = a.name || artistPage.name;
      artistPage.avatar = a.avatar_url || artistPage.avatar;
      artistPage.followers = a.followers_count || artistPage.followers;
      artistPage.top = (d.top_tracks || []).filter(isPlayableTrack);
      artistPage.all = (d.tracks || []).filter(isPlayableTrack);
      registerTracks(artistPage.top.concat(artistPage.all));
      artistTracks = artistQueueOf(artistPage);
    } catch (e) {
      if (seq !== _artistSeq) return;
      artistPage.error = e.status === 402 || e.status === 403 ? 'tier' : 'fail';
    }
    artistPage.loading = false;
    refreshArtistView(true);
  }
  function goBackFromArtist() {
    const prev = artistPage && artistPage.prevView && artistPage.prevView !== 'artist' ? artistPage.prevView : 'search';
    _artistSeq++;
    state.view = prev;
    state._animNext = true;
    renderAll();
  }

  /* ====================== Профиль другого пользователя ======================
     Открывается кликом по человеку в подсказке «leaf:» в поиске. Данные — те же ручки, что у веба
     (через локальный адаптер): /api/users/{login}/profile | library | liked | playlists/{id}/tracks. */
  let userPage = null;
  let userTracks = [];
  let _userSeq = 0;

  function userTopTracks() {
    return ((userPage && userPage.library && userPage.library.top_tracks) || []).filter(isPlayableTrack);
  }
  /* Очередь плеера = то, что сейчас открыто в профиле: список плейлиста или «Любимые треки». */
  function syncUserQueue() {
    userTracks = !userPage ? [] : (userPage.list ? userPage.list.tracks : userTopTracks());
  }
  function startUserPage(hint) {
    const prev = state.view === 'user' && userPage ? userPage.prevView : state.view;
    userPage = {
      login: hint.login, username: hint.username || hint.login, avatar_url: hint.avatar_url || '',
      theme: hint.theme || 'green', theme_color: hint.theme_color || '', verified: !!hint.verified,
      profile: null, library: null, loading: true, error: '', tab: 'library', list: null,
      prevView: prev && prev !== 'user' ? prev : 'search',
    };
    userTracks = [];
    state.view = 'user';
    state.currentUserLogin = hint.login;
    state._animNext = true;
    renderAll();
  }
  function refreshUserView(animate) {
    if (state.view !== 'user') return;
    state._animNext = !!animate;
    renderAll();
  }
  async function openUserProfile(hint) {
    if (!hint || !hint.login) return;
    const seq = ++_userSeq;
    startUserPage(hint);
    const login = encodeURIComponent(hint.login);
    const [pRes, lRes] = await Promise.allSettled([
      apiJson(`/api/users/${login}/profile`),
      apiJson(`/api/users/${login}/library`),
    ]);
    if (seq !== _userSeq || !userPage) return;
    if (pRes.status === 'fulfilled' && pRes.value) {
      const pr = pRes.value;
      userPage.profile = pr;
      Object.assign(userPage, {
        username: pr.username || userPage.username, avatar_url: pr.avatar_url || userPage.avatar_url,
        theme: pr.theme || userPage.theme, theme_color: pr.theme_color || '', verified: !!pr.verified,
      });
      if (pr.favorite_track) registerTracks([pr.favorite_track]);
    } else {
      userPage.error = 'fail';
    }
    if (lRes.status === 'fulfilled' && lRes.value) {
      userPage.library = lRes.value;
      registerTracks(userTopTracks());
    }
    userPage.loading = false;
    syncUserQueue();
    refreshUserView(true);
  }
  async function openUserList(id, title) {
    if (!userPage) return;
    const seq = ++_userSeq;
    userPage.list = { id, title: title || '', tracks: [], loading: true, error: '' };
    userTracks = [];
    refreshUserView(false);
    const login = encodeURIComponent(userPage.login);
    try {
      const d = await apiJson(id === 'liked'
        ? `/api/users/${login}/liked`
        : `/api/users/${login}/playlists/${encodeURIComponent(id)}/tracks`);
      if (seq !== _userSeq || !userPage || !userPage.list) return;
      userPage.list.tracks = (d.tracks || []).filter(isPlayableTrack);
      registerTracks(userPage.list.tracks);
    } catch (e) {
      if (seq !== _userSeq || !userPage || !userPage.list) return;
      userPage.list.error = 'fail';
    }
    userPage.list.loading = false;
    syncUserQueue();
    refreshUserView(true);
  }
  function closeUserList() {
    if (!userPage) return;
    _userSeq++;
    userPage.list = null;
    syncUserQueue();
    refreshUserView(false);
  }
  function goBackFromUser() {
    const prev = userPage && userPage.prevView && userPage.prevView !== 'user' ? userPage.prevView : 'search';
    _userSeq++;
    state.view = prev;
    state._animNext = true;
    renderAll();
  }
  function userTimeLabel(iso, withTime) {
    if (!iso) return '';
    /* сервер отдаёт UTC без «Z» — без него браузер сдвинул бы время на часовой пояс */
    const d = new Date(/(?:[zZ]|[+-]\d{2}:?\d{2})$/.test(iso) ? iso : iso + 'Z');
    if (isNaN(d.getTime())) return '';
    const loc = { ru: 'ru-RU', pl: 'pl-PL', en: 'en-US' }[state.language] || 'en-US';
    try {
      return d.toLocaleString(loc, withTime
        ? { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }
        : { day: 'numeric', month: 'long', year: 'numeric' });
    } catch (e) { return ''; }
  }
  /* «В сети: Leaf Web» / «В сети: Leaf Desktop» — название клиента своим цветом (как в вебе). */
  function userStatusHtml(pr) {
    if (!pr) return '';
    if (pr.is_online) {
      const label = { web: 'Leaf Web', desktop: 'Leaf Desktop' }[pr.last_client];
      return label
        ? `${esc(t('usrOnlineIn'))} <span class="leaf-client-badge leaf-client-${pr.last_client}">${label}</span>`
        : esc(t('usrOnline'));
    }
    const seen = userTimeLabel(pr.last_seen, true);
    return seen ? `${esc(t('usrLastSeen'))} ${esc(seen)}` : '';
  }
  function userBadgesHtml(pr, accent) {
    return ((pr && pr.badges) || []).map((b) => {
      const url = esc(String(b.icon).replace(/'/g, '%27'));
      return `<span class="name-badge-icon" title="${esc(b.name)}" style="background-color:${accent};-webkit-mask-image:url('${url}');mask-image:url('${url}');"></span>`;
    }).join('');
  }
  function userCollectionCard(o) {
    return `
      <button class="playlist-card glass" data-open-user-list="${esc(o.id)}" data-user-list-title="${esc(o.name)}">
        <div class="cover-wrap">
          ${o.cover
            ? `<img class="cover-img" src="${esc(o.cover)}" alt="" loading="lazy" decoding="async" />`
            : `<div class="cover-fallback ${o.liked ? 'liked' : ''}">${icon(o.icon, o.liked ? 'solid' : '')}</div>`}
          <div class="grad"></div>
          <div class="info">
            <p class="name font-display truncate">${esc(o.name)}</p>
            <p class="count">${o.count} ${t('tracks')}</p>
          </div>
        </div>
      </button>`;
  }
  function userOtherRow(label, value) {
    return `<div class="user-other-row"><span class="user-other-label">${esc(label)}</span><span class="user-other-value">${esc(value)}</span></div>`;
  }
  function userListHtml(l) {
    let inner;
    if (l.loading) inner = `<div class="glass tracklist">${skeletonRows(6)}</div>`;
    else if (l.error) inner = `<p class="empty-state">${t('usrListFail')}</p>`;
    else if (!l.tracks.length) inner = `<p class="empty-state">${t('usrNoTracks')}</p>`;
    else inner = `<div class="glass tracklist">${l.tracks.map((tr, i) => trackRowHtml(tr, i)).join('')}</div>`;
    return `
      <button class="user-list-back glass-subtle" data-user-list-back>${icon('chevronLeft', '', '', true)}<span>${t('usrPlaylists')}</span></button>
      <h2 class="font-display text-primary-c results-title user-list-title">${esc(l.title)}</h2>
      ${inner}`;
  }
  function userLibraryHtml(p) {
    const lib = p.library;
    const top = userTopTracks();
    const cards = [];
    if (lib && lib.liked_is_public !== false) {
      cards.push({ id: 'liked', name: t('likedSongs'), count: lib.liked_count || 0, icon: 'heart', liked: true, cover: LIKES_COVER });
    }
    ((lib && lib.playlists) || []).forEach((pl) => cards.push({ id: pl.id, name: pl.name, count: pl.track_count || 0, icon: 'music' }));
    if (!top.length && !cards.length) return `<p class="empty-state">${t('usrEmpty')}</p>`;
    return (top.length
        ? `<h2 class="font-display text-primary-c results-title">${t('usrTopTracks')}</h2>
           <div class="glass tracklist">${top.map((tr, i) => trackRowHtml(tr, i)).join('')}</div>` : '')
      + (cards.length
        ? `<h2 class="font-display text-primary-c results-title user-pl-title">${t('usrPlaylists')}</h2>
           <div class="card-grid">${cards.map(userCollectionCard).join('')}</div>` : '');
  }
  function userFavHtml(ft) {
    if (!ft || !isPlayableTrack(ft)) return '';
    const cov = ft.cover && coverOf(ft) === ft.cover ? String(ft.cover).replace(/'/g, '%27') : '';
    const bg = cov ? ` style="background-image:url('${esc(cov)}')"` : '';
    const cur = !!(state.currentTrack && String(state.currentTrack.id) === String(ft.id));
    return `
      <div class="user-fav">
        <div class="user-fav-label">${icon('heart', '', '', true)}<span>${t('usrFavSong')}</span></div>
        <div class="fav-song${cur ? ' is-current' : ''}${cur && !state.isPlaying ? ' is-paused' : ''}" data-play-fav="${esc(ft.id)}" data-fav-id="${esc(ft.id)}" role="button" tabindex="0">
          <div class="fav-song-glow"${bg}></div>
          <div class="fav-song-scrim"></div>
          <div class="fav-song-body">
            <div class="fav-song-cover"${bg}>
              ${cov ? '' : icon('music', '', '', true)}
              <span class="fav-song-cover-btn"><span class="fav-ic-play">${filled(icon('play', '', '', true))}</span><span class="fav-ic-pause">${filled(icon('pause', '', '', true))}</span></span>
            </div>
            <div class="fav-song-text">
              <div class="fav-song-title">${esc(ft.title)}</div>
              <div class="fav-song-artist">${esc(ft.artist)}</div>
            </div>
            <div class="fav-song-right">
              <span class="fav-song-duration">${formatTime(ft.duration)}</span>
              <span class="fav-song-eq"><i></i><i></i><i></i><i></i></span>
            </div>
          </div>
        </div>
      </div>`;
  }
  function renderUserProfile() {
    const p = userPage || {
      login: '', username: '', avatar_url: '', theme: 'green', theme_color: '', verified: false,
      profile: null, library: null, loading: false, error: 'fail', tab: 'library', list: null,
    };
    const pr = p.profile;
    const accent = leafUserAccent(p);
    const name = String(p.username || p.login || '?');
    const badges = pr ? userBadgesHtml(pr, accent) : '';
    const status = userStatusHtml(pr);
    const adminDesc = pr && pr.is_admin && pr.admin_description ? `<p class="user-admin-desc">${esc(pr.admin_description)}</p>` : '';
    const hero = `
      <div class="liked-hero artist-hero user-hero">
        <div class="artist-avatar-wrap">
          <div class="user-avatar" style="${leafUserAvatarStyle(p)}">
            <span class="user-avatar-initial">${esc(name.charAt(0).toUpperCase())}</span>
            ${p.avatar_url ? `<img src="${esc(p.avatar_url)}" alt="" onerror="this.remove()" />` : ''}
          </div>
          <button class="artist-back" data-user-back title="${t('artistBack')}" aria-label="${t('artistBack')}">${icon('chevronLeft', '', '', true)}</button>
        </div>
        <div style="min-width:0;flex:1;">
          <div class="user-name-row">
            <h1 class="font-display text-primary-c truncate">${esc(name)}</h1>
            ${p.verified ? `<span class="leaf-user-verified" style="background:${accent};" title="${esc(t('leafVerified'))}">${icon('check', '', '', true)}</span>` : ''}
            ${badges ? `<span class="name-badges-row">${badges}</span>` : ''}
          </div>
          <p class="count">${p.login ? '@' + esc(p.login) : ''}</p>
          <p class="user-status">${status || '&nbsp;'}</p>
          ${adminDesc}
        </div>
      </div>`;

    const ready = !p.loading && !p.error;
    const fav = ready && pr ? userFavHtml(pr.favorite_track) : '';
    const tabs = ready ? `
      <div class="user-tabs">
        <button class="user-tab${p.tab === 'library' ? ' active' : ''}" data-user-tab="library">${t('usrTabLibrary')}</button>
        <button class="user-tab${p.tab === 'other' ? ' active' : ''}" data-user-tab="other">${t('usrTabOther')}</button>
      </div>` : '';

    let body;
    if (p.loading) body = `<div class="glass tracklist">${skeletonRows(5)}</div>`;
    else if (p.error) body = `<p class="empty-state">${t('usrLoadFail')}</p>`;
    else if (p.tab === 'other') {
      const reg = userTimeLabel(pr && pr.created_at, false) || '—';
      body = `<div class="glass user-other">
        ${userOtherRow(t('usrTotalPlays'), String((pr && pr.total_plays) || 0))}
        ${userOtherRow(t('usrRegistered'), reg)}
        ${userOtherRow(t('usrTier'), (pr && pr.subscription_display_name) || '—')}
        ${userOtherRow(t('usrVerifiedRow'), pr && pr.verified ? t('usrYes') : t('usrNo'))}
      </div>`;
    } else body = p.list ? userListHtml(p.list) : userLibraryHtml(p);

    return `
      <div class="view-pad user-view">
        ${sec('hero', hero, 'animate-fade-in-up')}
        ${sec('fav', fav)}
        ${sec('tabs', tabs)}
        ${sec('body', body, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function loadUserPlaylists() {
    try {
      const raw = localStorage.getItem('leaf-user-playlists');
      if (raw) return JSON.parse(raw);
    } catch (e) {  }
    return [];
  }
  function saveUserPlaylists() {
    try { localStorage.setItem('leaf-user-playlists', JSON.stringify(userPlaylists)); } catch (e) {  }
  }
  let userPlaylists = loadUserPlaylists();

  function playlistCover(pl) {
    if (pl.trackIds && pl.trackIds.length) {
      const tr = allKnownTracks[pl.trackIds[0]];
      if (tr) return coverOf(tr);
    }
    return null;
  }
  let serverMode = false;
  const isLocalPlaylist = (pl) => String(pl.id).startsWith('up-');

  async function apiJson(url, method, body) {
    const res = await fetch(url, {
      method: method || 'GET',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) { const err = new Error('http ' + res.status); err.status = res.status; throw err; }
    return res.json();
  }

  async function migrateLegacyLibrary() {
    const legacyLikes = Object.values(likedTracksData).filter(isScTrack);
    const legacyPlaylists = userPlaylists.filter(isLocalPlaylist);
    if (!legacyLikes.length && !legacyPlaylists.length) return true;
    try {
      if (!localStorage.getItem('leaf-legacy-backup')) {
        localStorage.setItem('leaf-legacy-backup', JSON.stringify({ likes: likedTracksData, playlists: userPlaylists }));
      }
    } catch (e) {  }

    let ok = true;
    for (const tr of legacyLikes) {
      try { await apiJson('/api/user/liked', 'POST', tr); } catch (e) { ok = false; if (e.status === 401) return false; }
    }
    for (const lp of legacyPlaylists) {
      let serverId;
      try { serverId = (await apiJson('/api/user/playlists', 'POST', { name: lp.name })).id; }
      catch (e) { ok = false; if (e.status === 401) return false; continue; }
      for (const id of lp.trackIds || []) {
        let tr = allKnownTracks[id] || likedTracksData[id];
        if (!tr) { try { tr = await apiJson('/api/track-info?id=' + encodeURIComponent(id)); } catch (e) { tr = null; } }
        if (!tr) { ok = false; continue; }
        try { await apiJson(`/api/user/playlists/${serverId}/tracks`, 'POST', tr); } catch (e) { ok = false; }
      }
    }
    return ok;
  }

  async function syncLibrary() {
    let me;
    try { me = await apiJson('/api/me'); } catch (e) { serverMode = false; return; }
    serverMode = true;
    const who = String(me.login || me.id || 'user');
    state.user = { name: me.username || me.login || '', avatar: me.avatar_url || '' };
    try { localStorage.setItem('leaf-user', JSON.stringify(state.user)); } catch (e) {  }
    state.subscription = me.subscription && typeof me.subscription === 'object' ? me.subscription : null;
    czSetAccountBg(me.background_url || '');

    let owner = null;
    try { owner = localStorage.getItem('leaf-cache-owner'); } catch (e) {  }
    const setOwner = () => { try { localStorage.setItem('leaf-cache-owner', who); } catch (e) {  } };
    if (owner && owner !== who) {
      likedTracksData = {}; state.likedTracks = new Set(); userPlaylists = [];
      recents = []; try { localStorage.removeItem('leaf-recent'); } catch (e) {  }
      setOwner();
    } else if (!owner) {
      if (await migrateLegacyLibrary()) setOwner();
    }

    try {
      const d = await apiJson('/api/user/liked?sort=added_desc');
      const map = {};
      const n = (d.tracks || []).length;
      (d.tracks || []).forEach((tr, i) => { map[tr.id] = Object.assign({}, tr, { _ord: n - i }); });
      likedTracksData = map;
      state.likedTracks = new Set(Object.keys(map));
      registerTracks(d.tracks);
      saveLikes();
    } catch (e) {  }

    try {
      const pls = (await apiJson('/api/user/playlists')).playlists || [];
      const loaded = await Promise.all(pls.map(async (p) => {
        try {
          const d = await apiJson(`/api/user/playlists/${p.id}/tracks?sort=added_desc`);
          return { p, tracks: d.tracks || [] };
        } catch (e) { return { p, tracks: null }; }
      }));
      userPlaylists = loaded.map(({ p, tracks }) => {
        const prev = userPlaylists.find((x) => x.id === p.id);
        if (tracks) registerTracks(tracks);
        return { id: String(p.id), name: p.name, trackIds: tracks ? tracks.map((t) => t.id) : (prev ? prev.trackIds : []) };
      });
      saveUserPlaylists();
    } catch (e) {  }
    renderAll();
  }

  async function createUserPlaylist(name) {
    name = (name || '').trim();
    if (!name) return;
    let pl;
    if (!serverMode) {
      try { await apiJson('/api/me'); serverMode = true; } catch (e) {  }
    }
    if (serverMode) {
      try {
        const r = await apiJson('/api/user/playlists', 'POST', { name });
        pl = { id: String(r.id), name: r.name || name, trackIds: [] };
      } catch (e) {
        alert(e.status === 402 || e.status === 403
          ? 'Достигнут лимит плейлистов на вашем тарифе'
          : 'Не удалось создать плейлист на сервере. Проверьте соединение.');
        return;
      }
    } else {
      pl = { id: 'up-' + Date.now() + '-' + Math.floor(Math.random() * 1000), name, trackIds: [] };
    }
    userPlaylists.unshift(pl);
    saveUserPlaylists();
    renderAll();
    return pl;
  }
  async function addTrackToPlaylist(playlistId, trackId) {
    const pl = userPlaylists.find((p) => p.id === playlistId);
    const tr = allKnownTracks[trackId];
    if (!pl || !tr) return;
    const prevIds = pl.trackIds.slice();
    pl.trackIds = pl.trackIds.filter((id) => id !== trackId);
    pl.trackIds.unshift(trackId);
    saveUserPlaylists();
    renderAll();
    if (serverMode && !isLocalPlaylist(pl)) {
      try { await apiJson(`/api/user/playlists/${pl.id}/tracks`, 'POST', tr); }
      catch (e) { pl.trackIds = prevIds; saveUserPlaylists(); renderAll(); }
    }
  }
  async function deleteUserPlaylist(id) {
    const pl = userPlaylists.find((p) => p.id === id);
    if (!pl) return;
    if (!confirm('Удалить плейлист «' + pl.name + '»? Это действие необратимо.')) return;
    if (serverMode && !isLocalPlaylist(pl)) {
      try { await apiJson('/api/user/playlists/' + encodeURIComponent(id), 'DELETE'); } catch (e) { return; }
    }
    userPlaylists = userPlaylists.filter((p) => p.id !== id);
    saveUserPlaylists();
    if (state.view === 'playlist' && state.currentPlaylistId === id) state.view = 'library';
    renderAll();
  }
  async function removeTrackFromPlaylist(plId, trackId) {
    const pl = userPlaylists.find((p) => p.id === plId);
    if (!pl) return;
    const prevIds = pl.trackIds.slice();
    pl.trackIds = pl.trackIds.filter((id) => id !== trackId);
    saveUserPlaylists();
    renderAll();
    if (serverMode && !isLocalPlaylist(pl)) {
      try { await apiJson('/api/user/playlists/' + encodeURIComponent(plId) + '/tracks/' + encodeURIComponent(trackId), 'DELETE'); }
      catch (e) { pl.trackIds = prevIds; saveUserPlaylists(); renderAll(); }
    }
  }
  document.addEventListener('click', (ev) => {
    const del = ev.target.closest && ev.target.closest('[data-del-playlist]');
    const rm = ev.target.closest && ev.target.closest('[data-rm-from-playlist]');
    if (!del && !rm) return;
    ev.stopPropagation(); ev.preventDefault();
    if (del) deleteUserPlaylist(del.getAttribute('data-del-playlist'));
    else removeTrackFromPlaylist(state.currentPlaylistId, rm.getAttribute('data-rm-from-playlist'));
  }, true);
  function openUserPlaylist(id) {
    state.view = 'playlist';
    state.currentPlaylistId = id;
    renderAll();
  }
  function openAddToPlaylist(trackId) {
    state.addToPlaylistTrackId = trackId;
    renderAll();
  }
  function closeAddToPlaylist() {
    state.addToPlaylistTrackId = null;
    renderAll();
  }
  function openCreatePlaylistModal() {
    state.createPlaylistOpen = true;
    renderAll();
  }
  function closeCreatePlaylistModal() {
    state.createPlaylistOpen = false;
    renderAll();
  }

  const root = document.getElementById('root');
  let _lastView = null;
  let _lastLang = null;
  let _lastViewKey = null;
  let _lastModalKey = '';
  let _lastSecs = null;
  let _lastSettingsHtml = null;
  let _lastAvatar = null;
  let _lastPlaylistsHtml = null;
  let recentView = recents.slice(0, 6);

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function filled(svg) { return svg.replace('<svg ', '<svg fill="currentColor" '); }
  function sec(key, html, cls, style) {
    return `<div data-sec="${key}"${cls ? ` class="${cls}"` : ''}${style ? ` style="${style}"` : ''}>${html}</div>`;
  }
  function modalKeyNow() {
    return [
      state.eqOpen ? 'eq' : '',
      state.settingsOpen ? 'settings' : '',
      state.createPlaylistOpen ? 'cp' : '',
      state.accountOpen ? 'account' : '',
      state.addToPlaylistTrackId ? 'atp' : '',
      state.fullOpen ? 'full' : '',
    ].filter(Boolean).join(':');
  }

  function patchView(viewRoot, html, switched, animate) {
    if (!viewRoot) return false;
    const tpl = document.createElement('template');
    tpl.innerHTML = html;
    const newPad = tpl.content.firstElementChild;
    const kids = newPad ? Array.from(newPad.children) : [];
    const secs = kids.map((k) => ({ key: k.getAttribute('data-sec') || '', html: k.outerHTML }));
    const sameShape = !switched && _lastSecs && _lastSecs.length === secs.length
      && secs.every((s, i) => s.key && s.key === _lastSecs[i].key);

    let changed = false;
    if (!sameShape) {
      viewRoot.innerHTML = html;
      changed = true;
    } else {
      const live = viewRoot.firstElementChild ? viewRoot.firstElementChild.children : [];
      secs.forEach((s, i) => {
        if (s.html === _lastSecs[i].html || !live[i]) return;
        const wasEmpty = /^<div[^>]*><\/div>$/.test(_lastSecs[i].html);
        if (!animate && !wasEmpty) kids[i].classList.add('static');
        live[i].replaceWith(kids[i]);
        changed = true;
      });
    }
    _lastSecs = secs;
    return changed;
  }

  function markLoadedImages() {
    root.querySelectorAll('img.cover-img:not(.loaded)').forEach((img) => {
      if (img.complete && img.naturalWidth) img.classList.add('loaded');
    });
  }

  function syncTrackRows() {
    const cur = state.currentTrack ? String(state.currentTrack.id) : null;
    root.querySelectorAll('.track-row').forEach((row) => {
      const id = row.getAttribute('data-play-track');
      const isCur = id === cur;
      row.classList.toggle('current', isCur);
      row.classList.toggle('playing', isCur && state.isPlaying);
      const btn = row.querySelector('.track-like-btn');
      if (btn) setLikedClass(btn, state.likedTracks.has(id), id);
    });
    root.querySelectorAll('.fav-song[data-fav-id]').forEach((el) => {
      const isCur = el.getAttribute('data-fav-id') === cur;
      el.classList.toggle('is-current', isCur);
      el.classList.toggle('is-paused', isCur && !state.isPlaying);
    });
  }
  function setLikedClass(btn, liked, id) {
    const was = btn.classList.contains('liked');
    if (was === liked) return;
    btn.classList.toggle('liked', liked);
    if (liked && _justLiked === id) {
      btn.classList.remove('pop');
      void btn.offsetWidth;
      btn.classList.add('pop');
      btn.addEventListener('animationend', () => btn.classList.remove('pop'), { once: true });
    }
  }

  function afterViewPatch(viewSwitched) {
    syncTrackRows();
    markLoadedImages();
    const si = root.querySelector('#search-input');
    if (si) {
      const wantValue = state.leafMode ? LEAF_PREFIX + (state.leafQuery || '') : (state.searchQuery || '');
      if (document.activeElement !== si && si.value !== wantValue) si.value = wantValue;
      if (viewSwitched && (!document.activeElement || document.activeElement === document.body)) {
        si.focus();
        si.setSelectionRange(si.value.length, si.value.length);
      }
    }
  }

  function renderAll() {
    if (state._rendering) return;
    state._rendering = true;
    try {
      applyRootClasses();

      const modalKey = modalKeyNow();
      const viewKey = state.view
        + (state.view === 'artist' ? ':' + (state.currentArtistName || '') : '')
        + (state.view === 'user' ? ':' + (state.currentUserLogin || '') : '')
        + (state.view === 'playlist' ? ':' + (state.currentPlaylistId || '') : '');
      const langChanged = _lastLang !== null && _lastLang !== state.language;
      const fullRebuild = !root.querySelector('.app') || _lastView === null || langChanged;
      const viewSwitched = _lastViewKey !== viewKey;
      _lastView = state.view;
      _lastViewKey = viewKey;
      const animate = state._animNext;
      state._animNext = false;

      if (viewSwitched && state.view === 'home') recentView = recents.slice(0, 6);

      let keepPanelTop = null;
      if (fullRebuild) {
        const oldScroller = root.querySelector('.content-scroll');
        const keepTop = oldScroller ? oldScroller.scrollTop : 0;
        const oldPanel = root.querySelector('.side-panel-inner');
        if (oldPanel) keepPanelTop = oldPanel.scrollTop;
        const html = document.documentElement;
        if (langChanged) {
          html.classList.add('no-enter');
          requestAnimationFrame(() => requestAnimationFrame(() => html.classList.remove('no-enter')));
        }
        root.innerHTML = `
          <div class="app">
            ${renderWinTitlebar()}
            <div class="app-body">
              ${renderSidebar()}
              <main class="main">
                ${renderTopbar()}
                <div class="content-scroll"><div id="view-root"></div></div>
              </main>
            </div>
            ${renderPlayerBar()}
            ${renderMobileNav()}
          </div>
        `;
        _lastSecs = null; _lastPlaylistsHtml = null; _lastAvatar = null; _pbTrackId = null;
        wireEvents();
        patchView(root.querySelector('#view-root'), renderView(), true, true);
        const newScroller = root.querySelector('.content-scroll');
        if (newScroller && !viewSwitched) newScroller.scrollTop = keepTop;
        updatePlayerBarOnly();
      } else {
        const scroller = root.querySelector('.content-scroll');
        const scrollTop = scroller ? scroller.scrollTop : 0;
        patchView(root.querySelector('#view-root'), renderView(), viewSwitched, animate);
        if (scroller) scroller.scrollTop = viewSwitched ? 0 : scrollTop;
        updatePlayerBarOnly();
      }

      updateSidebarActive();
      renderPlaylistList();
      updateTopbar();
      updateModals(fullRebuild ? '' : _lastModalKey);
      if (keepPanelTop !== null) {
        const newPanel = root.querySelector('.side-panel-inner');
        if (newPanel) newPanel.scrollTop = keepPanelTop;
      }
      _lastModalKey = modalKey;
      _lastLang = state.language;
      afterViewPatch(viewSwitched);
      if (state.eqOpen) drawEqCurve();
    } finally {
      state._rendering = false;
    }
  }

  function updateSidebarActive() {
    root.querySelectorAll('.nav-item').forEach((btn) => {
      btn.classList.toggle('active', state.view === btn.getAttribute('data-nav'));
    });
    root.querySelectorAll('.mobile-nav-item').forEach((btn) => {
      btn.classList.toggle('active', state.view === btn.getAttribute('data-nav'));
    });
    root.querySelectorAll('.desktop-nav [data-nav]').forEach((btn) => {
      btn.classList.toggle('active', state.view === btn.getAttribute('data-nav'));
    });
    root.querySelectorAll('[data-open-playlist].playlist-item').forEach((el) => {
      el.classList.toggle('active', state.view === 'playlist' && el.getAttribute('data-open-playlist') === state.currentPlaylistId);
    });
  }

  function userInitial() {
    const n = state.user && state.user.name ? String(state.user.name).trim() : '';
    return n ? n.charAt(0).toUpperCase() : '';
  }
  function userFirstName() {
    const n = state.user && state.user.name ? String(state.user.name).trim() : '';
    return n ? n.split(/\s+/)[0] : '';
  }

  function updateTopbar() {
    const mobileInput = root.querySelector('[data-mobile-search]');
    if (mobileInput && document.activeElement !== mobileInput) mobileInput.value = state.searchQuery || '';
    root.querySelectorAll('.style-pill [data-style]').forEach((b) => {
      b.classList.toggle('active', b.getAttribute('data-style') === state.style);
    });
    const av = root.querySelector('#avatar-badge');
    const ini = userInitial();
    const pic = state.user && state.user.avatar ? state.user.avatar : '';
    const key = pic || ini;
    if (av && _lastAvatar !== key) {
      _lastAvatar = key;
      av.innerHTML = pic
        ? `<img class="avatar-img" src="${esc(pic)}" alt="" />`
        : (ini ? esc(ini) : icon('user'));
    }
  }

  function removeWithAnim(el) {
    if (!el || el.classList.contains('leaving')) return;
    if (document.documentElement.classList.contains('no-enter')) { el.remove(); return; }
    el.classList.add('leaving');
    const done = () => { if (el.parentNode) el.remove(); };
    el.addEventListener('animationend', (e) => { if (e.target === el) done(); });
    setTimeout(done, el.id === 'modal-backdrop' ? 170 : 450);
  }
  function closeAllModals() {
    state.eqOpen = false;
    state.settingsOpen = false;
    state.createPlaylistOpen = false;
    state.accountOpen = false;
    state.addToPlaylistTrackId = null;
    state.fullOpen = false;
    renderAll();
  }
  const MODAL_KINDS = {
    eq: { sel: '.eq-panel', html: () => renderEqualizer(), wire: () => wireEqEvents() },
    settings: { sel: '.side-panel', html: () => { _lastDevice = state.audioDevice || ''; return renderSettings(); }, wire: () => wireSettingsEvents() },
    cp: { sel: '.mini-modal:not(.acc-modal)', html: () => renderCreatePlaylistModal(), wire: () => { wireCreatePlaylistEvents(); setTimeout(() => { const i = root.querySelector('#create-playlist-input'); if (i) i.focus(); }, 60); } },
    atp: { sel: '.mini-modal:not(.acc-modal)', html: () => renderAddToPlaylistModal(), wire: () => wireAddToPlaylistEvents() },
    account: { sel: '.acc-modal', html: () => renderAccountModal(), wire: () => { wireAccountEvents(); accLoad(); } },
    full: { sel: '.fp', html: () => renderFullPlayer(), wire: () => wireFullPlayer() },
  };

  function updateModals(prevKey) {
    const curKey = modalKeyNow();
    document.documentElement.classList.toggle('modal-open', curKey !== '');
    const app = root.querySelector('.app');
    if (!app) return;

    if (prevKey === curKey) {
      if (state.settingsOpen) patchSettings();
      return;
    }

    const prev = new Set(prevKey ? prevKey.split(':') : []);
    const cur = new Set(curKey ? curKey.split(':') : []);
    const needBack = Array.from(cur).some((k) => k !== 'full');
    const back = root.querySelector('#modal-backdrop:not(.leaving)');
    if (needBack && !back) app.insertAdjacentHTML('beforeend', '<div class="backdrop" id="modal-backdrop"></div>');
    if (!needBack && back) removeWithAnim(back);

    prev.forEach((k) => { if (!cur.has(k)) removeWithAnim(root.querySelector(MODAL_KINDS[k].sel + ':not(.leaving)')); });
    cur.forEach((k) => {
      if (prev.has(k)) return;
      app.insertAdjacentHTML('beforeend', MODAL_KINDS[k].html());
      MODAL_KINDS[k].wire();
    });
  }

  let _winMaximized = false;
  function renderWinTitlebar() {
    const curTrack = state.currentTrack;
    const titleText = curTrack ? `${curTrack.title} — ${curTrack.artist}` : 'Leaf Music';
    return `
      <div class="win-titlebar" id="win-titlebar">
        <div class="win-brand win-no-drag">
          <div class="win-logo-wrap">
            <img class="win-logo-img" src="images/Leaf.png" alt="" onerror="this.style.display='none'" />
          </div>
          <span class="win-brand-text font-display">Leaf</span>
          <span class="win-title-sep"></span>
          <span class="win-title-track truncate" id="win-title-label">${esc(titleText)}</span>
        </div>
        <div class="win-drag-handle"></div>
        <div class="win-controls win-no-drag">
          <button type="button" class="win-btn win-btn-min" id="win-btn-min" title="Свернуть" aria-label="Свернуть">
            <svg viewBox="0 0 10 10"><path d="M0 5h10" stroke="currentColor" stroke-width="1"/></svg>
          </button>
          <button type="button" class="win-btn win-btn-max" id="win-btn-max" title="${_winMaximized ? 'Восстановить' : 'Развернуть'}" aria-label="Развернуть">
            <svg viewBox="0 0 10 10" class="win-ico-max" style="${_winMaximized ? 'display:none' : ''}"><rect x="0.5" y="0.5" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1"/></svg>
            <svg viewBox="0 0 10 10" class="win-ico-restore" style="${_winMaximized ? '' : 'display:none'}"><path d="M2.5 2.5V0.5h7v7H7.5" fill="none" stroke="currentColor" stroke-width="1"/><rect x="0.5" y="2.5" width="7" height="7" fill="none" stroke="currentColor" stroke-width="1"/></svg>
          </button>
          <button type="button" class="win-btn win-btn-close" id="win-btn-close" title="Закрыть" aria-label="Закрыть">
            <svg viewBox="0 0 10 10"><path d="M1 1l8 8M9 1l-8 8" stroke="currentColor" stroke-width="1"/></svg>
          </button>
        </div>
      </div>
    `;
  }

  function renderSidebar() {
    return `
      <aside class="sidebar">
        <div class="glass sidebar-logo">
          <div class="logo-badge"><img class="logo-img" src="images/Leaf.png" alt="" /></div>
          <div>
            <h1 class="sidebar-title font-display text-primary-c">${t('appName')}</h1>
            <p class="sidebar-subtitle text-muted-c">${t('tagline')}</p>
          </div>
        </div>
        <nav class="glass sidebar-nav">
          ${NAV_ITEMS.map((item) => `
            <button class="nav-item ${state.view === item.id ? 'active' : ''}" data-nav="${item.id}">
              <span class="nav-bar"></span>
              ${icon(item.icon, '', '', true)}
              <span>${t(item.key)}</span>
            </button>
          `).join('')}
        </nav>
        <div class="glass sidebar-playlists">
          <button class="create-playlist-btn" id="create-playlist-btn">
            <div class="dashed-box">${icon('plus')}</div>
            ${t('createPlaylist')}
          </button>
          <div class="playlist-list" id="playlist-list"></div>
        </div>
        <button type="button" class="sidebar-sub-btn" id="sub-open-btn">${SUB_ICON_STAR}<span>${t('subBtn')}</span></button>
      </aside>
    `;
  }

  function renderTopbar() {
    return `
      <header class="topbar">
        <div class="glass topbar-inner">
          <div class="mobile-logo">
            <div class="logo-badge"><img class="logo-img" src="images/Leaf.png" alt="" /></div>
            <span class="font-display text-primary-c">${t('appName')}</span>
          </div>
          <div class="glass-subtle mobile-search">
            ${icon('search')}
            <input type="text" placeholder="${t('searchPlaceholder')}" data-mobile-search value="${esc(state.searchQuery)}" />
          </div>
          <div class="desktop-nav">
            <button class="icon-btn glass-subtle" data-nav="home" title="${t('navHome')}">${icon('home', '', '', true)}</button>
            <button class="icon-btn glass-subtle" data-nav="library" title="${t('navLibrary')}">${icon('library', '', '', true)}</button>
          </div>
          <div class="top-lyric" id="top-lyric"></div>
          <div class="right-actions">
            <button class="icon-btn glass-subtle" id="open-settings" title="${t('settings')}">${icon('settings')}</button>
            <div class="avatar-badge" id="avatar-badge" role="button" tabindex="0" title="${t('accTitle')}"></div>
          </div>
        </div>
      </header>
    `;
  }

  function sectionHeader(iconName, title, subtitle) {
    return `
      <div class="section-header">
        <div class="glass-subtle section-icon">${icon(iconName)}</div>
        <div>
          <h2 class="font-display text-primary-c">${title}</h2>
          ${subtitle ? `<p>${subtitle}</p>` : ''}
        </div>
      </div>
    `;
  }

  function trackRowHtml(track, index, extra) {
    const id = esc(track.id);
    return `
      <div class="track-row" data-play-track="${id}" style="--i:${index}">
        <div class="track-index">
          <span class="idx-num">${index + 1}</span>
          <span class="idx-play">${filled(icon('play'))}</span>
          <span class="idx-pause">${filled(icon('pause'))}</span>
          <span class="eq-bars"><span></span><span></span><span></span><span></span></span>
        </div>
        <img class="track-cover cover-img" src="${esc(coverOf(track))}" alt="" loading="lazy" decoding="async" />
        <div class="track-meta">
          <p class="title truncate">${esc(track.title)}</p>
          <div class="artist-row">${sourceBadge(track)}<button class="artist-link" data-artist="${esc(track.artist)}" data-artist-source="${esc(track.source || '')}">${esc(track.artist)}</button></div>
        </div>
        <span class="track-album">${esc(track.genre || '')}</span>
        <button class="track-add-btn" data-add-to-playlist="${id}" title="${t('addToPlaylist')}">${icon('plus')}</button>
        <button class="track-like-btn" data-like-track="${id}">${icon('heart')}</button>
        ${extra || ''}
        <span class="track-duration">${formatTime(track.duration)}</span>
      </div>
    `;
  }

  function sourceBadge(track) {
    const id = String(track.id);
    const f = /^yt_/.test(id) ? 'yt' : (/^ym_/.test(id) ? '' : 'sc');
    return f ? `<img class="track-src" src="images/${f}.png" alt="" title="${f === 'yt' ? 'YouTube Music' : 'SoundCloud'}" />` : '';
  }

  function skeletonRows(n) {
    return Array.from({ length: n }, () => `
      <div class="skeleton-row">
        <div class="sk sk-num"></div>
        <div class="sk sk-cover"></div>
        <div class="sk-lines"><div class="sk sk-line"></div><div class="sk sk-line short"></div></div>
        <div class="sk sk-dur"></div>
      </div>
    `).join('');
  }

  function renderView() {
    if (state.view === 'home') return renderHome();
    if (state.view === 'search') return renderSearch();
    if (state.view === 'library') return renderLibrary();
    if (state.view === 'liked') return renderLiked();
    if (state.view === 'artist') return renderArtistPage();
    if (state.view === 'user') return renderUserProfile();
    if (state.view === 'playlist') return renderUserPlaylist();
    return renderHome();
  }

  function renderArtistPage() {
    const p = artistPage || { name: '', source: '', avatar: '', followers: 0, top: [], all: [], loading: false, error: '', expanded: false };
    const hasTracks = p.top.length || p.all.length;
    let body;
    if (p.loading) {
      body = `<div class="glass tracklist">${skeletonRows(6)}</div>`;
    } else if (!hasTracks) {
      const msg = p.error === 'tier' ? t('srcLockedYt') : p.error === 'fail' ? t('artistLoadFail') : t('artistEmpty');
      body = `<p class="empty-state">${esc(msg)}</p>`;
    } else {
      const collapsed = !p.expanded && p.all.length > ARTIST_COLLAPSED;
      const allShown = collapsed ? p.all.slice(0, ARTIST_COLLAPSED) : p.all;
      body = (p.top.length
          ? `<h2 class="font-display text-primary-c results-title">${t('artistTop')}</h2>
             <div class="glass tracklist artist-block">${p.top.map((tr, i) => trackRowHtml(tr, i)).join('')}</div>` : '')
        + (p.all.length
          ? `<h2 class="font-display text-primary-c results-title">${t('artistAll')}</h2>
             <div class="glass tracklist artist-block">${allShown.map((tr, i) => trackRowHtml(tr, i)).join('')}</div>
             ${p.all.length > ARTIST_COLLAPSED ? `<button class="show-more-btn glass-subtle" data-artist-expand>${p.expanded ? t('artistCollapse') : t('artistExpand')}</button>` : ''}` : '');
    }
    const srcFile = p.source === 'ytmusic' ? 'yt' : p.source === 'soundcloud' ? 'sc' : '';
    const srcLabel = p.source === 'ytmusic' ? 'YouTube Music' : p.source === 'soundcloud' ? 'SoundCloud' : '';
    const followers = p.followers > 0
      ? new Intl.NumberFormat(state.language).format(p.followers) + ' ' + t('followers') : '&nbsp;';
    return `
      <div class="view-pad">
        ${sec('hero', `
          <div class="liked-hero artist-hero">
            <div class="artist-avatar-wrap">
              <div class="artist-photo glass">
                <img src="${DEFAULT_AVATAR}" alt="" />
                ${p.avatar ? `<img class="artist-photo-real" src="${esc(p.avatar)}" alt="" referrerpolicy="no-referrer" onerror="this.remove()" />` : ''}
              </div>
              <button class="artist-back" data-artist-back title="${t('artistBack')}" aria-label="${t('artistBack')}">${icon('chevronLeft', '', '', true)}</button>
            </div>
            <div style="min-width:0;flex:1;">
              <p class="eyebrow artist-eyebrow">${srcFile ? `<img class="track-src" src="images/${srcFile}.png" alt="" /><span>${srcLabel}</span>` : t('tracksByArtist')}</p>
              <h1 class="font-display text-primary-c truncate">${esc(p.name)}</h1>
              <p class="count">${followers}</p>
            </div>
          </div>`, 'animate-fade-in-up')}
        ${sec('list', body, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function renderUserPlaylist() {
    const pl = userPlaylists.find((p) => p.id === state.currentPlaylistId);
    if (!pl) return `<div class="view-pad">${sec('empty', `<p class="empty-state">${t('noPlaylistsYet')}</p>`)}</div>`;
    const cover = playlistCover(pl);
    const plTracks = pl.trackIds.map((id) => allKnownTracks[id]).filter(isPlayableTrack);
    const rm = (track) => `<button class="track-add-btn" data-rm-from-playlist="${esc(track.id)}" title="${t('removeFromPlaylist')}">${icon('x')}</button>`;
    return `
      <div class="view-pad">
        ${sec('hero', `
          <div class="liked-hero">
            <div class="artist-photo glass" style="width:6rem;height:6rem;border-radius:0.75rem;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#52525b,#18181b);color:rgba(255,255,255,.75);">
              ${cover ? `<img class="cover-img" src="${esc(cover)}" alt="" />` : icon('music', 'big')}
            </div>
            <div style="min-width:0;flex:1;">
              <p class="eyebrow">${t('playlistWord')}</p>
              <h1 class="font-display text-primary-c truncate">${esc(pl.name)}</h1>
              <p class="count">${plTracks.length} ${t('tracks')}</p>
            </div>
            <button class="glass-subtle close-btn" data-del-playlist="${esc(pl.id)}" title="${t('deletePlaylist')}">${icon('trash')}</button>
          </div>`, 'animate-fade-in-up')}
        ${sec('list', `<div class="glass tracklist">${
          plTracks.length === 0
            ? `<p class="empty-state">${t('emptyPlaylist')}</p>`
            : plTracks.map((track, i) => trackRowHtml(track, i, rm(track))).join('')
        }</div>`, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function greetingKeyNow() {
    const h = new Date().getHours();
    if (h >= 5 && h < 12) return 'Morning';
    if (h >= 12 && h < 18) return 'Day';
    if (h >= 18 && h < 23) return 'Evening';
    return 'Night';
  }
  function greetingText() { return t('greeting' + greetingKeyNow()); }
  function todayLabel() {
    const loc = { ru: 'ru-RU', pl: 'pl-PL', en: 'en-US' }[state.language] || 'en-US';
    try { return new Date().toLocaleDateString(loc, { weekday: 'long', day: 'numeric', month: 'long' }); } catch (e) { return ''; }
  }

  function quickCardHtml(opts) {
    return `
      <button class="glass quick-card" ${opts.open}>
        <div class="quick-cover ${opts.liked ? 'liked' : ''}">
          ${opts.cover ? `<img class="cover-img" src="${esc(opts.cover)}" alt="" />` : icon(opts.icon, opts.liked ? 'solid' : '')}
        </div>
        <div class="quick-meta">
          <span class="name truncate text-primary-c">${esc(opts.name)}</span>
          <span class="sub truncate">${opts.count} ${t('tracks')}</span>
        </div>
        <span class="quick-play" data-play-collection="${esc(opts.collection)}">${filled(icon('play'))}</span>
      </button>
    `;
  }

  function renderHome() {
    const name = userFirstName();
    const hero = `
      <div class="hero">
        <p class="eyebrow">${esc(todayLabel())}</p>
        <h1 class="font-display text-primary-c">${esc(greetingText())}${name ? ', ' + esc(name) : ''}</h1>
      </div>`;

    const likedCount = likedList().filter(isPlayableTrack).length;
    let quick = '';
    if (likedCount || userPlaylists.length) {
      const cards = [];
      cards.push(quickCardHtml({ open: 'data-open-liked', liked: true, icon: 'heart', name: t('likedSongs'), count: likedCount, collection: 'liked', cover: LIKES_COVER }));
      userPlaylists.slice(0, 5).forEach((pl) => {
        cards.push(quickCardHtml({
          open: `data-open-playlist="${esc(pl.id)}"`, icon: 'music', name: pl.name,
          count: pl.trackIds.length, collection: pl.id, cover: playlistCover(pl),
        }));
      });
      quick = `<div class="quick-grid">${cards.join('')}</div>`;
    }

    let recent = '';
    if (recentView.length) {
      recent = sectionHeader('clock', t('recentlyPlayed'), t('recentSub')) + `
        <div class="recent-grid">
          ${recentView.map((tr) => `
            <button class="recent-card" data-play-recent="${esc(tr.id)}">
              <div class="recent-cover">
                <img class="cover-img" src="${esc(coverOf(tr))}" alt="" loading="lazy" decoding="async" />
                <span class="recent-play">${filled(icon('play'))}</span>
              </div>
              <p class="title truncate">${esc(tr.title)}</p>
              <p class="artist truncate">${esc(tr.artist)}</p>
            </button>
          `).join('')}
        </div>`;
    }

    let popular;
    if (!tracks.length && state.homeStatus === 'loading') {
      popular = `<div class="glass tracklist">${skeletonRows(8)}</div>`;
    } else if (!tracks.length) {
      popular = `<div class="glass tracklist"><p class="empty-state">${t('loadFailed')}<br><button class="glass-subtle retry-btn" data-retry-home>${t('retry')}</button></p></div>`;
    } else {
      const limit = state.homeExpanded ? tracks.length : Math.min(10, tracks.length);
      popular = `
        <div class="glass tracklist">${tracks.slice(0, limit).map((tr, i) => trackRowHtml(tr, i)).join('')}</div>
        ${tracks.length > 10 ? `<button class="show-more-btn glass-subtle" data-home-toggle>${state.homeExpanded ? t('showLess') : t('showAll')}</button>` : ''}`;
    }
    popular = sectionHeader('trendingUp', t('popularNow'), t('popularSub')) + popular;

    return `
      <div class="view-pad">
        ${sec('hero', hero, 'animate-fade-in-up')}
        ${sec('quick', quick, 'animate-fade-in-up', 'animation-delay:.06s')}
        ${sec('recent', recent, 'animate-fade-in-up', 'animation-delay:.12s')}
        ${sec('popular', popular, 'animate-fade-in-up', 'animation-delay:.18s')}
      </div>
    `;
  }

  function renderSourceFilter() {
    const btn = (id, label, file, locked) =>
      `<button class="source-btn${state.searchSource === id ? ' active' : ''}${locked ? ' locked' : ''}" data-search-source="${id}"${locked ? ` title="${esc(t('srcLockedYt'))}"` : ''}>`
      + (file ? `<img class="track-src" src="images/${file}.png" alt="" />` : '') + `<span>${label}</span></button>`;
    return `<div class="source-row">${btn('all', t('srcAll'), '', false)}${btn('ytmusic', 'YouTube Music', 'yt', ytSourceLocked())}${btn('soundcloud', 'SoundCloud', 'sc', false)}</div>`;
  }

  function renderArtistStrip() {
    if (!searchArtists.length) return '';
    return `
      <div class="artist-strip-wrap">
        <h2 class="font-display text-primary-c results-title">${t('artistsWord')}</h2>
        <div class="artist-strip">${searchArtists.map((a) => `
          <button class="artist-strip-item" data-open-artist-id="${esc(a.id)}" data-open-artist-src="${esc(a.source)}" data-open-artist-name="${esc(a.name)}" data-open-artist-avatar="${esc(a.avatar_url || '')}">
            <span class="artist-strip-avatar">${icon('music', '', '', true)}${a.avatar_url ? `<img src="${esc(a.avatar_url)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()" />` : ''}</span>
            <span class="artist-strip-name truncate">${esc(a.name)}</span>
            <img class="track-src" src="images/${a.source === 'ytmusic' ? 'yt' : 'sc'}.png" alt="" title="${a.source === 'ytmusic' ? 'YouTube Music' : 'SoundCloud'}" />
          </button>`).join('')}
        </div>
      </div>`;
  }

  function leafMix(hex, other, share) {
    const a = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
    const b = [1, 3, 5].map((i) => parseInt(other.slice(i, i + 2), 16));
    return '#' + a.map((v, i) => Math.round(v * share + b[i] * (1 - share)).toString(16).padStart(2, '0')).join('');
  }
  function leafCustomColor(u) {
    const theme = u.theme || 'green';
    if (theme !== 'custom' && theme !== 'gradient') return null;
    return czHex(String(u.theme_color || '').split('|')[0]);
  }
  function leafUserAccent(u) { return leafCustomColor(u) || LEAF_THEME_COLORS[u.theme || 'green'] || LEAF_THEME_COLORS.green; }
  function leafUserBack(u) {
    const c = leafCustomColor(u);
    return c ? leafMix(c, '#141414', 0.55) : (LEAF_THEME_BACK[u.theme || 'green'] || LEAF_THEME_BACK.green);
  }
  function leafUserAvatarStyle(u) {
    const a = leafUserAccent(u);
    const r = parseInt(a.slice(1, 3), 16), g = parseInt(a.slice(3, 5), 16), b = parseInt(a.slice(5, 7), 16);
    return `background:${leafUserBack(u)};color:#0a0a0a;box-shadow:0 2px 8px rgba(0,0,0,.3),0 0 0 2px rgba(${r},${g},${b},.35);`;
  }
  function leafUserRow(u) {
    const name = String(u.username || u.login || '?');
    const accent = leafUserAccent(u);
    return `
      <div class="leaf-user-item${u.login ? ' clickable' : ''}"${u.login ? ` data-open-user="${esc(u.login)}"` : ''}>
        <span class="leaf-user-avatar" style="${leafUserAvatarStyle(u)}">
          <span class="leaf-user-initial">${esc(name.charAt(0).toUpperCase())}</span>
          ${u.avatar_url ? `<img src="${esc(u.avatar_url)}" alt="" loading="lazy" onerror="this.remove()" />` : ''}
        </span>
        <div class="leaf-user-name-row">
          <span class="leaf-user-name truncate">${esc(name)}</span>
          ${u.verified ? `<span class="leaf-user-verified" style="background:${accent};" title="${esc(t('leafVerified'))}">${icon('check', '', '', true)}</span>` : ''}
        </div>
        <span class="leaf-user-chevron">${icon('chevronRight', '', '', true)}</span>
      </div>`;
  }
  function renderLeafUsers() {
    if (leafStatus === 'error') return `<p class="empty-state">${t('leafUsersError')}</p>`;
    if (!leafUsers.length) {
      return leafStatus === 'ok' ? `<p class="empty-state">${t('leafUsersEmpty')}</p>` : `<div class="glass tracklist">${skeletonRows(5)}</div>`;
    }
    return `<div class="glass leaf-users">${leafUsers.map(leafUserRow).join('')}</div>`;
  }

  function renderSearch() {
    let results;
    if (state.leafMode) {
      results = renderLeafUsers();
    } else if (state.searchLoading && !searchResults.length) {
      results = `<div class="glass tracklist">${skeletonRows(8)}</div>`;
    } else if (searchResults.length) {
      results = `
        <h2 class="font-display text-primary-c results-title">${t('resultsFor')} «${esc(state.searchQuery)}»</h2>
        <div class="glass tracklist ${state.searchLoading ? 'list-loading' : ''}">${searchResults.map((track, i) => trackRowHtml(track, i)).join('')}</div>
        ${state.searchHasMore ? `
          <button class="show-more-btn glass-subtle" id="search-show-more" ${state.searchLoadingMore ? 'disabled' : ''}>
            ${state.searchLoadingMore ? t('loadingMore') : t('showMore')}
          </button>` : ''}`;
    } else if (state.searchError) {
      results = `<p class="empty-state">${esc(state.searchError)}</p>`;
    } else if (state.searchQuery) {
      results = `<p class="empty-state">${t('noResults')}</p>`;
    } else {
      results = `
        <p class="empty-state" style="padding-bottom:1rem;">${t('searchHint')}</p>
        <button class="leaf-hint glass-subtle" data-leaf-hint>
          <span class="leaf-hint-ic">${icon('leaf', '', '', true)}</span>
          <span>${t('leafHintPre')} <b>leaf:</b> ${t('leafHintPost')}</span>
        </button>`;
    }
    return `
      <div class="view-pad search-view">
        ${sec('head', `
          <h1 class="font-display text-primary-c page-title">${t('search')}</h1>
          <div class="glass search-box">
            ${icon('search')}
            <input type="text" id="search-input" placeholder="${t('searchPlaceholderFull')}" autocomplete="off" spellcheck="false" />
          </div>`, 'animate-fade-in-up')}
        ${sec('sources', state.leafMode ? '' : renderSourceFilter(), 'animate-fade-in-up', 'animation-delay:.04s')}
        ${sec('artists', state.leafMode ? '' : renderArtistStrip())}
        ${sec('results', results, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function collectionCard(opts) {
    return `
      <button class="playlist-card glass" ${opts.open}>
        <div class="cover-wrap">
          ${opts.cover
            ? `<img class="cover-img" src="${esc(opts.cover)}" alt="" loading="lazy" decoding="async" />`
            : `<div class="cover-fallback ${opts.liked ? 'liked' : ''}">${icon(opts.icon, opts.liked ? 'solid' : '')}</div>`}
          <div class="grad"></div>
          <div class="info">
            <p class="name font-display truncate">${esc(opts.name)}</p>
            <p class="count">${opts.count} ${t('tracks')}</p>
          </div>
          <span class="play-fab" data-play-collection="${esc(opts.collection)}">${filled(icon('play'))}</span>
        </div>
      </button>
    `;
  }

  function renderLibrary() {
    const likedCount = likedList().filter(isPlayableTrack).length;
    const cards = [
      collectionCard({ open: 'data-open-liked', liked: true, icon: 'heart', name: t('likedSongs'), count: likedCount, collection: 'liked', cover: LIKES_COVER }),
      ...userPlaylists.map((pl) => collectionCard({
        open: `data-open-playlist="${esc(pl.id)}"`, icon: 'music', name: pl.name,
        count: pl.trackIds.length, collection: pl.id, cover: playlistCover(pl),
      })),
      `<button class="playlist-card create-card" data-create-playlist>${icon('plus')}<span>${t('createPlaylist')}</span></button>`,
    ];
    return `
      <div class="view-pad">
        ${sec('head', `<h1 class="font-display text-primary-c page-title" style="margin:0;">${t('yourLibrary')}</h1>`, 'animate-fade-in-up')}
        ${sec('grid', `<div class="card-grid">${cards.join('')}</div>`, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function renderLiked() {
    const liked = likedList().filter(isPlayableTrack);
    return `
      <div class="view-pad">
        ${sec('hero', `
          <div class="liked-hero">
            <div class="icon-box"><img class="cover-img" src="${LIKES_COVER}" alt="" /></div>
            <div>
              <p class="eyebrow">${t('playlistWord')}</p>
              <h1 class="font-display text-primary-c">${t('likedSongs')}</h1>
              <p class="count">${liked.length} ${t('tracks')}</p>
            </div>
          </div>`, 'animate-fade-in-up')}
        ${sec('list', `<div class="glass tracklist">${
          liked.length === 0
            ? `<p class="empty-state">${t('noLiked')}</p>`
            : liked.map((track, i) => trackRowHtml(track, i)).join('')
        }</div>`, 'animate-fade-in-up', 'animation-delay:.08s')}
      </div>
    `;
  }

  function renderPlayerBar() {
    const track = state.currentTrack;
    return `
      <div class="player-wrap">
        <div class="player-inner">

          <div class="cloud-player player-bar animate-fade-in-up">
            <div class="player-row">
              <div class="now-playing">
                <img src="${esc(track ? coverOf(track) : DEFAULT_TRACK_COVER)}" alt="" />
                <div class="meta">
                  <p class="title text-primary-c truncate">${track ? esc(track.title) : t('nothingPlaying')}</p>
                  ${track
                    ? `<div class="artist-row">${sourceBadge(track)}<button class="artist truncate artist-link" data-artist="${esc(track.artist)}" data-artist-source="${esc(track.source || '')}">${esc(track.artist)}</button></div>`
                    : `<p class="artist truncate">—</p>`}
                </div>
                <button class="like-btn" id="player-like">${icon('heart')}</button>
              </div>

              <div class="player-center">
                <div class="transport">
                  <button class="shuffle-btn" id="btn-shuffle">${icon('shuffle')}</button>
                  <button id="btn-prev">${filled(icon('skipBack'))}</button>
                  <button class="play-btn" id="btn-playpause">${filled(icon('play'))}</button>
                  <button id="btn-next">${filled(icon('skipForward'))}</button>
                  <button class="repeat-btn" id="btn-repeat">${icon('repeat')}</button>
                </div>
                <div class="seek-row">
                  <span class="seek-time start">0:00</span>
                  <div class="seek-track" id="seek-track">
                    <div class="track-bg"><div class="track-fill"><span class="thumb"></span></div></div>
                  </div>
                  <span class="seek-time end">0:00</span>
                </div>
              </div>

              <div class="player-right">
                <button id="open-eq" title="${t('equalizerTitle')}">${icon('sliders')}</button>
                <div class="volume-group">
                  ${icon('volume2')}
                  <div class="volume-track" id="volume-track">
                    <div class="volume-bg"><div class="volume-fill"><span class="volume-thumb"></span></div></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderMobileNav() {
    return `
      <nav class="mobile-nav">
        <div class="glass mobile-nav-inner">
          ${NAV_ITEMS.map((item) => `
            <button class="mobile-nav-item ${state.view === item.id ? 'active' : ''}" data-nav="${item.id}">
              ${icon(item.icon, '', '', true)}
              <span>${t(item.key)}</span>
            </button>
          `).join('')}
        </div>
      </nav>
    `;
  }

  function toggleHtml(id, on) {
    return `<button class="toggle ${on ? 'on' : ''}" id="${id}"><span class="knob"></span></button>`;
  }

  function renderSettingsInner() {
    return `
        <div class="glass-strong side-panel-inner">
          <div class="panel-header">
            <div class="left">
              <div class="glass-subtle icon-box">${icon('settings', '', '', true)}</div>
              <div>
                <h2 class="font-display text-primary-c">${t('settings')}</h2>
                <p>${t('personalize')}</p>
              </div>
            </div>
            <button class="glass-subtle close-btn" id="close-settings">${icon('x')}</button>
          </div>
          <div class="st-layout"><div class="st-content">${renderCustomizeBlock()}</div></div>
        </div>
    `;
  }
  function renderSettings() {
    return `<div class="side-panel">${renderSettingsInner()}</div>`;
  }
  let _lastDevice = null;
  function patchSettings() {
    const panel = root.querySelector('.side-panel:not(.leaving)');
    if (!panel) return;
    if (_lastDevice !== null && _lastDevice !== (state.audioDevice || '')) {
      const html = renderSettingsInner();
      const inner = panel.querySelector('.side-panel-inner');
      const sc = panel.querySelector('.st-content');
      const st = sc ? sc.scrollTop : 0;
      if (inner) inner.outerHTML = html;
      const nsc = panel.querySelector('.st-content');
      if (nsc) nsc.scrollTop = st;
    } else {
      const gl = panel.querySelector('#st-glass');
      if (gl) gl.classList.toggle('on', state.glassBlur);
      panel.querySelectorAll('[data-color-theme]').forEach((el) => el.classList.toggle('selected', el.getAttribute('data-color-theme') === state.colorTheme));
      panel.querySelectorAll('[data-lang]').forEach((el) => el.classList.toggle('active', el.getAttribute('data-lang') === state.language));
      panel.querySelectorAll('[data-style]').forEach((el) => el.classList.toggle('active', el.getAttribute('data-style') === state.style));
      const row = panel.querySelector('.settings-card .setting-row');
      if (row) {
        const ic = row.querySelector('.row-icon');
        const want = state.style === 'dark' ? 'moon' : 'sun';
        if (ic && ic.dataset.ico !== want) { ic.dataset.ico = want; ic.innerHTML = icon(want); }
        const d = row.querySelector('.desc');
        const txt = state.style === 'dark' ? t('darkMode') : t('lightMode');
        if (d && d.textContent !== txt) d.textContent = txt;
      }
    }
    _lastDevice = state.audioDevice || '';
  }

  function fmtDb(v) { return (v > 0 ? '+' : '') + v; }
  function sliderHtml(attrs, cls, min, max, step, value) {
    const p = max > min ? (value - min) / (max - min) : 0;
    return `<div class="eq-slider ${cls}" ${attrs} data-min="${min}" data-max="${max}" data-step="${step}" data-value="${value}" style="--p:${p}" tabindex="0" role="slider" aria-valuemin="${min}" aria-valuemax="${max}" aria-valuenow="${value}"><div class="eq-slider-track"><div class="eq-slider-fill"></div><div class="eq-slider-thumb"></div></div></div>`;
  }
  function setSlider(el, v) {
    const min = Number(el.dataset.min), max = Number(el.dataset.max);
    v = Math.max(min, Math.min(max, v));
    el.dataset.value = String(v);
    el.style.setProperty('--p', String(max > min ? (v - min) / (max - min) : 0));
    el.setAttribute('aria-valuenow', String(v));
  }
  function markCustomPreset() {
    if (eqState.activePreset === 'Custom') return;
    eqState.activePreset = 'Custom';
    root.querySelectorAll('[data-eq-preset], [data-eq-user]').forEach((el) => el.classList.remove('active'));
  }
  function onEqSlide(el, v) {
    if (el.hasAttribute('data-eq-band')) {
      const i = Number(el.getAttribute('data-eq-band'));
      if (eqState.bands[i] === v) return;
      eqState.bands[i] = v;
      markCustomPreset();
      const lab = root.querySelector(`[data-eq-db="${i}"]`);
      if (lab) lab.textContent = fmtDb(v);
    } else if (el.id === 'eq-bass-boost') {
      if (eqState.bassBoost === v) return;
      eqState.bassBoost = v;
      const bv = root.querySelector('#eq-bass-val');
      if (bv) bv.textContent = `+${v} dB`;
    } else if (el.id === 'eq-reverb') {
      if (eqState.reverb === v) return;
      eqState.reverb = v;
      const rv = root.querySelector('#eq-reverb-val');
      if (rv) rv.textContent = `${v}%`;
    } else return;
    applyEqToGraph();
    scheduleEqCurve();
  }
  function slideTo(el, ev) {
    const track = el.querySelector('.eq-slider-track');
    const r = track.getBoundingClientRect();
    const vertical = el.classList.contains('vertical');
    const len = vertical ? r.height : r.width;
    if (!len) return;
    const raw = vertical ? (r.bottom - ev.clientY) / len : (ev.clientX - r.left) / len;
    const p = Math.max(0, Math.min(1, raw));
    const min = Number(el.dataset.min), max = Number(el.dataset.max), step = Number(el.dataset.step) || 1;
    let v = Math.round((min + p * (max - min)) / step) * step;
    v = Math.max(min, Math.min(max, Number(v.toFixed(2))));
    setSlider(el, v);
    el.style.setProperty('--p', String(p));
    onEqSlide(el, v);
  }
  let _eqCurveRaf = 0;
  function scheduleEqCurve() {
    if (_eqCurveRaf) return;
    _eqCurveRaf = requestAnimationFrame(() => { _eqCurveRaf = 0; drawEqCurve(); });
  }
  function eqPresetPillsHtml() {
    const builtin = Object.keys(EQ_PRESETS).map((p) => `
      <button class="preset-pill glass-subtle ${eqState.activePreset === p ? 'active' : ''}" data-eq-preset="${esc(p)}">${esc(p)}</button>
    `).join('');
    const names = Object.keys(eqCustom);
    const mine = names.length
      ? `<p class="lbl eq-mine">${t('myPresets')}</p><div class="preset-pills">${names.map((n) => `
          <div class="preset-user">
            <button class="preset-pill glass-subtle ${eqState.activePreset === 'u:' + n ? 'active' : ''}" data-eq-user="${esc(n)}">${esc(n)}</button>
            <button class="preset-del" data-eq-del="${esc(n)}" title="${t('deletePreset')}">${icon('x')}</button>
          </div>
        `).join('')}</div>`
      : '';
    return `<div class="preset-pills">${builtin}</div>${mine}`;
  }
  function refreshPresetArea() {
    const area = root.querySelector('#eq-preset-area');
    if (area) area.innerHTML = eqPresetPillsHtml();
  }

  function renderEqualizer() {
    return `
      <div class="eq-panel">
        <div class="glass-strong eq-panel-inner">
          <div class="panel-header">
            <div class="left">
              <div class="glass-subtle icon-box">${icon('sliders')}</div>
              <div>
                <h2 class="font-display text-primary-c">${t('equalizer')}</h2>
                <p>${t('shapeSound')}</p>
              </div>
            </div>
            <div style="display:flex; align-items:center; gap:.5rem;">
              <button class="glass-subtle reset-btn" id="eq-reset">${icon('rotateCcw')}</button>
              <button class="glass-subtle close-btn" id="close-eq">${icon('x')}</button>
            </div>
          </div>

          <div class="glass-subtle eq-enable-row">
            <span class="text-primary-c">${t('equalizer')}</span>
            ${toggleHtml('eq-enable-toggle', eqState.enabled)}
          </div>

          <div class="glass-subtle eq-canvas-wrap">
            <canvas id="eq-canvas"></canvas>
          </div>

          <div class="eq-bands ${eqState.enabled ? '' : 'disabled'}">
            ${EQ_BANDS.map((_, i) => `
              <div class="eq-band-col">
                <span class="eq-db" data-eq-db="${i}">${fmtDb(eqState.bands[i])}</span>
                ${sliderHtml(`data-eq-band="${i}"`, 'vertical', -12, 12, 0.5, eqState.bands[i])}
                <span>${EQ_BAND_LABELS[i]}</span>
              </div>
            `).join('')}
          </div>

          <div class="eq-presets">
            <p class="lbl">${t('presets')}</p>
            <div id="eq-preset-area">${eqPresetPillsHtml()}</div>
            <form class="eq-save" id="eq-save-form">
              <input type="text" id="eq-save-name" class="eq-save-input" placeholder="${t('presetNamePlaceholder')}" maxlength="24" autocomplete="off" />
              <button type="submit" class="eq-save-btn">${t('savePreset')}</button>
            </form>
          </div>

          <div class="eq-effects ${eqState.enabled ? '' : 'disabled'}">
            <div class="glass-subtle eq-effect-card">
              <div class="head"><span class="label text-primary-c">${t('bassBoost')}</span><span class="val" id="eq-bass-val">+${eqState.bassBoost} dB</span></div>
              ${sliderHtml('id="eq-bass-boost"', 'horizontal', 0, 12, 0.5, eqState.bassBoost)}
            </div>
            <div class="glass-subtle eq-effect-card">
              <div class="head"><span class="label text-primary-c">${t('reverb')}</span><span class="val" id="eq-reverb-val">${eqState.reverb}%</span></div>
              ${sliderHtml('id="eq-reverb"', 'horizontal', 0, 100, 1, eqState.reverb)}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function syncEqPanel() {
    const panel = root.querySelector('.eq-panel:not(.leaving)');
    if (!panel) return;
    panel.querySelectorAll('[data-eq-band]').forEach((el) => {
      setSlider(el, eqState.bands[Number(el.getAttribute('data-eq-band'))]);
    });
    panel.querySelectorAll('[data-eq-preset]').forEach((el) => {
      el.classList.toggle('active', el.getAttribute('data-eq-preset') === eqState.activePreset);
    });
    panel.querySelectorAll('[data-eq-user]').forEach((el) => {
      el.classList.toggle('active', 'u:' + el.getAttribute('data-eq-user') === eqState.activePreset);
    });
    panel.querySelectorAll('[data-eq-db]').forEach((el) => {
      el.textContent = fmtDb(eqState.bands[Number(el.getAttribute('data-eq-db'))]);
    });
    const tog = panel.querySelector('#eq-enable-toggle');
    if (tog) tog.classList.toggle('on', eqState.enabled);
    const bands = panel.querySelector('.eq-bands');
    if (bands) bands.classList.toggle('disabled', !eqState.enabled);
    const fx = panel.querySelector('.eq-effects');
    if (fx) fx.classList.toggle('disabled', !eqState.enabled);
    const bass = panel.querySelector('#eq-bass-boost');
    if (bass) setSlider(bass, eqState.bassBoost);
    const reverb = panel.querySelector('#eq-reverb');
    if (reverb) setSlider(reverb, eqState.reverb);
    const bv = panel.querySelector('#eq-bass-val'); if (bv) bv.textContent = `+${eqState.bassBoost} dB`;
    const rv = panel.querySelector('#eq-reverb-val'); if (rv) rv.textContent = `${eqState.reverb}%`;
    drawEqCurve();
  }

  function drawEqCurve() {
    const canvas = document.getElementById('eq-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = { width: canvas.clientWidth, height: canvas.clientHeight };
    const bw = Math.round(rect.width * dpr), bh = Math.round(rect.height * dpr);
    if (canvas.width !== bw || canvas.height !== bh) { canvas.width = bw; canvas.height = bh; }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const w = rect.width, h = rect.height;
    ctx.clearRect(0, 0, w, h);

    ctx.strokeStyle = 'rgba(148,163,184,0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (h / 4) * i;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(148,163,184,0.2)';
    ctx.beginPath(); ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2); ctx.stroke();

    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
    const bands = eqState.bands;

    function curvePath() {
      ctx.beginPath();
      bands.forEach((gain, i) => {
        const x = (w / (bands.length - 1)) * i;
        const y = h / 2 - (gain / 12) * (h / 2);
        if (i === 0) ctx.moveTo(x, y);
        else {
          const prevX = (w / (bands.length - 1)) * (i - 1);
          const prevGain = bands[i - 1];
          const prevY = h / 2 - (prevGain / 12) * (h / 2);
          const cpX = (prevX + x) / 2;
          ctx.bezierCurveTo(cpX, prevY, cpX, y, x, y);
        }
      });
    }

    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    bands.forEach((gain, i) => {
      const x = (w / (bands.length - 1)) * i;
      const y = h / 2 - (gain / 12) * (h / 2);
      if (i === 0) ctx.lineTo(x, y);
      else {
        const prevX = (w / (bands.length - 1)) * (i - 1);
        const prevGain = bands[i - 1];
        const prevY = h / 2 - (prevGain / 12) * (h / 2);
        const cpX = (prevX + x) / 2;
        ctx.bezierCurveTo(cpX, prevY, cpX, y, x, y);
      }
    });
    ctx.lineTo(w, h / 2);
    ctx.closePath();
    let a1 = accent + '40', a0 = accent + '00';
    if (accent.startsWith('rgb')) { a1 = accent; a0 = accent; }
    const gradient = ctx.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, hexAlpha(accent, 0.25));
    gradient.addColorStop(1, hexAlpha(accent, 0));
    ctx.fillStyle = gradient;
    ctx.fill();

    curvePath();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = accent;
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;

    bands.forEach((gain, i) => {
      const x = (w / (bands.length - 1)) * i;
      const y = h / 2 - (gain / 12) * (h / 2);
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = accent;
      ctx.fill();
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    });
  }
  function hexAlpha(color, alpha) {
    if (/^#([0-9a-f]{6})$/i.test(color)) {
      const num = parseInt(color.slice(1), 16);
      const r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
      return `rgba(${r},${g},${b},${alpha})`;
    }
    return color;
  }


  function wireEvents() {
    wireWinTitlebarEvents();
    wireNavEvents();
    wireStyleEvents();
    wirePlayerEvents();
    wireViewEvents();
    wireSidebarEvents();
  }

  function wireWinTitlebarEvents() {
    const bar = document.getElementById('win-titlebar');
    if (!bar) return;
    // Нативное перетаскивание окна (WM_NCLBUTTONDOWN/HTCAPTION): DWM двигает окно
    // на частоте монитора (144 Гц), без пересылки каждого mousemove в Python.
    bar.addEventListener('mousedown', (e) => {
      if (e.button !== 0 || e.detail > 1) return;
      if (e.target.closest('.win-no-drag')) return;
      if (window.pywebview && window.pywebview.api && window.pywebview.api.win_start_drag) {
        window.pywebview.api.win_start_drag();
      }
    });
    bar.addEventListener('dblclick', (e) => {
      if (e.target.closest('.win-no-drag')) return;
      toggleWinMaximize();
    });
    const bMin = document.getElementById('win-btn-min');
    if (bMin) {
      bMin.addEventListener('click', (e) => {
        e.stopPropagation();
        if (window.pywebview && window.pywebview.api && window.pywebview.api.win_minimize) {
          window.pywebview.api.win_minimize();
        }
      });
    }
    const bMax = document.getElementById('win-btn-max');
    if (bMax) {
      bMax.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleWinMaximize();
      });
    }
    const bClose = document.getElementById('win-btn-close');
    if (bClose) {
      bClose.addEventListener('click', (e) => {
        e.stopPropagation();
        if (window.pywebview && window.pywebview.api && window.pywebview.api.win_close) {
          window.pywebview.api.win_close();
        }
      });
    }
  }

  function toggleWinMaximize() {
    _winMaximized = !_winMaximized;
    const maxIco = document.querySelector('.win-ico-max');
    const restoreIco = document.querySelector('.win-ico-restore');
    if (maxIco && restoreIco) {
      maxIco.style.display = _winMaximized ? 'none' : 'block';
      restoreIco.style.display = _winMaximized ? 'block' : 'none';
    }
    const btn = document.getElementById('win-btn-max');
    if (btn) btn.title = _winMaximized ? 'Восстановить' : 'Развернуть';
    document.documentElement.classList.toggle('win-maximized', _winMaximized);
    if (window.pywebview && window.pywebview.api && window.pywebview.api.win_toggle_maximize) {
      window.pywebview.api.win_toggle_maximize();
    }
  }

  function wireNavEvents() {
    root.querySelectorAll('[data-nav]').forEach((el) => {
      el.addEventListener('click', () => { state.view = el.getAttribute('data-nav'); renderAll(); });
    });
    const mobileSearch = root.querySelector('[data-mobile-search]');
    if (mobileSearch) {
      mobileSearch.addEventListener('focus', () => { if (state.view !== 'search') { state.view = 'search'; renderAll(); } });
      mobileSearch.addEventListener('keydown', (e) => { if (e.key === 'Enter') performSearch(mobileSearch.value); });
      mobileSearch.addEventListener('input', () => onSearchTyping(mobileSearch.value));
    }
  }

  function wireStyleEvents() {
    root.querySelectorAll('.style-pill [data-style]').forEach((el) => {
      el.addEventListener('click', () => { const v = el.getAttribute('data-style'); if (v !== state.style) fadeThen(() => { state.style = v; saveSettings(); renderAll(); }); });
    });
  }

  function wireSidebarEvents() {
    const createPlaylistBtn = root.querySelector('#create-playlist-btn');
    if (createPlaylistBtn) createPlaylistBtn.addEventListener('click', openCreatePlaylistModal);
    const list = root.querySelector('#playlist-list');
    if (list) list.addEventListener('click', (e) => {
      const el = e.target.closest('[data-open-playlist]');
      if (el) openUserPlaylist(el.getAttribute('data-open-playlist'));
    });
  }

  function playCollection(id) {
    let list;
    if (id === 'liked') list = likedList().filter(isPlayableTrack);
    else {
      const pl = userPlaylists.find((p) => p.id === id);
      list = pl ? pl.trackIds.map((tid) => allKnownTracks[tid]).filter(isPlayableTrack) : [];
    }
    if (list.length) playTrackById(list[0].id, list, true);
  }

  function onViewClick(e) {
    const q = (sel) => e.target.closest(sel);
    let el;
    if ((el = q('[data-like-track]'))) { e.stopPropagation(); toggleLike(el.getAttribute('data-like-track')); return; }
    if ((el = q('[data-add-to-playlist]'))) { e.stopPropagation(); openAddToPlaylist(el.getAttribute('data-add-to-playlist')); return; }
    if ((el = q('[data-open-artist-id]'))) {
      e.stopPropagation();
      openArtistById(el.getAttribute('data-open-artist-src'), el.getAttribute('data-open-artist-id'),
        { name: el.getAttribute('data-open-artist-name'), avatar_url: el.getAttribute('data-open-artist-avatar') });
      return;
    }
    if (q('[data-artist-back]')) { e.stopPropagation(); goBackFromArtist(); return; }
    if (q('[data-user-back]')) { e.stopPropagation(); goBackFromUser(); return; }
    if ((el = q('[data-user-tab]'))) {
      if (userPage) { userPage.tab = el.getAttribute('data-user-tab'); userPage.list = null; syncUserQueue(); refreshUserView(false); }
      return;
    }
    if (q('[data-user-list-back]')) { closeUserList(); return; }
    if ((el = q('[data-open-user-list]'))) { openUserList(el.getAttribute('data-open-user-list'), el.getAttribute('data-user-list-title')); return; }
    if ((el = q('[data-play-fav]'))) {
      const ft = userPage && userPage.profile && userPage.profile.favorite_track;
      if (ft && String(ft.id) === el.getAttribute('data-play-fav')) playTrackById(ft.id, [ft]);
      return;
    }
    if ((el = q('[data-open-user]'))) {
      const login = el.getAttribute('data-open-user');
      const hint = leafUsers.find((u) => String(u.login) === login) || { login };
      openUserProfile(hint);
      return;
    }
    if (q('[data-artist-expand]')) { if (artistPage) { artistPage.expanded = !artistPage.expanded; state._animNext = false; renderAll(); } return; }
    if ((el = q('[data-search-source]'))) { setSearchSource(el.getAttribute('data-search-source')); return; }
    if (q('[data-leaf-hint]')) {
      const si = root.querySelector('#search-input');
      if (si) { si.value = LEAF_PREFIX; si.focus(); }
      onSearchTyping(LEAF_PREFIX);
      return;
    }
    if ((el = q('[data-artist]'))) { e.stopPropagation(); openArtistPage(el.getAttribute('data-artist'), el.getAttribute('data-artist-source')); return; }
    if ((el = q('[data-play-collection]'))) { e.stopPropagation(); playCollection(el.getAttribute('data-play-collection')); return; }
    if ((el = q('[data-play-recent]'))) { playTrackById(el.getAttribute('data-play-recent'), recentView); return; }
    if (q('[data-open-liked]')) { state.view = 'liked'; renderAll(); return; }
    if ((el = q('[data-open-playlist]'))) { openUserPlaylist(el.getAttribute('data-open-playlist')); return; }
    if (q('[data-create-playlist]')) { openCreatePlaylistModal(); return; }
    if (q('[data-retry-home]')) { loadHomeTracks(); return; }
    if (q('[data-home-toggle]')) { state.homeExpanded = !state.homeExpanded; state._animNext = false; renderAll(); return; }
    if (q('#search-show-more')) { loadMoreSearchResults(); return; }
    if ((el = q('[data-play-track]'))) { playTrackById(el.getAttribute('data-play-track')); return; }
  }
  function onViewKeydown(e) {
    if (e.target && e.target.id === 'search-input' && e.key === 'Enter') performSearch(e.target.value);
  }
  function wireViewEvents() {
    const vr = root.querySelector('#view-root');
    if (!vr) return;
    vr.addEventListener('click', onViewClick);
    vr.addEventListener('keydown', onViewKeydown);
    vr.addEventListener('input', (e) => { if (e.target && e.target.id === 'search-input') onSearchTyping(e.target.value); });
  }

  function dragSlider(el, onMove, onStart, onEnd) {
    el.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      if (onStart && onStart() === false) return;
      el.classList.add('dragging');
      onMove(e.clientX);
      const move = (ev) => onMove(ev.clientX);
      const up = (ev) => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        el.classList.remove('dragging');
        if (onEnd) onEnd(ev.clientX);
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
      e.preventDefault();
    });
  }

  function wirePlayerEvents() {
    const btnPlayPause = root.querySelector('#btn-playpause');
    if (btnPlayPause) btnPlayPause.addEventListener('click', () => {
      if (!state.currentTrack) return;
      ensureAudioGraph();
      if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
      if (audioEl.paused) audioEl.play().catch(() => {});
      else audioEl.pause();
    });
    const btnNext = root.querySelector('#btn-next');
    if (btnNext) btnNext.addEventListener('click', handleNext);
    const btnPrev = root.querySelector('#btn-prev');
    if (btnPrev) btnPrev.addEventListener('click', handlePrev);
    const btnShuffle = root.querySelector('#btn-shuffle');
    if (btnShuffle) btnShuffle.addEventListener('click', () => { state.shuffle = !state.shuffle; updatePlayerBarOnly(); });
    const btnRepeat = root.querySelector('#btn-repeat');
    if (btnRepeat) btnRepeat.addEventListener('click', () => { state.repeat = !state.repeat; updatePlayerBarOnly(); });
    const playerLike = root.querySelector('#player-like');
    if (playerLike) playerLike.addEventListener('click', () => { if (state.currentTrack) toggleLike(state.currentTrack.id); });

    const nowPlaying = root.querySelector('.now-playing');
    if (nowPlaying) nowPlaying.addEventListener('click', (e) => {
      const a = e.target.closest('[data-artist]');
      if (a) { openArtistPage(a.getAttribute('data-artist'), a.getAttribute('data-artist-source')); return; }
      if (state.currentTrack && e.target.closest('img, .title')) { state.fullOpen = true; renderAll(); }
    });

    const seekTrack = root.querySelector('#seek-track');
    if (seekTrack) {
      const pctFrom = (x) => { const r = seekTrack.getBoundingClientRect(); return Math.max(0, Math.min(1, (x - r.left) / r.width)); };
      const durNow = () => (audioEl.duration && isFinite(audioEl.duration) ? audioEl.duration : (state.currentTrack && state.currentTrack.duration) || 0);
      dragSlider(seekTrack,
        (x) => {
          const p = pctFrom(x);
          state._seeking = true; state._seekPct = p;
          const fill = seekTrack.querySelector('.track-fill');
          if (fill) fill.style.width = (p * 100) + '%';
          const st = root.querySelector('.seek-time.start');
          if (st) st.textContent = formatTime(p * durNow());
        },
        () => { if (!state.currentTrack || !durNow()) return false; },
        (x) => {
          const d = durNow();
          if (d) { audioEl.currentTime = pctFrom(x) * d; state.progress = audioEl.currentTime; }
          state._seeking = false;
          updatePlayerBarOnly();
        });
    }

    const volumeTrack = root.querySelector('#volume-track');
    if (volumeTrack) {
      dragSlider(volumeTrack, (x) => {
        const r = volumeTrack.getBoundingClientRect();
        const pct = Math.max(0, Math.min(1, (x - r.left) / r.width));
        state.volume = Math.round(pct * 100);
        audioEl.volume = state.volume / 100;
        updatePlayerBarOnly();
      });
      volumeTrack.addEventListener('touchstart', (e) => { if (e.touches[0]) setVolumeFromX(volumeTrack, e.touches[0].clientX); }, { passive: true });
      volumeTrack.addEventListener('touchmove', (e) => { if (e.touches[0]) setVolumeFromX(volumeTrack, e.touches[0].clientX); }, { passive: true });
    }

    const openEq = root.querySelector('#open-eq');
    if (openEq) openEq.addEventListener('click', () => { state.eqOpen = true; renderAll(); });
    const openSettings = root.querySelector('#open-settings');
    if (openSettings) openSettings.addEventListener('click', () => { state.settingsOpen = true; renderAll(); });
  }
  function setVolumeFromX(track, x) {
    const r = track.getBoundingClientRect();
    state.volume = Math.round(Math.max(0, Math.min(1, (x - r.left) / r.width)) * 100);
    audioEl.volume = state.volume / 100;
    updatePlayerBarOnly();
  }

  function wireEqEvents() {
    const panel = root.querySelector('.eq-panel:not(.leaving)');
    if (!panel) return;
    syncEqPanel();
    panel.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = panel.querySelector('#eq-save-name');
      const name = input ? input.value.trim().slice(0, 24) : '';
      if (!name) { if (input) input.focus(); return; }
      eqCustom[name] = { bands: [...eqState.bands], bass: eqState.bassBoost, reverb: eqState.reverb };
      saveEqCustom();
      eqState.activePreset = 'u:' + name;
      saveEqState();
      if (input) input.value = '';
      refreshPresetArea();
      syncEqPanel();
    });
    panel.addEventListener('pointerdown', (e) => {
      const el = e.target.closest('.eq-slider');
      if (!el || (e.button !== undefined && e.button > 0)) return;
      e.preventDefault();
      try { el.setPointerCapture(e.pointerId); } catch (err) {  }
      el.classList.add('dragging');
      el.focus({ preventScroll: true });
      slideTo(el, e);
      const move = (ev) => slideTo(el, ev);
      const up = () => {
        el.classList.remove('dragging');
        el.removeEventListener('pointermove', move);
        el.removeEventListener('pointerup', up);
        el.removeEventListener('pointercancel', up);
        setSlider(el, Number(el.dataset.value));
      };
      el.addEventListener('pointermove', move);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
    });
    panel.addEventListener('dblclick', (e) => {
      const el = e.target.closest('.eq-slider');
      if (!el) return;
      setSlider(el, 0);
      onEqSlide(el, 0);
    });
    panel.addEventListener('keydown', (e) => {
      const el = e.target.closest && e.target.closest('.eq-slider');
      if (!el) return;
      const step = Number(el.dataset.step) || 1;
      let d = 0;
      if (e.key === 'ArrowUp' || e.key === 'ArrowRight') d = step;
      else if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') d = -step;
      else return;
      e.preventDefault();
      const v = Math.max(Number(el.dataset.min), Math.min(Number(el.dataset.max), Number(el.dataset.value) + d));
      setSlider(el, v);
      onEqSlide(el, v);
    });
    panel.addEventListener('click', (e) => {
      const del = e.target.closest('[data-eq-del]');
      if (del) {
        const n = del.getAttribute('data-eq-del');
        delete eqCustom[n];
        if (eqState.activePreset === 'u:' + n) eqState.activePreset = 'Custom';
        saveEqCustom(); saveEqState();
        refreshPresetArea(); syncEqPanel();
        return;
      }
      const user = e.target.closest('[data-eq-user]');
      if (user) {
        const n = user.getAttribute('data-eq-user');
        const p = eqCustom[n];
        if (p && Array.isArray(p.bands)) {
          eqState.bands = p.bands.map((v) => Number(v) || 0);
          eqState.bassBoost = Number(p.bass) || 0;
          eqState.reverb = Number(p.reverb) || 0;
          eqState.activePreset = 'u:' + n;
          applyEqToGraph(); syncEqPanel();
        }
        return;
      }
      const preset = e.target.closest('[data-eq-preset]');
      if (preset) {
        const p = preset.getAttribute('data-eq-preset');
        eqState.bands = [...EQ_PRESETS[p]];
        eqState.activePreset = p;
        applyEqToGraph(); syncEqPanel();
        return;
      }
      if (e.target.closest('#eq-reset')) {
        eqState.bands = [...EQ_PRESETS.Flat]; eqState.activePreset = 'Flat'; eqState.bassBoost = 0; eqState.reverb = 0;
        applyEqToGraph(); syncEqPanel();
        return;
      }
      if (e.target.closest('#eq-enable-toggle')) {
        eqState.enabled = !eqState.enabled;
        applyEqToGraph(); syncEqPanel();
        return;
      }
      if (e.target.closest('#close-eq')) { state.eqOpen = false; renderAll(); }
    });
  }

  function wireSettingsEvents() {
    const panel = root.querySelector('.side-panel:not(.leaving)');
    if (!panel) return;
    wireCustomizeEvents(panel);
    privLoadLiked();
    panel.addEventListener('click', (e) => {
      let el;
      if ((el = e.target.closest('[data-sg]'))) {
        const id = el.getAttribute('data-sg');
        state.stOpen[id] = !state.stOpen[id];
        const g = el.closest('.sg');
        if (g) g.classList.toggle('open', !!state.stOpen[id]);
        el.setAttribute('aria-expanded', String(!!state.stOpen[id]));
        return;
      }
      if ((el = e.target.closest('[data-game]'))) { gameToggle(el.getAttribute('data-game')); return; }
      if ((el = e.target.closest('[data-game-key]'))) { gameStartCapture(el.getAttribute('data-game-key')); return; }
      if (e.target.closest('[data-game-reset]')) { gameResetKeys(); return; }
      if (e.target.closest('[data-overlay-test]')) { overlayApi('overlay_toggle'); return; }
      if ((el = e.target.closest('[data-priv]'))) { privToggle(el.getAttribute('data-priv')); return; }
      if (e.target.closest('#st-glass')) { fadeThen(() => { state.glassBlur = !state.glassBlur; saveSettings(); renderAll(); }); return; }
      if ((el = e.target.closest('[data-color-theme]'))) { const v = el.getAttribute('data-color-theme'); if (v !== state.colorTheme || cz.accent) fadeThen(() => { state.colorTheme = v; czClearAccent(); saveSettings(); renderAll(); }); return; }
      if ((el = e.target.closest('[data-lang]'))) { const v = el.getAttribute('data-lang'); if (v !== state.language) fadeThen(() => { state.language = v; saveSettings(); renderAll(); }); return; }
      if ((el = e.target.closest('[data-style]'))) { const v = el.getAttribute('data-style'); if (v !== state.style) fadeThen(() => { state.style = v; saveSettings(); renderAll(); }); return; }
      if (e.target.closest('#close-settings')) { state.settingsOpen = false; renderAll(); }
    });
  }

  function wireCreatePlaylistEvents() {
    const modal = root.querySelector('.mini-modal:not(.leaving):not(.acc-modal)');
    if (!modal) return;
    const cpClose = modal.querySelector('#create-playlist-close');
    if (cpClose) cpClose.addEventListener('click', closeCreatePlaylistModal);
    const cpForm = modal.querySelector('#create-playlist-form');
    if (cpForm) cpForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = modal.querySelector('#create-playlist-input');
      const pl = await createUserPlaylist(input ? input.value : '');
      state.createPlaylistOpen = false;
      if (pl && state._pendingTrackForNewPlaylist) { addTrackToPlaylist(pl.id, state._pendingTrackForNewPlaylist); state._pendingTrackForNewPlaylist = null; }
      if (pl) openUserPlaylist(pl.id); else renderAll();
    });
  }

  function wireAddToPlaylistEvents() {
    const modal = root.querySelector('.mini-modal:not(.leaving):not(.acc-modal)');
    if (!modal) return;
    const atpClose = modal.querySelector('#add-to-playlist-close');
    if (atpClose) atpClose.addEventListener('click', closeAddToPlaylist);
    modal.querySelectorAll('[data-atp-target]').forEach((el) => {
      el.addEventListener('click', () => { addTrackToPlaylist(el.getAttribute('data-atp-target'), state.addToPlaylistTrackId); state.addToPlaylistTrackId = null; renderAll(); });
    });
    const atpNewBtn = modal.querySelector('#add-to-playlist-new');
    if (atpNewBtn) atpNewBtn.addEventListener('click', () => {
      const pendingTrackId = state.addToPlaylistTrackId; state.addToPlaylistTrackId = null; state.createPlaylistOpen = true;
      state._pendingTrackForNewPlaylist = pendingTrackId; renderAll();
    });
  }

  function renderPlaylistList() {
    const listEl = document.getElementById('playlist-list');
    if (!listEl) return;
    if (!userPlaylists.length) {
      if (_lastPlaylistsHtml === 'empty') return;
      _lastPlaylistsHtml = 'empty';
      listEl.innerHTML = `<p class="empty-state" style="padding:.75rem 0;font-size:.8rem;">${t('noPlaylistsYet')}</p>`;
      return;
    }
    const html = userPlaylists.map((pl) => {
      const cover = playlistCover(pl);
      return `
        <button class="playlist-item" data-open-playlist="${esc(pl.id)}">
          ${cover ? `<img class="playlist-thumb" src="${esc(cover)}" alt="" />` : `<div class="playlist-thumb">${icon('music', '', '', true)}</div>`}
          <span class="truncate">${esc(pl.name)}</span>
        </button>
      `;
    }).join('');
    if (html === _lastPlaylistsHtml) return;
    _lastPlaylistsHtml = html;
    listEl.innerHTML = html;
    updateSidebarActive();
  }

  function renderCreatePlaylistModal() {
    return `
      <div class="mini-modal">
        <div class="glass-strong mini-modal-inner">
          <div class="panel-header">
            <h2 class="font-display text-primary-c" style="font-size:1.1rem;">${t('createPlaylistTitle')}</h2>
            <button class="glass-subtle close-btn" id="create-playlist-close">${icon('x')}</button>
          </div>
          <form id="create-playlist-form">
            <input type="text" id="create-playlist-input" class="mini-modal-input" placeholder="${t('playlistNamePlaceholder')}" autocomplete="off" />
            <button type="submit" class="mini-modal-submit">${t('create')}</button>
          </form>
        </div>
      </div>
    `;
  }

  function renderAddToPlaylistModal() {
    return `
      <div class="mini-modal">
        <div class="glass-strong mini-modal-inner">
          <div class="panel-header">
            <h2 class="font-display text-primary-c" style="font-size:1.1rem;">${t('addToPlaylist')}</h2>
            <button class="glass-subtle close-btn" id="add-to-playlist-close">${icon('x')}</button>
          </div>
          <div class="atp-list">
            ${userPlaylists.length === 0 ? `<p class="empty-state" style="padding:1rem 0;">${t('noPlaylistsYet')}</p>` : userPlaylists.map((pl) => {
              const cover = playlistCover(pl);
              return `
                <button class="playlist-item" data-atp-target="${esc(pl.id)}">
                  ${cover ? `<img class="playlist-thumb" src="${esc(cover)}" alt="" />` : `<div class="playlist-thumb">${icon('music', '', '', true)}</div>`}
                  <span class="truncate">${esc(pl.name)}</span>
                </button>
              `;
            }).join('')}
          </div>
          <button class="mini-modal-submit" id="add-to-playlist-new" style="margin-top:.75rem;">${icon('plus')} ${t('newPlaylist')}</button>
        </div>
      </div>
    `;
  }


  let _fading = false;
  let _veilEl = null;
  function veilEl() {
    if (!_veilEl) {
      _veilEl = document.createElement('div');
      _veilEl.className = 'theme-veil';
      document.body.appendChild(_veilEl);
    }
    return _veilEl;
  }
  function fadeThen(fn) {
    if (_fading) { fn(); return; }
    _fading = true;
    const v = veilEl();
    v.classList.add('on');
    setTimeout(() => {
      try { fn(); } finally {
        requestAnimationFrame(() => requestAnimationFrame(() => {
          v.classList.remove('on');
          setTimeout(() => { _fading = false; }, 300);
        }));
      }
    }, 170);
  }

  const lyr = { key: null, lines: [], synced: false, active: -1, status: 'idle' };
  let _fpTrackId = null;
  let _fpBgToken = 0;

  const FP_SVG = {
    close: '<svg viewBox="0 0 16 16" fill="none"><path d="M3.5 6 8 10.5 12.5 6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    lyrics: '<svg viewBox="0 0 16 16" fill="none"><path d="M3 3.5h10M3 7h10M3 10.5h6.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
    vinyl: '<svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.2" stroke="currentColor" stroke-width="1.3"/><circle cx="8" cy="8" r="1.7" fill="currentColor"/></svg>',
  };

  function renderFullPlayer() {
    return `
      <div class="fp ${state.lyricsOpen ? 'lyrics-open' : ''}" id="full-player">
        <canvas class="fp-bg" id="fp-bg" width="128" height="128"></canvas>
        <div class="fp-shade"></div>
        <button class="fp-top fp-close" data-fp="close" title="${t('collapse')}">${FP_SVG.close}</button>
        <button class="fp-top fp-vinyl-toggle ${state.vinyl ? 'active' : ''}" data-fp="vinyl" title="${t('vinylView')}">${FP_SVG.vinyl}</button>
        <button class="fp-top fp-lyrics-toggle ${state.lyricsOpen ? 'active' : ''}" data-fp="lyrics" title="${t('lyricsTitle')}">${FP_SVG.lyrics}</button>

        <div class="fp-content">
          <div class="fp-art ${state.vinyl ? 'vinyl' : ''}" id="fp-art"><div class="fp-cover" id="fp-cover"></div></div>
          <div class="fp-title" id="fp-title"></div>
          <div class="fp-artist" id="fp-artist"></div>
          <div class="fp-timeline">
            <span class="fp-time" id="fp-cur">0:00</span>
            <div class="fp-progress" id="fp-progress"><div class="fp-fill" id="fp-fill"></div></div>
            <span class="fp-time" id="fp-tot">0:00</span>
          </div>
          <div class="fp-controls">
            <button class="fp-btn fp-mode" id="fp-repeat" data-fp="repeat">${icon('repeat')}</button>
            <button class="fp-btn" data-fp="prev">${icon('skipBack')}</button>
            <button class="fp-btn fp-play" id="fp-play" data-fp="play"></button>
            <button class="fp-btn" data-fp="next">${icon('skipForward')}</button>
            <button class="fp-btn fp-mode" id="fp-shuffle" data-fp="shuffle">${icon('shuffle')}</button>
          </div>
        </div>

        <div class="fp-lyrics">
          <div class="fp-lyrics-scroll" id="fp-lyr-scroll">
            <div class="fp-lyrics-state" id="fp-lyr-state"></div>
            <div class="fp-lyrics-lines" id="fp-lyr-lines"></div>
          </div>
        </div>
      </div>
    `;
  }

  function togglePlay() {
    if (!state.currentTrack) return;
    ensureAudioGraph();
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    if (audioEl.paused) audioEl.play().catch(() => {});
    else audioEl.pause();
  }

  function paintFpBg(src) {
    const cv = root.querySelector('#fp-bg');
    if (!cv) return;
    const token = ++_fpBgToken;
    const img = new Image();
    img.onload = () => {
      if (token !== _fpBgToken) return;
      try {
        const ctx = cv.getContext('2d');
        ctx.clearRect(0, 0, 128, 128);
        ctx.filter = 'blur(10px)';
        ctx.drawImage(img, -16, -16, 160, 160);
        ctx.filter = 'none';
        cv.classList.remove('fade');
        void cv.offsetWidth;
        cv.classList.add('fade');
      } catch (e) {  }
    };
    img.src = src;
  }

  function lyrMessage(text) {
    const st = root.querySelector('#fp-lyr-state');
    const ln = root.querySelector('#fp-lyr-lines');
    if (!st || !ln) return;
    ln.style.display = 'none'; ln.innerHTML = '';
    st.style.display = 'block'; st.textContent = text;
  }
  function lyrRender() {
    const st = root.querySelector('#fp-lyr-state');
    const ln = root.querySelector('#fp-lyr-lines');
    if (!st || !ln) return;
    st.style.display = 'none';
    ln.style.display = 'block';
    const first = lyr.synced ? lyr.lines.find((l) => typeof l.time === 'number') : null;
    const gap = first && first.time >= 5
      ? '<div class="fp-gap" id="fp-gap"><span class="fp-dots"><i></i><i></i><i></i></span><span class="fp-count"></span></div>'
      : '';
    ln.innerHTML = gap + lyr.lines
      .map((l, i) => `<div class="fp-line${lyr.synced ? ' synced' : ''}" data-i="${i}">${esc(l.text || '')}</div>`)
      .join('');
  }
  function updateGap(gap, now) {
    const first = lyr.lines.find((l) => typeof l.time === 'number');
    if (!first) return;
    const remain = first.time - now;
    const counting = remain > 0 && remain <= 3;
    gap.classList.toggle('counting', counting);
    if (!counting) return;
    const c = gap.querySelector('.fp-count');
    const n = String(Math.ceil(remain));
    if (c && c.textContent !== n) {
      c.textContent = n;
      c.classList.remove('pop');
      void c.offsetWidth;
      c.classList.add('pop');
    }
  }
  async function loadLyrics() {
    const tr = state.currentTrack;
    if (!tr) return;
    const key = String(tr.id);
    if (lyr.key === key) return;
    lyr.key = key; lyr.lines = []; lyr.synced = false; lyr.active = -1; lyr.status = 'loading';
    lyrMessage(t('lyricsLoading'));
    updateTopLyric();
    try {
      const params = new URLSearchParams({ title: tr.title || '', artist: tr.artist || '' });
      if (tr.duration) params.set('duration', String(Math.round(tr.duration)));
      const res = await fetch('/api/lyrics?' + params.toString());
      if (lyr.key !== key) return;
      const data = await res.json();
      if (lyr.key !== key) return;
      if (!data.found || !data.lines || !data.lines.length) { lyr.status = 'none'; lyrMessage(t('lyricsNotFound')); return; }
      lyr.lines = data.lines; lyr.synced = !!data.synced; lyr.status = 'found';
      lyrRender();
      if (lyr.synced) updateActiveLyric(true);
      updateTopLyric();
    } catch (e) {
      if (lyr.key === key) { lyr.status = 'none'; lyrMessage(t('lyricsNotFound')); }
    }
  }
  function syncLyricsPanel() {
    if (!root.querySelector('#fp-lyr-lines')) return;
    if (lyr.status === 'found') { lyrRender(); updateActiveLyric(true); }
    else if (lyr.status === 'none') lyrMessage(t('lyricsNotFound'));
    else if (lyr.status === 'loading') lyrMessage(t('lyricsLoading'));
    else loadLyrics();
  }
  function updateTopLyric() {
    const box = root.querySelector('#top-lyric');
    if (!box) return;
    let idx = -1;
    if (lyr.status === 'found' && lyr.synced && state.currentTrack) {
      const now = audioEl.currentTime || 0;
      for (let i = 0; i < lyr.lines.length; i++) {
        if (lyr.lines[i].time !== null && lyr.lines[i].time <= now) idx = i; else break;
      }
    }
    const tag = String(lyr.key) + ':' + idx;
    if (box.dataset.tag === tag) return;
    box.dataset.tag = tag;
    const text = idx >= 0 ? String(lyr.lines[idx].text || '').trim() : '';
    const prev = box.querySelector('.tl-line:not(.leave)');
    if (prev) {
      prev.classList.add('leave');
      prev.addEventListener('animationend', () => prev.remove(), { once: true });
      setTimeout(() => prev.remove(), 700);
    }
    if (text) {
      const el = document.createElement('span');
      el.className = 'tl-line enter';
      el.textContent = text;
      box.appendChild(el);
    }
  }
  function updateActiveLyric(force) {
    if (!state.lyricsOpen || !lyr.synced || !lyr.lines.length) return;
    const now = audioEl.currentTime || 0;
    let idx = -1;
    for (let i = 0; i < lyr.lines.length; i++) {
      if (lyr.lines[i].time !== null && lyr.lines[i].time <= now) idx = i; else break;
    }
    const gap = root.querySelector('#fp-gap');
    if (gap && idx === -1) updateGap(gap, now);
    if (idx === lyr.active && !force) return;
    lyr.active = idx;
    const nodes = root.querySelectorAll('#fp-lyr-lines .fp-line');
    nodes.forEach((n, i) => n.classList.toggle('active', i === idx));
    const scroll = root.querySelector('#fp-lyr-scroll');
    if (gap) {
      gap.classList.toggle('active', idx === -1);
      if (idx === -1 && scroll && scroll.scrollTo) {
        scroll.scrollTo({ top: gap.offsetTop - scroll.clientHeight / 2 + gap.offsetHeight / 2, behavior: 'smooth' });
      }
    }
    if (idx >= 0 && nodes[idx] && scroll) {
      if (scroll.scrollTo) scroll.scrollTo({ top: nodes[idx].offsetTop - scroll.clientHeight / 2 + nodes[idx].offsetHeight / 2, behavior: 'smooth' });
    }
  }

  function softSwap(fp) {
    ['#fp-art', '#fp-title', '#fp-artist'].forEach((s) => {
      const el = fp.querySelector(s);
      if (!el) return;
      el.classList.remove('swap');
      void el.offsetWidth;
      el.classList.add('swap');
    });
  }

  function updateFullPlayer() {
    const fp = root.querySelector('#full-player:not(.leaving)');
    if (!fp) return;
    const tr = state.currentTrack;
    const id = tr ? String(tr.id) : null;
    const prevId = _fpTrackId;
    const changed = id !== _fpTrackId;
    _fpTrackId = id;

    if (changed) {
      const cov = tr ? coverOf(tr) : DEFAULT_TRACK_COVER;
      fp.querySelector('#fp-title').textContent = tr ? tr.title : t('nothingPlaying');
      fp.querySelector('#fp-artist').innerHTML = tr ? `${sourceBadge(tr)}<span>${esc(tr.artist)}</span>` : '';
      fp.querySelector('#fp-cover').style.backgroundImage = `url("${cov}")`;
      paintFpBg(cov);
      syncLyricsPanel();
      if (prevId !== null) softSwap(fp);
    }

    const play = fp.querySelector('#fp-play');
    if (play) {
      const k = state.isPlaying ? 'pause' : 'play';
      if (play.dataset.ico !== k) { play.dataset.ico = k; play.innerHTML = icon(k); }
    }
    const cover = fp.querySelector('#fp-cover');
    if (cover) cover.classList.toggle('spinning', state.isPlaying);
    fp.querySelector('#fp-repeat').classList.toggle('on', state.repeat);
    fp.querySelector('#fp-shuffle').classList.toggle('on', state.shuffle);

    const dur = tr ? tr.duration : 0;
    const pct = dur ? Math.min(100, Math.max(0, (state.progress / dur) * 100)) : 0;
    if (!state._seeking) {
      const fill = fp.querySelector('#fp-fill');
      const w = pct.toFixed(1) + '%';
      if (fill && fill.style.width !== w) fill.style.width = w;
      const cur = fp.querySelector('#fp-cur'); const txt = formatTime(state.progress);
      if (cur && cur.textContent !== txt) cur.textContent = txt;
    }
    const tot = fp.querySelector('#fp-tot'); const tt = formatTime(dur);
    if (tot && tot.textContent !== tt) tot.textContent = tt;
    updateActiveLyric(false);
  }

  function wireFullPlayer() {
    const fp = root.querySelector('#full-player:not(.leaving)');
    if (!fp) return;
    fp.addEventListener('click', (e) => {
      const b = e.target.closest('[data-fp]');
      if (b) {
        const a = b.getAttribute('data-fp');
        if (a === 'close') { state.fullOpen = false; renderAll(); }
        else if (a === 'lyrics') {
          state.lyricsOpen = !state.lyricsOpen;
          fp.classList.toggle('lyrics-open', state.lyricsOpen);
          b.classList.toggle('active', state.lyricsOpen);
          if (state.lyricsOpen) syncLyricsPanel();
        } else if (a === 'vinyl') {
          state.vinyl = !state.vinyl;
          try { localStorage.setItem('leaf-vinyl', state.vinyl ? '1' : '0'); } catch (err) {  }
          fp.querySelector('#fp-art').classList.toggle('vinyl', state.vinyl);
          b.classList.toggle('active', state.vinyl);
        } else if (a === 'prev') handlePrev();
        else if (a === 'next') handleNext();
        else if (a === 'play') togglePlay();
        else if (a === 'shuffle') { state.shuffle = !state.shuffle; updatePlayerBarOnly(); }
        else if (a === 'repeat') { state.repeat = !state.repeat; updatePlayerBarOnly(); }
        return;
      }
      const line = e.target.closest('.fp-line.synced');
      if (line) {
        const l = lyr.lines[Number(line.getAttribute('data-i'))];
        if (l && typeof l.time === 'number') { audioEl.currentTime = l.time; if (audioEl.paused) audioEl.play().catch(() => {}); }
      }
    });

    const prog = fp.querySelector('#fp-progress');
    const pctFrom = (x) => { const r = prog.getBoundingClientRect(); return Math.max(0, Math.min(1, (x - r.left) / r.width)); };
    const durNow = () => (audioEl.duration && isFinite(audioEl.duration) ? audioEl.duration : (state.currentTrack && state.currentTrack.duration) || 0);
    dragSlider(prog,
      (x) => {
        const p = pctFrom(x);
        state._seeking = true;
        fp.querySelector('#fp-fill').style.width = (p * 100) + '%';
        fp.querySelector('#fp-cur').textContent = formatTime(p * durNow());
      },
      () => { if (!state.currentTrack || !durNow()) return false; },
      (x) => {
        const d = durNow();
        if (d) { audioEl.currentTime = pctFrom(x) * d; state.progress = audioEl.currentTime; }
        state._seeking = false;
        updatePlayerBarOnly();
      });

    _fpTrackId = null;
    updateFullPlayer();
  }

  /* ===== Настройки аккаунта: аватар, username, логин, пароль, описание (клик по аватарке в топбаре) ===== */
  Object.assign(I18N.ru, {
    accTitle: 'Настройки аккаунта', accSub: 'Профиль и безопасность',
    accLoading: 'Загрузка…', accRetry: 'Повторить',
    accUpload: 'Загрузить фото', accRemove: 'Убрать фото', accAvatarHint: 'JPG, PNG, GIF или WEBP, до 1 МБ',
    accUploading: 'Загружаем…', accSaved: 'Сохранено', accRemoved: 'Фото удалено',
    accAvatarBad: 'Не удалось обработать изображение', accAvatarBig: 'Файл больше 1 МБ',
    accUsername: 'Имя пользователя', accNewUsername: 'Новое имя пользователя',
    accLogin: 'Логин', accNewLogin: 'Новый логин',
    accPassword: 'Пароль', accCurrentPassword: 'Текущий пароль', accNewPassword: 'Новый пароль', accRepeatPassword: 'Повторите новый пароль',
    accDescription: 'Описание профиля', accDescPlaceholder: 'Расскажите о себе (до 300 символов)',
    accSave: 'Сохранить', accChangePassword: 'Сменить пароль',
    accRuleName: 'От 3 до 20 символов: латиница, цифры и _', accRulePass: 'Пароль — от 6 символов', accPassMismatch: 'Пароли не совпадают', accNeedPass: 'Введите текущий пароль',
    accErr400: 'Проверьте введённые данные', accErr401: 'Войдите в аккаунт заново', accErr402: 'Для этого нужен другой тариф',
    accErr403: 'Недостаточно прав', accErr409: 'Это уже занято', accErrNet: 'Сервер недоступен',
    accLogout: 'Выйти из аккаунта', accLogoutSure: 'Нажмите ещё раз, чтобы выйти', accLoggingOut: 'Выходим…',
  });
  Object.assign(I18N.en, {
    accTitle: 'Account settings', accSub: 'Profile and security',
    accLoading: 'Loading…', accRetry: 'Retry',
    accUpload: 'Upload photo', accRemove: 'Remove photo', accAvatarHint: 'JPG, PNG, GIF or WEBP, up to 1 MB',
    accUploading: 'Uploading…', accSaved: 'Saved', accRemoved: 'Photo removed',
    accAvatarBad: 'Could not process the image', accAvatarBig: 'File is larger than 1 MB',
    accUsername: 'Username', accNewUsername: 'New username',
    accLogin: 'Login', accNewLogin: 'New login',
    accPassword: 'Password', accCurrentPassword: 'Current password', accNewPassword: 'New password', accRepeatPassword: 'Repeat new password',
    accDescription: 'Profile description', accDescPlaceholder: 'Tell about yourself (up to 300 characters)',
    accSave: 'Save', accChangePassword: 'Change password',
    accRuleName: '3–20 characters: Latin letters, digits and _', accRulePass: 'Password must be at least 6 characters', accPassMismatch: 'Passwords do not match', accNeedPass: 'Enter your current password',
    accErr400: 'Please check the entered data', accErr401: 'Please sign in again', accErr402: 'A different plan is required',
    accErr403: 'Not enough permissions', accErr409: 'Already taken', accErrNet: 'Server unavailable',
    accLogout: 'Log out', accLogoutSure: 'Click again to log out', accLoggingOut: 'Logging out…',
  });

  Object.assign(I18N.ru, {
    accSettings: 'Настройки', accTabAccount: 'Аккаунт', accUploadAvatar: 'Загрузить аватарку', accDelete: 'Удалить',
    accChangeLogin: 'Сменить логин', accNewLoginPh: 'новый_логин', accSaveLogin: 'Сохранить логин',
    accChangeUsername: 'Сменить имя пользователя', accNewUsernamePh: 'новое_имя', accSaveUsername: 'Сохранить имя',
    accChangePasswordTitle: 'Сменить пароль', accOldPh: 'старый пароль', accNewPassPh: 'минимум 6 символов', accNewPassConfirmPh: 'новый пароль',
    accYourPassword: 'ваш пароль', accSavePassword: 'Сохранить пароль', accRepeatNew: 'Повтор нового пароля',
    accDescTitle: 'Описание профиля', accDescDesc: 'Показывается другим пользователям в вашем профиле',
  });
  Object.assign(I18N.en, {
    accSettings: 'Settings', accTabAccount: 'Account', accUploadAvatar: 'Upload avatar', accDelete: 'Delete',
    accChangeLogin: 'Change login', accNewLoginPh: 'new_login', accSaveLogin: 'Save login',
    accChangeUsername: 'Change username', accNewUsernamePh: 'new_name', accSaveUsername: 'Save username',
    accChangePasswordTitle: 'Change password', accOldPh: 'old password', accNewPassPh: 'at least 6 characters', accNewPassConfirmPh: 'new password',
    accYourPassword: 'your password', accSavePassword: 'Save password', accRepeatNew: 'Repeat new password',
    accDescTitle: 'Profile description', accDescDesc: 'Shown to other users on your profile',
  });

  const ACC_AVATAR_MAX = 1024 * 1024;
  const ACC_NAME_RE = /^[A-Za-z0-9_]{3,20}$/;
  let acc = { loading: false, error: '', data: null, msgs: {} };

  async function accReq(url, method, body, form) {
    try {
      const res = await fetch(url, {
        method: method || 'GET',
        headers: body ? { 'Content-Type': 'application/json' } : undefined,
        body: form || (body ? JSON.stringify(body) : undefined),
      });
      let data = null;
      try { data = await res.json(); } catch (e) {  }
      return { ok: res.ok, status: res.status, data };
    } catch (e) { return { ok: false, status: 0, data: null }; }
  }
  function accErr(r) {
    const d = r.data && typeof r.data.detail === 'string' ? r.data.detail : '';
    if (r.status === 401) return t('accErr401');
    if (r.status === 402) return t('accErr402');
    if (r.status === 403) return t('accErr403');
    if (r.status === 409) return t('accErr409');
    if (r.status === 413) return d || t('accAvatarBig');
    if (r.status === 0 || r.status === 502 || r.status === 503) return t('accErrNet');
    return /[А-Яа-яЁё]/.test(d) ? d : t('accErr400');
  }
  function accSetMsg(scope, text, kind) {
    acc.msgs[scope] = { text: text || '', kind: kind || '' };
    document.querySelectorAll('[data-acc-msg]').forEach((el) => {
      if (el.getAttribute('data-acc-msg') !== scope) return;
      const isOk = el.classList.contains('auth-success');
      const mine = (kind === 'err') ? !isOk : isOk;
      el.textContent = mine ? (text || '') : '';
      el.classList.toggle('show', mine && !!text);
    });
  }
  function accMsgHtml(scope) {
    const m = acc.msgs[scope] || { text: '', kind: '' };
    const e = m.kind === 'err' ? esc(m.text) : '', o = m.kind !== 'err' ? esc(m.text) : '';
    return '<div class="auth-error" data-acc-msg="' + scope + '">' + e + '</div><div class="auth-success" data-acc-msg="' + scope + '">' + o + '</div>';
  }
  async function accFetch() {
    const r = await accReq('/api/account', 'GET');
    return r.ok && r.data && typeof r.data === 'object' ? { data: r.data } : { err: accErr(r) };
  }
  async function accLoad() {
    acc.loading = true; acc.error = ''; acc.msgs = {};
    accRender();
    const res = await accFetch();
    acc.loading = false;
    if (res.data) acc.data = res.data; else acc.error = res.err;
    accRender();
  }

  function accNames() {
    const d = acc.data || {};
    return {
      username: d.username || (state.user && state.user.name) || '',
      login: d.login || '',
    };
  }
  const ACC_EDIT_SVG = '<span class="avatar-edit-overlay"><svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.3 2.2a1.4 1.4 0 0 1 2 2L6 11.5l-2.7.7.7-2.7 7.3-7.3Z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/></svg></span>';
  function accAvatarInner() {
    const pic = (state.user && state.user.avatar) || '';
    return (pic ? `<img class="acc-photo" src="${esc(pic)}" alt="" />` : `<img class="icon-img" src="images/User.png" alt="" />`) + ACC_EDIT_SVG;
  }
  function accPaintAvatar() {
    const el = document.getElementById('acc-avatar');
    if (el) el.innerHTML = accAvatarInner();
    const del = document.getElementById('acc-del');
    if (del) del.hidden = !(state.user && state.user.avatar);
  }
  function accPaintNames() {
    const n = accNames();
    const a = document.getElementById('acc-name'); if (a) a.textContent = n.username;
    const b = document.getElementById('acc-login'); if (b) b.textContent = n.login ? '@' + n.login : '';
  }
  function accApplyAvatar(url) {
    const v = url ? url + (url.indexOf('?') > -1 ? '&' : '?') + 'v=' + Date.now() : '';
    if (acc.data) acc.data.avatar_url = v;
    if (state.user) state.user.avatar = v; else state.user = { name: '', avatar: v };
    try { localStorage.setItem('leaf-user', JSON.stringify(state.user)); } catch (e) {  }
    _lastAvatar = null; updateTopbar(); accPaintAvatar();
  }

  function accBodyHtml() {
    if (acc.loading && !acc.data) return `<p class="acc-state">${t('accLoading')}</p>`;
    if (acc.error && !acc.data) return `<p class="acc-state err">${esc(acc.error)}</p><button type="button" class="settings-inline-btn" id="acc-retry"><span>${t('accRetry')}</span></button>${accLogoutHtml()}`;
    const d = acc.data || {};
    const n = accNames();
    const canDesc = !!(d.can_edit && d.can_edit.description);
    const hasPic = !!(state.user && state.user.avatar);
    const UP = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width="14" height="14"><path d="M8 10.5V2.5M8 2.5 5 5.5M8 2.5l3 3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M2.75 10.5v1.75c0 .55.45 1 1 1h8.5c.55 0 1-.45 1-1V10.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const lbl = (txt) => `<label>${txt}</label>`;
    const inp = (name, type, ph, extra) => `<input type="${type}" name="${name}" placeholder="${esc(ph)}" autocomplete="off" required ${extra || ''}>`;
    const form = (kind, title, fields, btn) => `<form class="auth-form settings-form" data-acc-form="${kind}"><h2>${title}</h2>${fields}${accMsgHtml(kind)}<button type="submit" class="auth-submit">${btn}</button></form>`;
    const divider = '<div class="settings-section-divider"></div>';
    return `
      <div class="settings-account-row">
        <button type="button" class="avatar avatar-editable settings-avatar-lg" id="acc-avatar" title="${t('accUploadAvatar')}">${accAvatarInner()}</button>
        <input type="file" id="acc-file" accept="image/jpeg,image/png,image/gif,image/webp" style="display:none;">
        <div class="track-text">
          <div class="track-title-row"><div class="track-title" id="acc-name">${esc(n.username)}</div></div>
          <div class="track-artist" id="acc-login">${n.login ? '@' + esc(n.login) : ''}</div>
        </div>
      </div>
      <div class="settings-avatar-actions">
        <button type="button" class="settings-inline-btn" id="acc-pick">${UP}<span>${t('accUploadAvatar')}</span></button>
        <button type="button" class="settings-inline-btn settings-inline-btn-danger" id="acc-del"${hasPic ? '' : ' hidden'}>${t('accDelete')}</button>
      </div>
      ${accMsgHtml('avatar')}
      ${accSubRowHtml()}
      ${canDesc ? `${divider}<form data-acc-form="desc" class="settings-select-item settings-admin-desc-item">
        <div class="settings-toggle-text settings-admin-desc-text">
          <div class="settings-toggle-title">${t('accDescTitle')}</div>
          <div class="settings-toggle-desc">${t('accDescDesc')}</div>
          <textarea name="description" id="acc-desc" class="settings-admin-desc-textarea" maxlength="300" placeholder="${esc(t('accDescPlaceholder'))}">${esc(d.description || '')}</textarea>
          <div class="settings-admin-desc-footer"><span class="settings-admin-desc-counter" id="acc-desc-counter">${(d.description || '').length}/300</span><button type="submit" class="settings-inline-btn">${t('accSave')}</button></div>
          ${accMsgHtml('desc')}
        </div></form>` : ''}
      ${divider}
      ${form('username', t('accChangeUsername'), lbl(t('accNewUsername')) + inp('new_username', 'text', t('accNewUsernamePh'), 'maxlength="20"') + lbl(t('accCurrentPassword')) + inp('password', 'password', t('accYourPassword'), 'autocomplete="current-password"'), t('accSaveUsername'))}
      ${divider}
      ${form('login', t('accChangeLogin'), lbl(t('accNewLogin')) + inp('new_login', 'text', t('accNewLoginPh'), 'maxlength="20"') + lbl(t('accCurrentPassword')) + inp('password', 'password', t('accYourPassword'), 'autocomplete="current-password"'), t('accSaveLogin'))}
      ${divider}
      ${form('password', t('accChangePasswordTitle'), lbl(t('accCurrentPassword')) + inp('old_password', 'password', t('accOldPh'), 'autocomplete="current-password"') + lbl(t('accNewPassword')) + inp('new_password', 'password', t('accNewPassPh'), 'autocomplete="new-password"') + lbl(t('accRepeatNew')) + inp('new_password_confirm', 'password', t('accNewPassConfirmPh'), 'autocomplete="new-password"'), t('accSavePassword'))}
      ${divider}
      ${accLogoutHtml()}`;
  }
  function accLogoutHtml() {
    return `<button type="button" class="settings-inline-btn settings-inline-btn-danger acc-logout" id="acc-logout">${icon('logout', '', '', true)}<span>${t('accLogout')}</span></button>`;
  }
  function accRender() {
    const body = document.getElementById('acc-body');
    if (body) body.innerHTML = accBodyHtml();
  }
  function renderAccountModal() {
    return `
      <div class="mini-modal acc-modal">
        <div class="acc-web">
          <div class="settings-card acc-card">
            <div class="settings-card-header">
              <h2>${t('accTitle')}</h2>
              <button class="settings-close-btn" id="acc-close">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width="14" height="14"><path d="M3.5 3.5 12.5 12.5M12.5 3.5 3.5 12.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
              </button>
            </div>
            <div class="acc-body" id="acc-body">${accBodyHtml()}</div>
          </div>
        </div>
      </div>
    `;
  }

  function accDownscale(file, max, q) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(url);
        const s = Math.min(img.naturalWidth, img.naturalHeight);
        const side = Math.min(max, s);
        const c = document.createElement('canvas');
        c.width = c.height = side;
        c.getContext('2d').drawImage(img, (img.naturalWidth - s) / 2, (img.naturalHeight - s) / 2, s, s, 0, 0, side, side);
        c.toBlob((b) => (b ? resolve(b) : reject(new Error('blob'))), 'image/jpeg', q);
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('img')); };
      img.src = url;
    });
  }
  async function accPrepAvatar(file) {
    if (/^image\/(jpeg|png|gif|webp)$/.test(file.type) && file.size <= ACC_AVATAR_MAX) return file;
    if (!/^image\//.test(file.type)) throw new Error('type');
    const steps = [[512, 0.9], [512, 0.8], [384, 0.8], [256, 0.75]];
    for (let i = 0; i < steps.length; i++) {
      const b = await accDownscale(file, steps[i][0], steps[i][1]);
      if (b.size <= ACC_AVATAR_MAX) return b;
    }
    throw new Error('big');
  }
  async function accUploadAvatar(file) {
    accSetMsg('avatar', t('accUploading'), '');
    let blob;
    try { blob = await accPrepAvatar(file); } catch (e) { accSetMsg('avatar', t('accAvatarBad'), 'err'); return; }
    const fd = new FormData();
    fd.append('file', blob, blob === file ? (file.name || 'avatar') : 'avatar.jpg');
    const r = await accReq('/api/account/avatar', 'POST', null, fd);
    if (!r.ok) { accSetMsg('avatar', accErr(r), 'err'); return; }
    let url = r.data && r.data.avatar_url;
    if (!url) { const f = await accFetch(); url = f.data && f.data.avatar_url; }
    accApplyAvatar(url || '');
    accSetMsg('avatar', t('accSaved'), 'ok');
  }
  async function accRemoveAvatar() {
    const r = await accReq('/api/account/avatar', 'DELETE');
    if (!r.ok) { accSetMsg('avatar', accErr(r), 'err'); return; }
    accApplyAvatar('');
    accSetMsg('avatar', t('accRemoved'), 'ok');
  }

  async function accSubmit(form) {
    const kind = form.getAttribute('data-acc-form');
    const v = (n) => (form.elements[n] ? form.elements[n].value : '');
    const btn = form.querySelector('button[type=submit]');
    const done = (r, okText, after) => {
      if (btn) btn.disabled = false;
      if (!r.ok) { accSetMsg(kind, accErr(r), 'err'); return; }
      accSetMsg(kind, okText || t('accSaved'), 'ok');
      form.querySelectorAll('input[type=password]').forEach((i) => { i.value = ''; });
      if (after) after();
    };
    if (kind === 'username' || kind === 'login') {
      const val = v(kind === 'username' ? 'new_username' : 'new_login').trim();
      const pw = v('password');
      if (!ACC_NAME_RE.test(val)) { accSetMsg(kind, t('accRuleName'), 'err'); return; }
      if (!pw) { accSetMsg(kind, t('accNeedPass'), 'err'); return; }
      if (btn) btn.disabled = true;
      if (kind === 'username') {
        const r = await accReq('/api/account/username', 'POST', { new_username: val, password: pw });
        done(r, '', () => {
          if (acc.data) acc.data.username = val;
          if (state.user) state.user.name = val; else state.user = { name: val, avatar: '' };
          try { localStorage.setItem('leaf-user', JSON.stringify(state.user)); } catch (e) {  }
          form.elements.new_username.value = '';
          _lastAvatar = null; updateTopbar(); accPaintNames(); accPaintAvatar();
        });
      } else {
        const r = await accReq('/api/change-login', 'POST', { new_login: val, password: pw });
        done(r, '', () => {
          if (acc.data) acc.data.login = val;
          try { localStorage.setItem('leaf-cache-owner', val); } catch (e) {  }
          form.elements.new_login.value = '';
          accPaintNames();
        });
      }
    } else if (kind === 'password') {
      const oldp = v('old_password'), np = v('new_password'), npc = v('new_password_confirm');
      if (!oldp) { accSetMsg(kind, t('accNeedPass'), 'err'); return; }
      if (np.length < 6) { accSetMsg(kind, t('accRulePass'), 'err'); return; }
      if (np !== npc) { accSetMsg(kind, t('accPassMismatch'), 'err'); return; }
      if (btn) btn.disabled = true;
      done(await accReq('/api/change-password', 'POST', { old_password: oldp, new_password: np, new_password_confirm: npc }));
    } else if (kind === 'desc') {
      const text = v('description').trim().slice(0, 300);
      if (btn) btn.disabled = true;
      done(await accReq('/api/settings/admin-description', 'POST', { description: text }), '', () => { if (acc.data) acc.data.description = text; });
    }
  }

  let _accLogoutTimer = null;
  function accLogoutClick(btn) {
    if (!btn) return;
    if (btn.dataset.sure !== '1') {
      btn.dataset.sure = '1';
      btn.classList.add('sure');
      btn.querySelector('span').textContent = t('accLogoutSure');
      clearTimeout(_accLogoutTimer);
      _accLogoutTimer = setTimeout(() => {
        btn.dataset.sure = '';
        btn.classList.remove('sure');
        const sp = btn.querySelector('span'); if (sp) sp.textContent = t('accLogout');
      }, 4000);
      return;
    }
    accLogout(btn);
  }
  async function accLogout(btn) {
    clearTimeout(_accLogoutTimer);
    btn.disabled = true;
    btn.querySelector('span').textContent = t('accLoggingOut');
    try { await fetch('/api/logout', { method: 'POST' }); } catch (e) {  }
    try { localStorage.removeItem('leaf-user'); } catch (e) {  }
    const api = window.pywebview && window.pywebview.api;
    if (api && typeof api.restart_app === 'function') {
      try { await api.restart_app(); return; } catch (e) {  }
    }
    location.reload();
  }

  function wireAccountEvents() {
    const modal = root.querySelector('.acc-modal:not(.leaving)');
    if (!modal) return;
    modal.addEventListener('click', (e) => {
      if (e.target.closest('#acc-close')) { state.accountOpen = false; renderAll(); return; }
      if (e.target.closest('#acc-pick') || e.target.closest('#acc-avatar')) { const f = modal.querySelector('#acc-file'); if (f) f.click(); return; }
      if (e.target.closest('#acc-del')) { accRemoveAvatar(); return; }
      if (e.target.closest('#acc-retry')) { accLoad(); return; }
      if (e.target.closest('#acc-sub-open')) { state.accountOpen = false; renderAll(); subOpen(); return; }
      if (e.target.closest('#acc-logout')) { accLogoutClick(modal.querySelector('#acc-logout')); return; }
    });
    modal.addEventListener('input', (e) => {
      if (e.target && e.target.id === 'acc-desc') {
        const c = modal.querySelector('#acc-desc-counter'); if (c) c.textContent = e.target.value.length + '/300';
      }
    });
    modal.addEventListener('change', (e) => {
      if (e.target && e.target.id === 'acc-file') {
        const f = e.target.files && e.target.files[0];
        e.target.value = '';
        if (f) accUploadAvatar(f);
      }
    });
    modal.addEventListener('submit', (e) => {
      const form = e.target.closest && e.target.closest('[data-acc-form]');
      if (!form) return;
      e.preventDefault();
      accSubmit(form);
    });
  }
  function openAccountModal() {
    if (state.accountOpen) return;
    state.accountOpen = true;
    renderAll();
  }
  document.addEventListener('click', (e) => {
    if (e.target && e.target.closest && e.target.closest('#avatar-badge')) openAccountModal();
  });
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.id === 'avatar-badge') { e.preventDefault(); openAccountModal(); }
  });

  document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'modal-backdrop') closeAllModals();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalKeyNow()) closeAllModals();
  });
  document.addEventListener('load', (e) => {
    const el = e.target;
    if (el && el.tagName === 'IMG') el.classList.add('loaded');
  }, true);
  document.addEventListener('error', (e) => {
    const el = e.target;
    if (!el || el.tagName !== 'IMG') return;
    if (el.classList.contains('avatar-img')) {
      if (state.user) state.user.avatar = '';
      _lastAvatar = null; updateTopbar();
      return;
    }
    if (!el.dataset.fb) { el.dataset.fb = '1'; el.src = DEFAULT_TRACK_COVER; }
    else el.classList.add('loaded');
  }, true);
  const _idle = (on) => document.documentElement.classList.toggle('window-idle', on);
  window.addEventListener('blur', () => _idle(true));
  window.addEventListener('focus', () => _idle(false));
  document.addEventListener('visibilitychange', () => _idle(document.hidden));

  /* ==========================================================================
     Кастомизация: фоны, свой акцент, эффекты (снег/дождь), библиотека тем.
     Хранение: localStorage 'leaf-custom' (настройки) и 'leaf-bg-image' (свой фон).
     Сервер (через локальный адаптер): GET /api/themes, POST /api/themes/{id}/apply,
     POST /api/settings/theme, POST/DELETE /api/account/background, background_url из /api/me.
     ========================================================================== */
  const CZ_PRESETS = {
    aurora:   { name: 'Aurora',   css: 'radial-gradient(60% 55% at 18% 18%, rgba(34,211,238,.55), transparent 62%), radial-gradient(55% 60% at 82% 28%, rgba(168,85,247,.5), transparent 62%), radial-gradient(70% 60% at 50% 105%, rgba(34,197,94,.45), transparent 62%), #050d14' },
    sunset:   { name: 'Sunset',   css: 'radial-gradient(70% 60% at 80% 10%, rgba(251,113,133,.6), transparent 60%), radial-gradient(70% 70% at 10% 90%, rgba(251,146,60,.5), transparent 62%), #1a0b14' },
    ocean:    { name: 'Ocean',    css: 'linear-gradient(160deg, #0b3a5b 0%, #0a1f3a 55%, #050b18 100%)' },
    forest:   { name: 'Forest',   css: 'radial-gradient(70% 60% at 20% 15%, rgba(34,197,94,.45), transparent 62%), radial-gradient(60% 60% at 85% 85%, rgba(132,204,22,.3), transparent 62%), #06140c' },
    sakura:   { name: 'Sakura',   css: 'radial-gradient(60% 55% at 15% 20%, rgba(244,114,182,.5), transparent 62%), radial-gradient(60% 60% at 85% 80%, rgba(196,181,253,.55), transparent 62%), #fdf2f8' },
    frost:    { name: 'Frost',    css: 'linear-gradient(170deg, #1e3a5f 0%, #0f1f38 60%, #08111f 100%)' },
    midnight: { name: 'Midnight', css: 'radial-gradient(60% 60% at 75% 15%, rgba(99,102,241,.45), transparent 62%), radial-gradient(60% 60% at 15% 90%, rgba(168,85,247,.35), transparent 62%), #07070f' },
    graphite: { name: 'Graphite', css: 'linear-gradient(145deg, #2a2a2e 0%, #141416 60%, #0a0a0b 100%)' },
    paper:    { name: 'Paper',    css: 'linear-gradient(145deg, #fafaf9 0%, #e7e5e4 100%)' },
  };
  const CZ_LIBRARY = [
    { id: 'classic',  name: 'Leaf Classic', style: 'dark',  colorTheme: 'green',  accent: null,      bg: { type: 'none' },                      dim: 35, blur: 0, particles: 'none' },
    { id: 'aurora',   name: 'Aurora',       style: 'dark',  colorTheme: 'green',  accent: '#2dd4bf', bg: { type: 'preset', preset: 'aurora' },   dim: 25, blur: 0, particles: 'none' },
    { id: 'sunset',   name: 'Sunset',       style: 'dark',  colorTheme: 'red',    accent: '#fb7185', bg: { type: 'preset', preset: 'sunset' },   dim: 30, blur: 0, particles: 'none' },
    { id: 'ocean',    name: 'Ocean',        style: 'dark',  colorTheme: 'blue',   accent: null,      bg: { type: 'preset', preset: 'ocean' },    dim: 20, blur: 0, particles: 'none' },
    { id: 'forest',   name: 'Forest',       style: 'dark',  colorTheme: 'green',  accent: null,      bg: { type: 'preset', preset: 'forest' },   dim: 25, blur: 0, particles: 'none' },
    { id: 'winter',   name: 'Winter',       style: 'dark',  colorTheme: 'blue',   accent: '#93c5fd', bg: { type: 'preset', preset: 'frost' },    dim: 20, blur: 0, particles: 'snow' },
    { id: 'rainy',    name: 'Rainy Night',  style: 'dark',  colorTheme: 'purple', accent: null,      bg: { type: 'preset', preset: 'midnight' }, dim: 30, blur: 0, particles: 'rain' },
    { id: 'sakura',   name: 'Sakura',       style: 'light', colorTheme: 'red',    accent: '#ec4899', bg: { type: 'preset', preset: 'sakura' },   dim: 15, blur: 0, particles: 'none' },
    { id: 'mono',     name: 'Mono',         style: 'light', colorTheme: 'white',  accent: '#18181b', bg: { type: 'preset', preset: 'paper' },    dim: 0,  blur: 0, particles: 'none' },
  ];
  const CZ_FX = ['none', 'snow', 'rain'];
  const CZ_DEFAULT = { bg: { type: 'none', preset: 'aurora' }, dim: 35, blur: 0, accent: null, particles: 'none', themeId: null, syncBg: false, bgTouched: false };
  const czHex = (v) => (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v.trim()) ? v.trim().toLowerCase() : null);
  const czClamp = (v, a, b, d) => { v = Number(v); return Number.isFinite(v) ? Math.max(a, Math.min(b, Math.round(v))) : d; };

  function czLoad() {
    let o = null;
    try { o = JSON.parse(localStorage.getItem('leaf-custom') || 'null'); } catch (e) {  }
    o = o && typeof o === 'object' ? o : {};
    const bg = o.bg && typeof o.bg === 'object' ? o.bg : {};
    return {
      bg: {
        type: ['none', 'preset', 'image', 'account'].includes(bg.type) ? bg.type : 'none',
        preset: CZ_PRESETS[bg.preset] ? bg.preset : 'aurora',
      },
      dim: czClamp(o.dim, 0, 90, CZ_DEFAULT.dim),
      blur: czClamp(o.blur, 0, 30, 0),
      accent: czHex(o.accent),
      particles: CZ_FX.includes(o.particles) ? o.particles : 'none',
      themeId: typeof o.themeId === 'string' ? o.themeId : null,
      syncBg: o.syncBg === true,
      bgTouched: o.bgTouched === true,
    };
  }
  const cz = czLoad();
  let czImage = '';
  try { czImage = localStorage.getItem('leaf-bg-image') || ''; } catch (e) {  }
  let czAccountBg = '';
  let czServerThemes = [];
  let czServerState = 'idle';
  let czMsg = { text: '', kind: '', scope: 'bg' };
  let _czSaveTimer = null;
  function czSave() { try { localStorage.setItem('leaf-custom', JSON.stringify(cz)); } catch (e) {  } }
  function czSaveSoon() { clearTimeout(_czSaveTimer); _czSaveTimer = setTimeout(czSave, 250); }

  function czApplyAccent() {
    const s = document.documentElement.style;
    const hex = czHex(cz.accent);
    if (!hex) { ['--accent', '--accent-fg', '--accent-glow', '--accent-soft'].forEach((k) => s.removeProperty(k)); return; }
    const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    s.setProperty('--accent', hex);
    s.setProperty('--accent-fg', lum > 0.6 ? '#111111' : '#ffffff');
    s.setProperty('--accent-glow', 'rgba(' + r + ',' + g + ',' + b + ',.35)');
    s.setProperty('--accent-soft', 'rgba(' + r + ',' + g + ',' + b + ',.14)');
  }

  function czBgCss() {
    if (cz.bg.type === 'preset' && CZ_PRESETS[cz.bg.preset]) return CZ_PRESETS[cz.bg.preset].css;
    const u = cz.bg.type === 'image' ? czImage : cz.bg.type === 'account' ? czAccountBg : '';
    return u ? 'center / cover no-repeat url("' + u.replace(/"/g, '%22') + '")' : '';
  }
  function czApplyBgVars() {
    const el = document.getElementById('leaf-bg');
    if (!el) return;
    el.style.setProperty('--cz-dim', String(cz.dim / 100));
    el.style.setProperty('--cz-blur', cz.blur + 'px');
    el.classList.toggle('blurred', cz.blur > 0);
  }
  function czApplyBg() {
    const html = document.documentElement;
    let el = document.getElementById('leaf-bg');
    const css = czBgCss();
    if (!css) { if (el) el.remove(); html.classList.remove('has-bg'); return; }
    if (!el) {
      el = document.createElement('div');
      el.id = 'leaf-bg';
      el.innerHTML = '<div class="cz-layer"></div>';
      document.body.insertBefore(el, document.body.firstChild);
    }
    el.firstChild.style.background = css;
    html.classList.add('has-bg');
    czApplyBgVars();
  }

  let czFx = null;
  function czStopFx() {
    if (!czFx) return;
    czFx.stop();
    czFx = null;
  }
  function gamePerfOn() { try { return game.perf === true; } catch (e) { return false; } }
  function czApplyParticles() {
    const kind = cz.particles;
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (kind === 'none' || reduced || gamePerfOn()) { czStopFx(); return; }
    if (czFx && czFx.kind === kind) return;
    czStopFx();
    const canvas = document.createElement('canvas');
    canvas.id = 'leaf-fx';
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d');
    let w = 0, h = 0;
    const resize = () => { w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);
    const n = kind === 'snow' ? 70 : 110;
    let flake = null;
    if (kind === 'snow') {
      const img = new Image();
      img.onload = () => {
        const make = (color) => {
          const c = document.createElement('canvas');
          c.width = c.height = 64;
          const g = c.getContext('2d');
          g.drawImage(img, 0, 0, 64, 64);
          if (color) { g.globalCompositeOperation = 'source-in'; g.fillStyle = color; g.fillRect(0, 0, 64, 64); }
          return c;
        };
        flake = { dark: make(null), light: make('rgb(110,140,185)') };
      };
      img.src = 'images/snow.png';
    }
    const ps = Array.from({ length: n }, () => ({
      x: Math.random() * w, y: Math.random() * h, ph: Math.random() * Math.PI * 2,
      a: Math.random() * Math.PI * 2, spin: (Math.random() - 0.5) * 0.03, o: 0.5 + Math.random() * 0.5,
      r: kind === 'snow' ? 1 + Math.random() * 2.2 : 0.8 + Math.random() * 0.8,
      v: kind === 'snow' ? 0.5 + Math.random() * 1.1 : 9 + Math.random() * 6,
      l: 8 + Math.random() * 10,
    }));
    let alive = true, last = 0, raf = 0, timer = 0;
    const tick = (ts) => {
      if (!alive) return;
      const cl = document.documentElement.classList;
      if (cl.contains('modal-open') || cl.contains('window-idle') || document.hidden) {
        timer = setTimeout(() => { raf = requestAnimationFrame(tick); }, 300);
        return;
      }
      raf = requestAnimationFrame(tick);
      const dt = Math.min(3, (ts - last) / 16.7 || 1);
      last = ts;
      ctx.clearRect(0, 0, w, h);
      const dark = cl.contains('dark');
      if (kind === 'snow') {
        const sprite = flake ? (dark ? flake.dark : flake.light) : null;
        if (sprite) {
          for (const p of ps) {
            p.y += p.v * dt; p.ph += 0.02 * dt; p.x += Math.sin(p.ph) * 0.6 * dt; p.a += p.spin * dt;
            if (p.y > h + 12) { p.y = -12; p.x = Math.random() * w; }
            const sz = p.r * 5;
            ctx.globalAlpha = p.o * (dark ? 0.9 : 0.8);
            ctx.setTransform(Math.cos(p.a), Math.sin(p.a), -Math.sin(p.a), Math.cos(p.a), p.x, p.y);
            ctx.drawImage(sprite, -sz / 2, -sz / 2, sz, sz);
          }
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.globalAlpha = 1;
        } else {
          ctx.fillStyle = dark ? 'rgba(255,255,255,.8)' : 'rgba(110,140,185,.7)';
          ctx.beginPath();
          for (const p of ps) {
            p.y += p.v * dt; p.ph += 0.02 * dt; p.x += Math.sin(p.ph) * 0.6 * dt;
            if (p.y > h + 4) { p.y = -4; p.x = Math.random() * w; }
            ctx.moveTo(p.x + p.r, p.y); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          }
          ctx.fill();
        }
      } else {
        ctx.strokeStyle = dark ? 'rgba(180,200,255,.38)' : 'rgba(70,100,150,.45)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (const p of ps) {
          p.y += p.v * dt; p.x -= 1.6 * dt;
          if (p.y > h + 12) { p.y = -12; p.x = Math.random() * w + 40; }
          ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + 1.6, p.y - p.l);
        }
        ctx.stroke();
      }
    };
    raf = requestAnimationFrame(tick);
    czFx = {
      kind,
      stop() { alive = false; cancelAnimationFrame(raf); clearTimeout(timer); window.removeEventListener('resize', resize); canvas.remove(); },
    };
  }

  function czApplyAll() { czApplyAccent(); czApplyBg(); czApplyParticles(); }
  function czInit() { czApplyAll(); }

  /* scope: 'bg' — сообщения блока «Фон», 'theme' — блока «Библиотека тем». */
  function czSetMsg(text, kind, scope) {
    czMsg = { text: text || '', kind: kind || '', scope: scope || 'bg' };
    document.querySelectorAll('[data-cz-msg]').forEach((el) => {
      const on = el.getAttribute('data-cz-msg') === czMsg.scope;
      el.textContent = on ? czMsg.text : '';
      el.className = 'cz-msg ' + (on ? czMsg.kind : '');
    });
  }
  function czMsgHtml(scope) {
    const on = czMsg.scope === scope;
    return '<p data-cz-msg="' + scope + '" class="cz-msg ' + (on ? czMsg.kind : '') + '">' + (on ? esc(czMsg.text) : '') + '</p>';
  }
  function czClearAccent() {
    cz.accent = null; cz.themeId = null;
    czSave(); czApplyAccent(); czRefresh();
    czSyncThemeToServer();
  }
  function czSetAccountBg(url) {
    czAccountBg = typeof url === 'string' && url.indexOf('/remote-static/') === 0 ? url : '';
    if (czAccountBg && cz.bg.type === 'none' && !cz.bgTouched) { cz.bg.type = 'account'; czSave(); }
    czApplyBg();
    czRefresh();
  }

  function czDownscale(file, max, q) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        try {
          const k = Math.min(1, max / Math.max(img.width, img.height));
          const c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(img.width * k));
          c.height = Math.max(1, Math.round(img.height * k));
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', q));
        } catch (e) { reject(e); } finally { URL.revokeObjectURL(url); }
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('image')); };
      img.src = url;
    });
  }
  async function czUploadAccountBg(blob, name) {
    if (blob.size > 10 * 1024 * 1024) { czSetMsg(t('czFileOver10'), 'err'); return; }
    const fd = new FormData();
    fd.append('file', blob, name || 'background');
    try {
      const res = await fetch('/api/account/background', { method: 'POST', body: fd });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error('http ' + res.status);
      if (d.background_url) czAccountBg = String(d.background_url) + '?v=' + Date.now();
      czSetMsg(t('czSynced'), 'ok');
    } catch (e) { czSetMsg(t('czSyncFail'), 'err'); }
  }
  async function czPickImage(file) {
    if (!file) return;
    if (!/^image\/(jpeg|png|gif|webp)$/.test(file.type)) { czSetMsg(t('czBadType'), 'err'); return; }
    let dataUrl;
    try { dataUrl = await czDownscale(file, 1920, 0.85); } catch (e) { czSetMsg(t('czUploadFail'), 'err'); return; }
    try { localStorage.setItem('leaf-bg-image', dataUrl); } catch (e) { czSetMsg(t('czImageTooBig'), 'err'); return; }
    czImage = dataUrl;
    cz.bg.type = 'image'; cz.bgTouched = true; cz.themeId = null;
    czSave(); czApplyBg(); czSetMsg('', ''); czRefresh();
    if (cz.syncBg) czUploadAccountBg(file, file.name);
  }
  async function czRemoveBg() {
    const wasType = cz.bg.type;
    const deleteRemote = wasType === 'account' || (wasType === 'image' && cz.syncBg);
    cz.bg.type = 'none'; cz.bgTouched = true; cz.themeId = null;
    czImage = '';
    try { localStorage.removeItem('leaf-bg-image'); } catch (e) {  }
    if (deleteRemote) {
      try { await fetch('/api/account/background', { method: 'DELETE' }); czAccountBg = ''; } catch (e) {  }
    }
    czSave(); czApplyBg(); czRefresh();
  }

  function czApplyLibrary(th) {
    fadeThen(() => {
      state.style = th.style;
      if (COLOR_THEMES.includes(th.colorTheme)) state.colorTheme = th.colorTheme;
      cz.accent = czHex(th.accent);
      cz.bg = { type: th.bg.type, preset: th.bg.preset || cz.bg.preset };
      cz.dim = th.dim; cz.blur = th.blur; cz.particles = th.particles;
      cz.themeId = 'local:' + th.id; cz.bgTouched = true;
      saveSettings(); czSave(); czApplyAll(); renderAll(); czRefresh();
      czSyncThemeToServer();
    });
  }
  /* Превью тем бывают анимированными (GIF/WEBP). Десятки анимаций одновременно
     заставляют панель постоянно перерисовываться и рвут картинку. Поэтому берём
     только первый кадр (по одному, в очереди) и показываем его как статичную картинку. */
  const czStill = new Map();
  const czStillQueue = [];
  let czStillBusy = 0;
  let czStillTimer = 0;
  function czStillRefreshSoon() {
    clearTimeout(czStillTimer);
    czStillTimer = setTimeout(czStillPaint, 120);
  }
  function czStillNext() {
    if (czStillBusy >= 2) return;
    const url = czStillQueue.shift();
    if (!url) return;
    czStillBusy++;
    const done = (out) => {
      czStill.set(url, out);
      czStillBusy--;
      czStillRefreshSoon();
      czStillNext(); czStillNext();
    };
    const img = new Image();
    img.onload = () => {
      let out = 'fail';
      try {
        const k = Math.min(1, 192 / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round((img.naturalWidth || 1) * k));
        c.height = Math.max(1, Math.round((img.naturalHeight || 1) * k));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        out = c.toDataURL('image/jpeg', 0.82);
      } catch (e) {  }
      img.src = '';
      done(out);
    };
    img.onerror = () => done('fail');
    img.src = url;
  }
  function czStillOf(url) {
    if (!url) return '';
    if (url.indexOf('data:image/') === 0) return url;
    const v = czStill.get(url);
    if (v === undefined) { czStill.set(url, 'pending'); czStillQueue.push(url); czStillNext(); return ''; }
    return v === 'pending' || v === 'fail' ? '' : v;
  }
  function czNormServerTheme(o) {
    if (!o || typeof o !== 'object') return null;
    const id = o.id !== undefined && o.id !== null ? o.id : (o.slug !== undefined ? o.slug : o.name);
    if (id === undefined || id === null || id === '') return null;
    const prev = String(o.preview_url || o.preview || o.preview_path || '');
    return {
      id: String(id),
      name: String(o.name || o.title || id),
      description: String(o.description || ''),
      accent: czHex(o.accent_color || o.accent),
      particles: CZ_FX.includes(o.particles_type) ? o.particles_type : 'none',
      tier: String(o.required_tier || ''),
      available: typeof o.available === 'boolean' ? o.available : null,
      preview: prev.indexOf('/remote-static/') === 0 || prev.indexOf('data:image/') === 0 ? prev : '',
    };
  }
  async function czLoadServerThemes() {
    czServerState = 'loading'; czRefresh();
    try {
      const d = await apiJson('/api/themes');
      czServerThemes = (Array.isArray(d.themes) ? d.themes : []).map(czNormServerTheme).filter(Boolean);
      czServerState = 'ok';
    } catch (e) { czServerState = 'error'; }
    czRefresh();
  }
  const CZ_TIER_ORDER = { free: 0, lite: 1, standard: 2, family: 3 };
  function czTierOk(required) {
    const have = (state.subscription && state.subscription.tier) || 'free';
    return (CZ_TIER_ORDER[have] || 0) >= (CZ_TIER_ORDER[required || 'free'] || 0);
  }
  /* Сервер сам говорит, доступна ли тема (поле available); если его нет — считаем по тарифу из /api/me. */
  function czThemeOk(th) {
    return th.available !== null && th.available !== undefined ? th.available : czTierOk(th.tier);
  }

  /* Цвет темы аккаунта хранится на сервере — его видят другие пользователи в списке «leaf:».
     Формат как в вебе: встроенные цвета — по имени, свой акцент — theme=custom + hex. */
  let _czSyncTimer = 0;
  let _czSyncLast = '';
  function czSyncThemeToServer() {
    if (!serverMode) return;
    clearTimeout(_czSyncTimer);
    _czSyncTimer = setTimeout(async () => {
      const payload = cz.accent ? { theme: 'custom', theme_color: cz.accent } : { theme: state.colorTheme, theme_color: null };
      const ser = JSON.stringify(payload);
      if (ser === _czSyncLast) return;
      try {
        await apiJson('/api/settings/theme', 'POST', payload);
        _czSyncLast = ser;
      } catch (e) {
        if (e.status === 429) _czSyncTimer = setTimeout(czSyncThemeToServer, 1200);
      }
    }, 700);
  }

  /* Тема применяется МГНОВЕННО, не дожидаясь сервера: цвет и эффект берём из темы, фон — её превью
     (его же сервер и ставит фоном аккаунта). Запрос POST /api/themes/{id}/apply уходит в фоне;
     если сервер откажет (тариф/лимит) — откатываем всё как было. */
  async function czApplyServerTheme(id) {
    const th = czServerThemes.find((x) => x.id === id);
    if (!th) return;
    if (!czThemeOk(th)) { czSetMsg(t('czNeedTier'), 'err', 'theme'); return; }
    const before = {
      accent: cz.accent, particles: cz.particles, themeId: cz.themeId, bgTouched: cz.bgTouched,
      bgType: cz.bg.type, bgUrl: czAccountBg, sync: _czSyncLast,
    };
    const accent0 = th.accent || czAccentNow();
    cz.accent = accent0; cz.particles = th.particles; cz.themeId = 'srv:' + th.id; cz.bgTouched = true;
    czAccountBg = th.preview || ''; cz.bg.type = czAccountBg ? 'account' : 'none';
    _czSyncLast = JSON.stringify({ theme: 'custom', theme_color: accent0 });
    czSave(); czApplyAll(); czRefresh();
    czSetMsg(t('czApplied'), 'ok', 'theme');
    try {
      const res = await apiJson('/api/themes/' + encodeURIComponent(th.id) + '/apply', 'POST');
      const st = (res && res.settings) || {};
      const accent = czHex(st.theme_color);
      if (accent && cz.themeId === 'srv:' + th.id && accent !== cz.accent) {
        cz.accent = accent; _czSyncLast = JSON.stringify({ theme: 'custom', theme_color: accent });
        czSave(); czApplyAccent();
      }
    } catch (e) {
      if (cz.themeId === 'srv:' + th.id) {
        cz.accent = before.accent; cz.particles = before.particles; cz.themeId = before.themeId; cz.bgTouched = before.bgTouched;
        cz.bg.type = before.bgType; czAccountBg = before.bgUrl; _czSyncLast = before.sync;
        czSave(); czApplyAll(); czRefresh();
      }
      czSetMsg(e.status === 402 || e.status === 403 ? t('czNeedTier') : e.status === 429 ? t('czRateLimited') : t('czThemeFail'), 'err', 'theme');
    }
  }

  /* ---------- Предпросмотр тем: большая анимированная гифка + гифка в плитке при наведении ---------- */
  let czPeekId = null;
  const czGifReady = new Set();
  function czPeekTheme() {
    return czServerThemes.find((x) => x.id === czPeekId)
      || czServerThemes.find((x) => cz.themeId === 'srv:' + x.id)
      || null;
  }
  function czBigHtml() {
    const th = czPeekTheme();
    const has = !!(th && th.preview);
    return '<div class="cz-big' + (has ? '' : ' empty') + '" id="cz-big">'
      + '<img alt="" decoding="async"' + (has ? ' src="' + esc(th.preview) + '"' : '') + ' />'
      + '<div class="cz-big-meta"><b class="cz-big-name">' + (th ? esc(th.name) : '') + '</b>'
      + '<span class="cz-big-desc">' + (th ? esc(th.description) : esc(t('czPeekHint'))) + '</span></div></div>';
  }
  function czPeek(id) {
    czPeekId = id;
    const box = document.getElementById('cz-big');
    if (!box) return;
    const th = czPeekTheme();
    const img = box.querySelector('img');
    box.querySelector('.cz-big-name').textContent = th ? th.name : '';
    box.querySelector('.cz-big-desc').textContent = th ? (th.description || '') : t('czPeekHint');
    if (!th || !th.preview) { box.classList.add('empty'); img.removeAttribute('src'); return; }
    box.classList.remove('empty');
    if (img.getAttribute('src') !== th.preview) {
      if (!czGifReady.has(th.preview)) box.classList.add('loading');
      img.onload = () => { czGifReady.add(th.preview); box.classList.remove('loading'); };
      img.src = th.preview;
    }
  }
  // стоп-кадры плиток дорисовываем на месте — панель целиком не перерисовывается
  function czStillPaint() {
    document.querySelectorAll('[data-cz-srv] .cz-prev[data-gif]').forEach((prev) => {
      const still = czStillOf(prev.getAttribute('data-gif'));
      if (still && prev.dataset.still !== still) {
        prev.dataset.still = still;
        if (!prev.dataset.hot) prev.style.background = "center / cover no-repeat url('" + still + "')";
      }
    });
  }
  function czTileHot(tile, on) {
    const prev = tile.querySelector('.cz-prev[data-gif]');
    if (!prev) return;
    const gif = prev.getAttribute('data-gif');
    if (on) {
      prev.dataset.hot = '1';
      prev.style.background = "center / cover no-repeat url('" + gif + "')";
    } else {
      delete prev.dataset.hot;
      const still = prev.dataset.still;
      prev.style.background = still ? "center / cover no-repeat url('" + still + "')" : (prev.dataset.fallback || '');
    }
  }

  function czAccentNow() {
    const c = czHex(cz.accent);
    if (c) return c;
    const v = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
    return czHex(v) || '#22c55e';
  }
  function czTileBg(th) {
    if (th.bg && th.bg.type === 'preset' && CZ_PRESETS[th.bg.preset]) return CZ_PRESETS[th.bg.preset].css;
    return th.style === 'light' ? '#f8f8f8' : '#0c0c0c';
  }
  function renderCustomizeBlock() { return '<div id="cz-root">' + renderCustomizeInner() + '</div>'; }
  function sgGroup(id, ic, title, sub, body) {
    const open = !!state.stOpen[id];
    return `<section class="sg${open ? ' open' : ''}">
      <button class="sg-head" data-sg="${id}" aria-expanded="${open}">
        <span class="sg-ico">${icon(ic, '', '', true)}</span>
        <span class="sg-titles"><b>${title}</b><small>${sub}</small></span>
        <span class="sg-chev">${icon('chevronDown', '', '', true)}</span>
      </button>
      <div class="sg-body">${body}</div>
    </section>`;
  }
  function sgSub(ic, title, body) {
    return `<div class="sg-sub"><p class="sg-sub-title">${icon(ic, '', '', true)}<span>${title}</span></p>${body}</div>`;
  }
  function renderCustomizeInner() {
    const sel = (c) => (c ? ' selected' : '');
    const colorThemeLabelKey = { green: 'themeGreen', blue: 'themeBlue', white: 'themeWhite', red: 'themeRed', purple: 'themePurple' };
    const presetTiles = Object.keys(CZ_PRESETS).map((id) =>
      '<button class="cz-tile' + sel(cz.bg.type === 'preset' && cz.bg.preset === id) + '" data-cz-preset="' + id + '">'
      + '<span class="cz-prev" style="background:' + esc(CZ_PRESETS[id].css) + '"></span><span class="cz-name">' + esc(CZ_PRESETS[id].name) + '</span></button>').join('');
    const hasBg = cz.bg.type !== 'none';
    const libTiles = CZ_LIBRARY.map((th) =>
      '<button class="cz-tile' + sel(cz.themeId === 'local:' + th.id) + '" data-cz-theme="' + th.id + '">'
      + '<span class="cz-prev" style="background:' + esc(czTileBg(th)) + '"><i class="cz-dot" style="background:' + esc(th.accent || ({ green: '#22c55e', blue: '#3b82f6', white: '#f2f2f2', red: '#ef4444', purple: '#a855f7' })[th.colorTheme]) + '"></i></span>'
      + '<span class="cz-name">' + esc(th.name) + '</span></button>').join('');
    let srv = '';
    if (czServerState === 'loading' || czServerState === 'idle') srv = '<p class="cz-note">' + t('czServerLoading') + '</p>';
    else if (czServerState === 'error') srv = '<p class="cz-note">' + t('czServerError') + ' <button class="cz-link" data-cz-retry>' + t('czRetry') + '</button></p>';
    else if (!czServerThemes.length) srv = '<p class="cz-note">' + t('czServerEmpty') + '</p>';
    else srv = czBigHtml() + '<div class="cz-grid">' + czServerThemes.map((th) =>
      '<button class="cz-tile' + sel(cz.themeId === 'srv:' + th.id) + (czThemeOk(th) ? '' : ' locked') + '" data-cz-srv="' + esc(th.id) + '" title="' + esc(th.description) + '">'
      + '<span class="cz-prev"' + (th.preview ? ' data-gif="' + esc(th.preview) + '"' : '') + ' data-fallback="' + esc(th.accent || '#27272a') + '"'
      + (cz.themeId === 'srv:' + th.id && th.preview ? ' style="background:center / cover no-repeat url(\'' + esc(th.preview) + '\')"'
        : (czStillOf(th.preview) ? ' data-still="' + esc(czStillOf(th.preview)) + '" style="background:center / cover no-repeat url(\'' + esc(czStillOf(th.preview)) + '\')"' : ' style="background:' + esc(th.accent || '#27272a') + '"')) + '>'
      + (th.accent ? '<i class="cz-dot" style="background:' + esc(th.accent) + '"></i>' : '') + (th.tier && th.tier !== 'free' ? '<b class="cz-tier">' + esc(th.tier) + '</b>' : '') + '</span>'
      + '<span class="cz-name">' + esc(th.name) + '</span></button>').join('') + '</div>';
    const fxBtn = (k, label) => '<button class="cz-chip' + sel(cz.particles === k) + '" data-cz-fx="' + k + '">' + label + '</button>';

    const modeSub = sgSub(state.style === 'dark' ? 'moon' : 'sun', t('stSubMode'), `
      <div class="glass-subtle style-toggle-mini sg-mode">
        <button class="${state.style === 'light' ? 'active' : ''}" data-style="light">${icon('sun', '', '', true)} ${t('light')}</button>
        <button class="${state.style === 'dark' ? 'active' : ''}" data-style="dark">${icon('moon', '', '', true)} ${t('dark')}</button>
      </div>`);
    const colorsSub = sgSub('pipette', t('stSubColors'), `
      <div class="color-swatches">
        ${COLOR_THEMES.map((c) => `<button class="swatch swatch-${c} ${state.colorTheme === c ? 'selected' : ''}" data-color-theme="${c}" title="${t(colorThemeLabelKey[c])}"></button>`).join('')}
      </div>
      <div class="cz-accent-row">
        <input type="color" id="cz-accent" value="${czAccentNow()}">
        <span class="cz-hex" id="cz-accent-hex">${czAccentNow()}</span>
        ${cz.accent ? '<button class="cz-link" data-cz-accent-reset>' + t('czAccentReset') + '</button>' : ''}
      </div>`);
    const bgSub = sgSub('image', t('czBackground'), `
      <div class="cz-grid">
        <button class="cz-tile${sel(cz.bg.type === 'none')}" data-cz-none><span class="cz-prev cz-prev-none"></span><span class="cz-name">${t('czNone')}</span></button>
        ${presetTiles}
        <button class="cz-tile${sel(cz.bg.type === 'image')}" data-cz-pick><span class="cz-prev cz-prev-add"${czImage ? ' style="background:center / cover no-repeat url(\'' + czImage.replace(/'/g, '%27') + '\')"' : ''}>${czImage ? '' : '+'}</span><span class="cz-name">${t('czCustomImage')}</span></button>
        ${czAccountBg ? '<button class="cz-tile' + sel(cz.bg.type === 'account') + '" data-cz-account><span class="cz-prev"' + (czStillOf(czAccountBg) ? ' style="background:center / cover no-repeat url(\'' + esc(czStillOf(czAccountBg)) + '\')"' : '') + '></span><span class="cz-name">' + t('czAccountBg') + '</span></button>' : ''}
      </div>
      <input type="file" id="cz-file" accept="image/jpeg,image/png,image/gif,image/webp" hidden>
      <label class="cz-range-row"><span>${t('czDim')}</span><input type="range" class="cz-range" data-cz-range="dim" min="0" max="90" value="${cz.dim}"><b id="cz-dim-v">${cz.dim}%</b></label>
      <label class="cz-range-row"><span>${t('czBlur')}</span><input type="range" class="cz-range" data-cz-range="blur" min="0" max="30" value="${cz.blur}"><b id="cz-blur-v">${cz.blur}px</b></label>
      <label class="cz-check"><input type="checkbox" id="cz-sync" ${cz.syncBg ? 'checked' : ''}><span>${t('czSyncBg')}</span></label>
      ${hasBg ? '<button class="cz-link" data-cz-remove>' + t('czRemoveBg') + '</button>' : ''}
      ${czMsgHtml('bg')}`);
    const fxSub = sgSub('snowflake', t('czEffects'), `<div class="cz-chips">${fxBtn('none', t('czOff'))}${fxBtn('snow', t('czSnow'))}${fxBtn('rain', t('czRain'))}</div>`);
    const libLocalSub = sgSub('layers', t('czLibraryLocal'), `<div class="cz-grid">${libTiles}</div>`);
    const libServerSub = sgSub('globe', t('czLibraryServer'), srv + czMsgHtml('theme'));

    const langSub = sgSub('globe', t('language'), `
      <div class="lang-options">
        ${[['ru', 'langRu'], ['pl', 'langPl'], ['en', 'langEn']].map(([code, key]) => `
          <button class="lang-option ${state.language === code ? 'active' : ''}" data-lang="${code}"><span>${t(key)}</span></button>`).join('')}
      </div>`);
    const uiSub = sgSub('monitor', t('stSubInterface'), `
      <div class="sg-row">
        <div class="sg-row-text"><p class="label">${t('glassBlur')}</p><p class="desc">${t('glassBlurDesc')}</p></div>
        ${toggleHtml('st-glass', state.glassBlur)}
      </div>`);
    const devSub = sgSub('headphones', t('devices'), `
      <div class="sg-row">
        <div class="sg-row-text"><p class="label">${t('outputDevice')}</p><p class="desc">${esc(state.audioDevice || t('outputDeviceUnknown'))}</p></div>
        ${state.audioDevice ? `<span class="text-muted-c" style="font-size:.75rem;">${t('connected')}</span>` : ''}
      </div>`);
    const aboutSub = sgSub('info', t('about'), `<p class="sg-about">${t('version')}</p>`);

    return sgGroup('look', 'palette', t('stGroupLook'), t('stGroupLookDesc'), modeSub + colorsSub + bgSub + fxSub + uiSub + libLocalSub + libServerSub)
      + sgGroup('game', 'gamepad', t('stGroupGame'), t('stGroupGameDesc'), renderGameBody())
      + sgGroup('privacy', 'lock', t('stGroupPrivacy'), t('stGroupPrivacyDesc'), renderPrivacyBody())
      + sgGroup('client', 'monitor', t('stGroupClient'), t('stGroupClientDesc'), langSub + devSub + aboutSub);
  }
  function czRefresh() {
    const host = document.getElementById('cz-root');
    if (!host) return;
    const sc = host.closest('.st-content');
    const top = sc ? sc.scrollTop : 0;
    host.innerHTML = renderCustomizeInner();
    if (sc) sc.scrollTop = top;
    czStillPaint();
  }

  function wireCustomizeEvents(panel) {
    if (czServerState === 'idle') czLoadServerThemes();
    const setBg = (type, preset) => {
      cz.bg.type = type; if (preset) cz.bg.preset = preset;
      cz.bgTouched = true; cz.themeId = null;
      czSave(); czApplyBg(); czRefresh();
    };
    panel.addEventListener('mouseover', (e) => {
      const tile = e.target.closest('[data-cz-srv]');
      if (!tile || (e.relatedTarget && tile.contains(e.relatedTarget))) return;
      czTileHot(tile, true);
      czPeek(tile.getAttribute('data-cz-srv'));
    });
    panel.addEventListener('mouseout', (e) => {
      const tile = e.target.closest('[data-cz-srv]');
      if (!tile || (e.relatedTarget && tile.contains(e.relatedTarget))) return;
      czTileHot(tile, false);
      if (!(e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('[data-cz-srv]'))) czPeek(null);
    });
    panel.addEventListener('click', (e) => {
      let el;
      if ((el = e.target.closest('[data-cz-none]'))) { setBg('none'); return; }
      if ((el = e.target.closest('[data-cz-preset]'))) { setBg('preset', el.getAttribute('data-cz-preset')); return; }
      if ((el = e.target.closest('[data-cz-account]'))) { setBg('account'); return; }
      if ((el = e.target.closest('[data-cz-pick]'))) {
        if (czImage && cz.bg.type !== 'image') { setBg('image'); return; }
        const f = panel.querySelector('#cz-file'); if (f) f.click();
        return;
      }
      if (e.target.closest('[data-cz-remove]')) { czRemoveBg(); return; }
      if (e.target.closest('[data-cz-accent-reset]')) { czClearAccent(); return; }
      if ((el = e.target.closest('[data-cz-fx]'))) {
        const k = el.getAttribute('data-cz-fx');
        if (CZ_FX.includes(k) && k !== cz.particles) { cz.particles = k; cz.themeId = null; czSave(); czApplyParticles(); czRefresh(); }
        return;
      }
      if ((el = e.target.closest('[data-cz-theme]'))) {
        const th = CZ_LIBRARY.find((x) => x.id === el.getAttribute('data-cz-theme'));
        if (th) czApplyLibrary(th);
        return;
      }
      if ((el = e.target.closest('[data-cz-srv]'))) { czApplyServerTheme(el.getAttribute('data-cz-srv')); return; }
      if (e.target.closest('[data-cz-retry]')) { czLoadServerThemes(); return; }
    });
    panel.addEventListener('input', (e) => {
      const r = e.target.closest('[data-cz-range]');
      if (r) {
        const key = r.getAttribute('data-cz-range');
        if (key === 'dim') { cz.dim = czClamp(r.value, 0, 90, 35); const v = document.getElementById('cz-dim-v'); if (v) v.textContent = cz.dim + '%'; }
        else { cz.blur = czClamp(r.value, 0, 30, 0); const v = document.getElementById('cz-blur-v'); if (v) v.textContent = cz.blur + 'px'; }
        cz.themeId = null; czApplyBgVars(); czSaveSoon();
        return;
      }
      if (e.target.id === 'cz-accent') {
        cz.accent = czHex(e.target.value); cz.themeId = null;
        const hx = document.getElementById('cz-accent-hex'); if (hx) hx.textContent = cz.accent || '';
        czApplyAccent(); czSaveSoon();
        czSyncThemeToServer();
      }
    });
    panel.addEventListener('change', async (e) => {
      if (e.target.id === 'cz-file') {
        const f = e.target.files && e.target.files[0];
        e.target.value = '';
        await czPickImage(f);
        return;
      }
      if (e.target.id === 'cz-sync') {
        cz.syncBg = !!e.target.checked; czSave();
        if (cz.syncBg && cz.bg.type === 'image' && czImage) {
          try { const b = await (await fetch(czImage)).blob(); czUploadAccountBg(b, 'background.jpg'); } catch (err) {  }
        }
        return;
      }
      if (e.target.id === 'cz-accent') { czSave(); czRefresh(); }
    });
  }

  /* ===== Подписки: панель тарифов перенесена из веба. «Купить» -> оплата Platega открывается в браузере ===== */
  Object.assign(I18N.ru, {
    subBtn: 'Подписки', subRowTitle: 'Подписка', subFreeDesc: 'Бесплатный тариф', subActive: 'Активна', subActiveUntil: 'Активна до {date}',
    subHome: 'Назад', subTitle: 'Подписки LFM', subSubtitle: 'Выберите план, который вам подходит', subPriceNote: 'Цены указаны за 1 месяц (30 дней)',
    subPriceLabel: 'Стоимость:', subPeriod: '/мес', subBuy: 'Купить', subCurrent: 'Ваш тариф', subOpening: 'Открываем…',
    subRedeemTitle: 'Есть ключ активации?', subRedeemBtn: 'Применить',
    subPurchased: 'Тариф {plan} успешно активирован', subPurchaseError: 'Не удалось оформить подписку', subNetError: 'Сервер недоступен',
    subBrowserOpened: 'Оплата открыта в браузере. После оплаты вернитесь в Leaf — подписка активируется автоматически.',
    subBrowserFailed: 'Не удалось открыть браузер автоматически. Нажмите кнопку, чтобы открыть страницу оплаты.',
    subOpenAgain: 'Открыть оплату', subPaid: 'Оплата получена! Тариф {plan} активирован.',
    subFeatNoAds: 'Нету рекламы (баннеров на сайте)', subFeatEq2: 'Эквалайзер (2 прессета)', subFeatEq: 'Эквалайзер', subFeatSpeed: 'Speed Up / Slowed',
    subFeatQGood: 'Хорошее качество звука', subFeatQMax: 'Максимальное качество звука', subFeatDl: 'Загрузка треков на устройство',
    subFeatPremium: 'Статус Premium в профиле', subFeatFamily: 'Подключение до 4 аккаунтов (вместе с вами)',
    subFeatCustomTheme: 'Своя тема (произвольный акцентный цвет)', subFeatGradTheme: 'Градиентная тема (2 акцентных цвета)', subFeatYandex: 'Поиск и прослушивание Яндекс Музыки',
  });
  Object.assign(I18N.en, {
    subBtn: 'Subscriptions', subRowTitle: 'Subscription', subFreeDesc: 'Free plan', subActive: 'Active', subActiveUntil: 'Active until {date}',
    subHome: 'Back', subTitle: 'LFM Subscriptions', subSubtitle: 'Choose the plan that suits you', subPriceNote: 'Prices are shown for 1 month (30 days)',
    subPriceLabel: 'Price:', subPeriod: '/mo', subBuy: 'Buy', subCurrent: 'Your plan', subOpening: 'Opening…',
    subRedeemTitle: 'Have an activation key?', subRedeemBtn: 'Apply',
    subPurchased: '{plan} plan activated successfully', subPurchaseError: "Couldn't activate the subscription", subNetError: 'Server unavailable',
    subBrowserOpened: 'Payment opened in your browser. After paying, come back to Leaf — the subscription activates automatically.',
    subBrowserFailed: "Couldn't open the browser automatically. Click the button to open the payment page.",
    subOpenAgain: 'Open payment', subPaid: 'Payment received! {plan} is now active.',
    subFeatNoAds: 'No ads (site banners)', subFeatEq2: 'Equalizer (2 presets)', subFeatEq: 'Equalizer', subFeatSpeed: 'Speed Up / Slowed',
    subFeatQGood: 'Good audio quality', subFeatQMax: 'Maximum audio quality', subFeatDl: 'Download tracks to your device',
    subFeatPremium: 'Premium status on your profile', subFeatFamily: 'Add up to 4 accounts (including yourself)',
    subFeatCustomTheme: 'Custom theme (custom accent color)', subFeatGradTheme: 'Gradient theme (2 accent colors)', subFeatYandex: 'Search and play Yandex Music',
  });
  Object.assign(I18N.pl, {
    subBtn: 'Subskrypcje', subRowTitle: 'Subskrypcja', subFreeDesc: 'Plan darmowy', subActive: 'Aktywna', subActiveUntil: 'Aktywna do {date}',
    subHome: 'Wstecz', subTitle: 'Subskrypcje LFM', subSubtitle: 'Wybierz plan, który Ci odpowiada', subPriceNote: 'Ceny podane są za 1 miesiąc (30 dni)',
    subPriceLabel: 'Cena:', subPeriod: '/mies.', subBuy: 'Kup', subCurrent: 'Twój plan', subOpening: 'Otwieranie…',
    subRedeemTitle: 'Masz klucz aktywacyjny?', subRedeemBtn: 'Zastosuj',
    subPurchased: 'Plan {plan} został aktywowany', subPurchaseError: 'Nie udało się aktywować subskrypcji', subNetError: 'Serwer niedostępny',
    subBrowserOpened: 'Płatność otwarta w przeglądarce. Po opłaceniu wróć do Leaf — subskrypcja aktywuje się automatycznie.',
    subBrowserFailed: 'Nie udało się automatycznie otworzyć przeglądarki. Kliknij przycisk, aby otworzyć stronę płatności.',
    subOpenAgain: 'Otwórz płatność', subPaid: 'Płatność otrzymana! Plan {plan} jest aktywny.',
    subFeatNoAds: 'Brak reklam (banerów na stronie)', subFeatEq2: 'Korektor (2 presety)', subFeatEq: 'Korektor', subFeatSpeed: 'Speed Up / Slowed',
    subFeatQGood: 'Dobra jakość dźwięku', subFeatQMax: 'Maksymalna jakość dźwięku', subFeatDl: 'Pobieranie utworów na urządzenie',
    subFeatPremium: 'Status Premium na profilu', subFeatFamily: 'Do 4 kont (włącznie z Tobą)',
    subFeatCustomTheme: 'Własny motyw (dowolny kolor akcentu)', subFeatGradTheme: 'Motyw gradientowy (2 kolory akcentu)', subFeatYandex: 'Wyszukiwanie i odtwarzanie Yandex Music',
  });

  const SUB_PLANS = [
    { tier: 'lite', name: 'LFM Lite+', price: 75, feats: ['subFeatNoAds', 'subFeatEq2', 'subFeatSpeed', 'subFeatQGood', 'subFeatDl'] },
    { tier: 'standard', name: 'LFM Standart+', price: 150, feats: ['subFeatNoAds', 'subFeatEq', 'subFeatSpeed', 'subFeatQMax', 'subFeatDl', 'subFeatPremium', 'subFeatYandex'] },
    { tier: 'family', name: 'LFM Family+', price: 300, feats: ['subFeatNoAds', 'subFeatEq', 'subFeatSpeed', 'subFeatQMax', 'subFeatDl', 'subFeatPremium', 'subFeatFamily', 'subFeatCustomTheme', 'subFeatGradTheme', 'subFeatYandex'] },
  ];
  const SUB_ICON_STAR = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 1.4l1.9 3.86 4.26.62-3.08 3 .73 4.24L8 11.06l-3.81 2.06.73-4.24-3.08-3 4.26-.62L8 1.4Z" fill="currentColor"/></svg>';
  const SUB_ICON_BACK = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.5 3.2 4.4 8l5.1 4.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const SUB_ICON_CHEV = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 3.2 10.4 8 6 12.8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const SUB_ICON_EXT = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 2.5h4.5V7M13.5 2.5 7.5 8.5M12 9.5v3a1 1 0 0 1-1 1H3.5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  let sub = { open: false, busy: '', waiting: false, buyTier: '', prices: {}, names: {} };
  let _subPoll = 0;

  function subTier() { return (state.subscription && state.subscription.tier) || 'free'; }
  function subDetail(r) {
    const d = r.data && r.data.detail;
    if (d && typeof d === 'object') return d.message || '';
    return typeof d === 'string' ? d : '';
  }
  function subPlansHtml() {
    const cur = subTier();
    return SUB_PLANS.map((p) => {
      const isCur = cur === p.tier;
      const busy = sub.busy === p.tier;
      const price = sub.prices[p.tier] != null ? sub.prices[p.tier] : p.price;
      const name = sub.names[p.tier] || p.name;
      const label = isCur ? t('subCurrent') : busy ? t('subOpening') : t('subBuy') + SUB_ICON_EXT;
      return `
        <div class="sub-plan${isCur ? ' current' : ''}">
          <div class="sub-plan-name">${esc(name)}</div>
          <div class="sub-plan-price">
            <span class="sub-plan-price-label">${t('subPriceLabel')}</span>
            <span class="sub-plan-price-value">${price}₽<span class="sub-plan-price-period">${t('subPeriod')}</span></span>
          </div>
          <ul class="sub-plan-features">${p.feats.map((k) => `<li>${t(k)}</li>`).join('')}</ul>
          <button type="button" class="sub-buy-btn" data-sub-buy="${p.tier}"${isCur || sub.busy ? ' disabled' : ''}>${label}</button>
        </div>`;
    }).join('');
  }
  function subRenderPlans() {
    const el = document.getElementById('sub-plans');
    if (el) el.innerHTML = subPlansHtml();
  }
  function subSetMsg(text, kind, withReopen) {
    const el = document.getElementById('sub-msg');
    if (!el) return;
    if (!text) { el.hidden = true; el.className = 'sub-msg'; el.innerHTML = ''; return; }
    el.hidden = false;
    el.className = 'sub-msg ' + (kind || '');
    el.innerHTML = `<span class="sub-msg-text">${esc(text)}</span>${withReopen ? `<button type="button" id="sub-reopen">${t('subOpenAgain')}</button>` : ''}`;
  }
  function subInner() {
    return `
      <div class="sub-topbar"><button type="button" class="sub-home-btn" id="sub-close">${SUB_ICON_BACK}<span>${t('subHome')}</span></button></div>
      <div class="sub-content">
        <div class="sub-header">
          <h1>${t('subTitle')}</h1>
          <p>${t('subSubtitle')}</p>
          <p class="sub-price-note">${t('subPriceNote')}</p>
        </div>
        <div class="sub-msg" id="sub-msg" hidden></div>
        <div class="sub-plans" id="sub-plans">${subPlansHtml()}</div>
        <div class="sub-redeem">
          <h3>${t('subRedeemTitle')}</h3>
          <form class="sub-redeem-form" id="sub-redeem-form" autocomplete="off">
            <input type="text" id="sub-redeem-input" placeholder="LFM-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" required>
            <button type="submit">${t('subRedeemBtn')}</button>
          </form>
          <div class="sub-redeem-err" id="sub-redeem-err"></div>
          <div class="sub-redeem-ok" id="sub-redeem-ok"></div>
        </div>
      </div>`;
  }

  async function subLoadPlans() {
    const r = await accReq('/api/subscription/plans');
    if (!r.ok || !r.data || !Array.isArray(r.data.plans)) return;
    r.data.plans.forEach((p) => {
      if (p && p.tier && p.tier !== 'free') {
        if (typeof p.price_rub === 'number') sub.prices[p.tier] = p.price_rub;
        if (p.display_name) sub.names[p.tier] = p.display_name;
      }
    });
    subRenderPlans();
  }
  /* Подтягивает актуальный тариф с сервера; true — если тариф изменился */
  async function subSync() {
    const r = await accReq('/api/subscription');
    if (!r.ok || !r.data || !r.data.tier) return false;
    const before = subTier();
    state.subscription = r.data;
    const changed = before !== r.data.tier;
    if (changed) { subRenderPlans(); renderAll(); }
    return changed;
  }
  function subStopWaiting() { sub.waiting = false; sub.buyTier = ''; clearInterval(_subPoll); _subPoll = 0; }
  async function subCheckPaid() {
    if (!sub.waiting) return;
    await subSync();
    if (sub.waiting && sub.buyTier && subTier() === sub.buyTier) {
      const name = (state.subscription && state.subscription.display_name) || '';
      subStopWaiting();
      subSetMsg(t('subPaid').replace('{plan}', name), 'ok');
      subRenderPlans();
    }
  }
  function subStartPolling() {
    clearInterval(_subPoll);
    let n = 0;
    _subPoll = setInterval(() => {
      if (++n > 120 || !sub.waiting) { subStopWaiting(); return; }
      subCheckPaid();
    }, 5000);
  }

  async function subBuy(tier) {
    if (sub.busy || subTier() === tier) return;
    sub.busy = tier;
    subSetMsg('', '');
    subRenderPlans();
    const r = await accReq('/api/subscription/purchase', 'POST', { tier });
    sub.busy = '';
    if (!r.ok) {
      const msg = subDetail(r) || (r.status === 0 ? t('subNetError') : t('subPurchaseError'));
      subSetMsg(msg, 'err');
      subRenderPlans();
      return;
    }
    sub.waiting = true; sub.buyTier = tier;
    const opened = !!(r.data && r.data.opened);
    subSetMsg(opened ? t('subBrowserOpened') : t('subBrowserFailed'), 'ok', true);
    subRenderPlans();
    subStartPolling();
  }

  async function subRedeem(form) {
    const input = form.querySelector('#sub-redeem-input');
    const err = document.getElementById('sub-redeem-err');
    const ok = document.getElementById('sub-redeem-ok');
    const btn = form.querySelector('button[type=submit]');
    err.textContent = ''; ok.textContent = '';
    const code = (input.value || '').trim();
    if (!code) return;
    btn.disabled = true;
    const r = await accReq('/api/subscription/redeem', 'POST', { code });
    btn.disabled = false;
    if (!r.ok) { err.textContent = subDetail(r) || (r.status === 0 ? t('subNetError') : t('subPurchaseError')); return; }
    if (r.data && r.data.tier) state.subscription = r.data;
    ok.textContent = t('subPurchased').replace('{plan}', (r.data && r.data.display_name) || '');
    form.reset();
    subRenderPlans();
    renderAll();
  }

  function subOpen() {
    if (document.getElementById('sub-overlay')) return;
    sub.open = true;
    const el = document.createElement('div');
    el.className = 'sub-overlay';
    el.id = 'sub-overlay';
    el.innerHTML = subInner();
    document.body.appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('active')));
    el.addEventListener('click', (e) => {
      if (e.target.closest('#sub-close')) { subClose(); return; }
      const buy = e.target.closest('[data-sub-buy]');
      if (buy) { subBuy(buy.getAttribute('data-sub-buy')); return; }
      if (e.target.closest('#sub-reopen')) { accReq('/api/subscription/open-payment', 'POST'); return; }
    });
    el.addEventListener('submit', (e) => {
      if (e.target && e.target.id === 'sub-redeem-form') { e.preventDefault(); subRedeem(e.target); }
    });
    subLoadPlans();
    subSync();
  }
  function subClose() {
    const el = document.getElementById('sub-overlay');
    sub.open = false;
    if (!el) return;
    el.classList.remove('active');
    setTimeout(() => { if (el.parentNode) el.remove(); }, 220);
  }

  document.addEventListener('click', (e) => {
    if (e.target && e.target.closest && e.target.closest('#sub-open-btn')) subOpen();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && sub.open) { e.stopPropagation(); subClose(); }
  }, true);
  /* вернулись из браузера после оплаты — сразу проверяем тариф, не ждём таймера */
  window.addEventListener('focus', () => { if (sub.waiting) subCheckPaid(); });

  function accSubRowHtml() {
    const s = state.subscription;
    const paid = !!(s && s.is_paid);
    const name = (s && s.display_name) || 'LFM Free';
    let desc = t('subFreeDesc');
    if (paid) {
      desc = s.expires_at
        ? t('subActiveUntil').replace('{date}', new Date(s.expires_at).toLocaleDateString(state.language))
        : t('subActive');
    }
    return `<div style="margin-top:12px"><button type="button" class="acc-sub-row" id="acc-sub-open">
      <div class="acc-sub-text"><div class="acc-sub-title">${t('subRowTitle')}</div><div class="acc-sub-desc">${esc(desc)}</div></div>
      <span class="acc-sub-badge${paid ? ' paid' : ''}">${esc(name)}</span>${SUB_ICON_CHEV}</button></div>`;
  }

  /* ===== Конфиденциальность ===== */
  const PRIV_KEY = 'leaf-privacy';
  const priv = (() => {
    let o = {};
    try { o = JSON.parse(localStorage.getItem(PRIV_KEY) || '{}') || {}; } catch (e) {}
    return { discord: o.discord !== false, hideTrack: o.hideTrack === true, hideCover: o.hideCover === true };
  })();
  let privLiked = null, privLikedBusy = false, privLikedLoading = false, privErr = '';
  Object.assign(I18N.ru, {
    stGroupPrivacy: 'Конфиденциальность', stGroupPrivacyDesc: 'Discord-статус, видимость профиля',
    privSubDiscord: 'Discord', privSubProfile: 'Профиль',
    privDiscord: 'Показывать статус в Discord', privDiscordDesc: 'Что вы слушаете, как «Слушает» в профиле Discord',
    privHideTrack: 'Скрывать название трека', privHideTrackDesc: 'В Discord будет только «Слушает музыку»',
    privHideCover: 'Скрывать обложку', privHideCoverDesc: 'Вместо обложки — логотип Leaf',
    privLiked: 'Любимые треки публичны', privLikedDesc: 'Другие пользователи видят ваши любимые треки в профиле',
    privLikedLoading: 'Загрузка…', privLikedFail: 'Не удалось изменить настройку на сервере',
  });
  Object.assign(I18N.en, {
    stGroupPrivacy: 'Privacy', stGroupPrivacyDesc: 'Discord status, profile visibility',
    privSubDiscord: 'Discord', privSubProfile: 'Profile',
    privDiscord: 'Show Discord status', privDiscordDesc: 'What you are listening to, as "Listening to" on your Discord profile',
    privHideTrack: 'Hide track name', privHideTrackDesc: 'Discord will only show "Listening to music"',
    privHideCover: 'Hide cover art', privHideCoverDesc: 'Leaf logo is shown instead of the cover',
    privLiked: 'Liked songs are public', privLikedDesc: 'Other users can see your liked songs on your profile',
    privLikedLoading: 'Loading…', privLikedFail: 'Could not change the setting on the server',
  });
  Object.assign(I18N.pl, {
    stGroupPrivacy: 'Prywatność', stGroupPrivacyDesc: 'Status Discord, widoczność profilu',
    privSubDiscord: 'Discord', privSubProfile: 'Profil',
    privDiscord: 'Pokazuj status w Discord', privDiscordDesc: 'Czego słuchasz, jako „Słucha” w profilu Discord',
    privHideTrack: 'Ukryj tytuł utworu', privHideTrackDesc: 'Discord pokaże tylko „Słucha muzyki”',
    privHideCover: 'Ukryj okładkę', privHideCoverDesc: 'Zamiast okładki — logo Leaf',
    privLiked: 'Ulubione utwory są publiczne', privLikedDesc: 'Inni użytkownicy widzą Twoje ulubione utwory w profilu',
    privLikedLoading: 'Ładowanie…', privLikedFail: 'Nie udało się zmienić ustawienia na serwerze',
  });
  function privRow(key, on, label, desc, disabled) {
    return `<div class="sg-row"${disabled ? ' style="opacity:.45;pointer-events:none"' : ''}>
      <div class="sg-row-text"><p class="label">${label}</p><p class="desc">${desc}</p></div>
      <button class="toggle ${on ? 'on' : ''}" data-priv="${key}"><span class="knob"></span></button>
    </div>`;
  }
  function renderPrivacyBody() {
    const discordSub = sgSub('headphones', t('privSubDiscord'),
      privRow('discord', priv.discord, t('privDiscord'), t('privDiscordDesc'), false)
      + privRow('hideTrack', priv.hideTrack, t('privHideTrack'), t('privHideTrackDesc'), !priv.discord)
      + privRow('hideCover', priv.hideCover, t('privHideCover'), t('privHideCoverDesc'), !priv.discord));
    const likedDesc = privLikedLoading && privLiked === null ? t('privLikedLoading') : t('privLikedDesc');
    const profileSub = serverMode ? sgSub('user', t('privSubProfile'),
      privRow('liked', privLiked !== false, t('privLiked'), likedDesc, privLiked === null || privLikedBusy)
      + (privErr ? '<p class="cz-note">' + esc(privErr) + '</p>' : '')) : '';
    return discordSub + profileSub;
  }
  function privPush() {
    fetch('/api/telemetry/privacy', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled: priv.discord, hide_track: priv.hideTrack, hide_cover: priv.hideCover }),
    }).catch(() => {});
  }
  function privSave() {
    try { localStorage.setItem(PRIV_KEY, JSON.stringify(priv)); } catch (e) {}
    privPush();
  }
  async function privLoadLiked() {
    if (!serverMode || privLiked !== null || privLikedLoading) return;
    privLikedLoading = true; czRefresh();
    try {
      const me = await apiJson('/api/me');
      if (me && typeof me.liked_is_public === 'boolean') privLiked = me.liked_is_public;
    } catch (e) { /* оставим null: переключатель заблокирован */ }
    privLikedLoading = false; czRefresh();
  }
  async function privSetLiked(v) {
    const prev = privLiked;
    privLiked = v; privLikedBusy = true; privErr = ''; czRefresh();
    try {
      await apiJson('/api/liked/visibility', 'POST', { is_public: v });
    } catch (e) { privLiked = prev; privErr = t('privLikedFail'); }
    privLikedBusy = false; czRefresh();
  }
  function privToggle(key) {
    if (key === 'liked') { if (privLiked !== null && !privLikedBusy) privSetLiked(!privLiked); return; }
    if (key === 'discord') priv.discord = !priv.discord;
    else if (key === 'hideTrack') priv.hideTrack = !priv.hideTrack;
    else if (key === 'hideCover') priv.hideCover = !priv.hideCover;
    else return;
    privSave(); czRefresh();
  }
  privPush();

  /* ===== Игровой режим ===== */
  const GAME_KEY = 'leaf-game';
  const GAME_ACTIONS = ['playPause', 'next', 'prev', 'volUp', 'volDown', 'mute', 'like'];
  const GAME_DEFAULT_KEYS = {
    playPause: 'Ctrl+Alt+Space', next: 'Ctrl+Alt+Right', prev: 'Ctrl+Alt+Left',
    volUp: 'Ctrl+Alt+Up', volDown: 'Ctrl+Alt+Down', mute: 'Ctrl+Alt+M', like: 'Ctrl+Alt+L',
    overlayToggle: 'Shift+Backquote',   /* Shift + Ё — глобальный бинд оверлея (отдельно от GAME_ACTIONS) */
  };
  const GAME_ALL_KEYS = GAME_ACTIONS.concat('overlayToggle');
  const game = (() => {
    let o = {};
    try { o = JSON.parse(localStorage.getItem(GAME_KEY) || '{}') || {}; } catch (e) {}
    const keys = Object.assign({}, GAME_DEFAULT_KEYS);
    if (o.keys && typeof o.keys === 'object') GAME_ALL_KEYS.forEach((a) => { if (typeof o.keys[a] === 'string') keys[a] = o.keys[a]; });
    return { overlay: o.overlay === true, perf: o.perf === true, keys };
  })();
  let gameCapture = null, _gamePrevVol = 70;
  Object.assign(I18N.ru, {
    stGroupGame: 'Игровой режим', stGroupGameDesc: 'Оверлей, горячие клавиши, оптимизация',
    gameSubOverlay: 'Оверлей', gameSubKeys: 'Горячие клавиши', gameSubPerf: 'Производительность',
    gameOverlay: 'Оверлей поверх приложений', gameOverlayDesc: 'Мини-плеер в стиле Dynamic Island поверх игр и программ',
    gameOverlayKey: 'Показать / скрыть оверлей', gameOverlayTest: 'Показать оверлей сейчас',
    gameOverlayBusy: 'Это сочетание уже занято другим приложением — выберите другое.', gameOverlayBad: 'Нужен модификатор (Ctrl, Alt, Shift или Win) или клавиша F1–F24.', gameOverlayFail: 'Не удалось назначить сочетание.',
    gamePerf: 'Оптимизированный режим', gamePerfDesc: 'Отключает размытие, тени, анимации, эффекты и фон — разгружает рендеринг',
    gameKeysHint: 'Нажмите на кнопку и затем на нужное сочетание. Esc — отмена, Backspace — очистить.',
    gameKeyPress: 'Нажмите клавиши…', gameKeyNone: 'Не назначено', gameKeysReset: 'Сбросить по умолчанию',
    gaPlayPause: 'Пуск / пауза', gaNext: 'Следующий трек', gaPrev: 'Предыдущий трек', gaVolUp: 'Громкость +', gaVolDown: 'Громкость −', gaMute: 'Без звука', gaLike: 'Лайк текущему треку',
  });
  Object.assign(I18N.en, {
    stGroupGame: 'Game mode', stGroupGameDesc: 'Overlay, hotkeys, optimization',
    gameSubOverlay: 'Overlay', gameSubKeys: 'Hotkeys', gameSubPerf: 'Performance',
    gameOverlay: 'Overlay over apps', gameOverlayDesc: 'Dynamic Island–style mini player over games and apps',
    gameOverlayKey: 'Show / hide overlay', gameOverlayTest: 'Show overlay now',
    gameOverlayBusy: 'This shortcut is already used by another app — pick another one.', gameOverlayBad: 'Use a modifier (Ctrl, Alt, Shift or Win) or an F1–F24 key.', gameOverlayFail: 'Could not assign the shortcut.',
    gamePerf: 'Optimized mode', gamePerfDesc: 'Disables blur, shadows, animations, effects and background to offload rendering',
    gameKeysHint: 'Click a button, then press the shortcut. Esc cancels, Backspace clears.',
    gameKeyPress: 'Press keys…', gameKeyNone: 'Not set', gameKeysReset: 'Reset to defaults',
    gaPlayPause: 'Play / pause', gaNext: 'Next track', gaPrev: 'Previous track', gaVolUp: 'Volume up', gaVolDown: 'Volume down', gaMute: 'Mute', gaLike: 'Like current track',
  });
  Object.assign(I18N.pl, {
    stGroupGame: 'Tryb gry', stGroupGameDesc: 'Nakładka, skróty, optymalizacja',
    gameSubOverlay: 'Nakładka', gameSubKeys: 'Skróty klawiszowe', gameSubPerf: 'Wydajność',
    gameOverlay: 'Nakładka nad aplikacjami', gameOverlayDesc: 'Mini odtwarzacz w stylu Dynamic Island nad grami i programami',
    gameOverlayKey: 'Pokaż / ukryj nakładkę', gameOverlayTest: 'Pokaż nakładkę teraz',
    gameOverlayBusy: 'Ten skrót jest już używany przez inną aplikację — wybierz inny.', gameOverlayBad: 'Użyj modyfikatora (Ctrl, Alt, Shift lub Win) albo klawisza F1–F24.', gameOverlayFail: 'Nie udało się przypisać skrótu.',
    gamePerf: 'Tryb zoptymalizowany', gamePerfDesc: 'Wyłącza rozmycie, cienie, animacje, efekty i tło — odciąża renderowanie',
    gameKeysHint: 'Kliknij przycisk, a potem skrót. Esc anuluje, Backspace czyści.',
    gameKeyPress: 'Naciśnij klawisze…', gameKeyNone: 'Nie przypisano', gameKeysReset: 'Przywróć domyślne',
    gaPlayPause: 'Odtwarzaj / pauza', gaNext: 'Następny utwór', gaPrev: 'Poprzedni utwór', gaVolUp: 'Głośniej', gaVolDown: 'Ciszej', gaMute: 'Wycisz', gaLike: 'Polub bieżący utwór',
  });
  function gameSave() { try { localStorage.setItem(GAME_KEY, JSON.stringify(game)); } catch (e) {} overlaySync(); }
  function gameApplyPerf() {
    document.documentElement.classList.toggle('perf-mode', game.perf);
    czApplyParticles();
  }
  function gameComboOf(e) {
    const c = e.code || '';
    if (/^(Control|Alt|Shift|Meta|OS)(Left|Right)$/.test(c) || !c) return '';
    let name = c.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Arrow/, '');
    const mods = [];
    if (e.ctrlKey) mods.push('Ctrl');
    if (e.altKey) mods.push('Alt');
    if (e.shiftKey) mods.push('Shift');
    if (e.metaKey) mods.push('Meta');
    return mods.concat(name).join('+');
  }
  function gameKeyLabel(a) {
    if (gameCapture === a) return t('gameKeyPress');
    return game.keys[a] ? gameKeyPretty(game.keys[a]) : t('gameKeyNone');
  }
  const GAME_KEY_GLYPHS = { Meta: 'Win', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Backslash: '\\', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/' };
  function gameKeyPretty(combo) {
    return combo.split('+').map((p) => {
      if (p === 'Backquote') return state.language === 'ru' ? 'Ё' : '`';
      return GAME_KEY_GLYPHS[p] || p;
    }).join(' + ');
  }
  function gameRow(a, label, extra) {
    return `<div class="sg-row"><div class="sg-row-text"><p class="label">${label}</p></div>
      <button class="cz-chip game-key${gameCapture === a ? ' selected' : ''}" data-game-key="${a}">${esc(gameKeyLabel(a))}</button></div>`;
  }
  function renderGameBody() {
    const row = (key, on, label, desc) => `<div class="sg-row">
      <div class="sg-row-text"><p class="label">${label}</p><p class="desc">${desc}</p></div>
      <button class="toggle ${on ? 'on' : ''}" data-game="${key}"><span class="knob"></span></button></div>`;
    const A = { playPause: 'gaPlayPause', next: 'gaNext', prev: 'gaPrev', volUp: 'gaVolUp', volDown: 'gaVolDown', mute: 'gaMute', like: 'gaLike' };
    const ovErr = overlayStatus ? `<p class="cz-note" style="margin:.6rem 0 0;color:#ef4444">${esc(t(overlayStatus === 'busy' ? 'gameOverlayBusy' : (overlayStatus === 'need_modifier' || overlayStatus === 'bad_key' || overlayStatus === 'bad_modifier' || overlayStatus === 'empty') ? 'gameOverlayBad' : 'gameOverlayFail'))}</p>` : '';
    return sgSub('monitor', t('gameSubOverlay'), row('overlay', game.overlay, t('gameOverlay'), t('gameOverlayDesc'))
          + (game.overlay ? gameRow('overlayToggle', t('gameOverlayKey')) + ovErr
            + `<button class="cz-link" data-overlay-test style="margin-top:.8rem">${t('gameOverlayTest')}</button>` : ''))
      + sgSub('gamepad', t('gameSubKeys'),
          `<p class="cz-note" style="margin:0 0 .9rem">${t('gameKeysHint')}</p>`
          + GAME_ACTIONS.map((a) => gameRow(a, t(A[a]))).join('')
          + `<button class="cz-link" data-game-reset style="margin-top:1rem">${t('gameKeysReset')}</button>`)
      + sgSub('zap', t('gameSubPerf'), row('perf', game.perf, t('gamePerf'), t('gamePerfDesc')));
  }
  function gameToggle(k) {
    if (k === 'overlay') { game.overlay = !game.overlay; if (!game.overlay && gameCapture === 'overlayToggle') gameCapture = null; }
    else if (k === 'perf') { game.perf = !game.perf; gameApplyPerf(); }
    else return;
    gameSave(); czRefresh();
  }
  function gameStartCapture(a) { gameCapture = gameCapture === a ? null : a; overlaySync(); czRefresh(); }
  function gameResetKeys() { Object.assign(game.keys, GAME_DEFAULT_KEYS); gameCapture = null; gameSave(); czRefresh(); }
  function gameRun(a) {
    const setVol = (v) => { state.volume = Math.max(0, Math.min(100, Math.round(v))); audioEl.volume = state.volume / 100; updatePlayerBarOnly(); };
    if (a === 'playPause') togglePlay();
    else if (a === 'next') handleNext();
    else if (a === 'prev') handlePrev();
    else if (a === 'volUp') setVol(state.volume + 5);
    else if (a === 'volDown') setVol(state.volume - 5);
    else if (a === 'mute') { if (state.volume > 0) { _gamePrevVol = state.volume; setVol(0); } else setVol(_gamePrevVol || 70); }
    else if (a === 'like') { if (state.currentTrack) toggleLike(state.currentTrack.id); }
  }
  /* ===== Оверлей (Dynamic Island): связь с Python и страницей overlay.html ===== */
  let overlayStatus = '';
  function overlayApi(method, ...args) {
    return new Promise((resolve) => {
      const go = () => {
        const api = window.pywebview && window.pywebview.api;
        if (!api || typeof api[method] !== 'function') return false;
        try { api[method](...args).then(resolve, () => resolve(null)); } catch (e) { resolve(null); }
        return true;
      };
      if (go()) return;
      window.addEventListener('pywebviewready', () => { if (!go()) resolve(null); }, { once: true });
      setTimeout(() => resolve(null), 10000);
    });
  }
  let _ovSyncSeq = 0;
  async function overlaySync() {
    const seq = ++_ovSyncSeq;
    const r = await overlayApi('overlay_configure', !!game.overlay, game.keys.overlayToggle || '', gameCapture === 'overlayToggle');
    if (seq !== _ovSyncSeq) return;
    const next = r && r.ok === false ? (r.error || 'fail') : '';
    if (next !== overlayStatus) { overlayStatus = next; czRefresh(); }
    if (game.overlay) overlayPush(true);
  }
  let _ovSig = '', _ovWatching = false;
  function overlayPush(force) {
    if (!game.overlay) return;
    const tr = state.currentTrack;
    const dur = tr ? (audioEl.duration && isFinite(audioEl.duration) ? audioEl.duration : (tr.duration || 0)) : 0;
    const base = {
      has_track: !!tr,
      title: tr ? (tr.title || '').replace(new RegExp('\\s*[-–—]\\s*' + (tr.artist || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$', 'i'), '').trim() : '',
      artist: tr ? (tr.artist || '') : '',
      cover: tr ? (tr.cover || '') : '',
      duration: dur,
      is_playing: !!state.isPlaying,
      liked: !!(tr && state.likedTracks.has(tr.id)),
      volume: state.volume,
      accent: (getComputedStyle(document.documentElement).getPropertyValue('--accent') || '').trim() || '#22c55e',
      lang: state.language,
    };
    const sig = JSON.stringify(base);
    const pos = audioEl.currentTime || state.progress || 0;
    if (!force && sig === _ovSig && !_ovWatching) return;
    _ovSig = sig;
    fetch('/api/overlay/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ position: pos }, base)),
    }).then((r) => r.json()).then((j) => { _ovWatching = !!(j && j.watching); }).catch(() => {});
  }
  window.leafOverlayPush = overlayPush;
  window.leafOverlayCmd = (name, arg) => {
    if (name === 'seek') {
      const v = Number(arg);
      if (isFinite(v) && state.currentTrack) { audioEl.currentTime = Math.max(0, v); state.progress = audioEl.currentTime; }
    } else if (GAME_ACTIONS.indexOf(name) > -1) gameRun(name);
    setTimeout(() => overlayPush(true), 120);
  };
  setInterval(() => { if (game.overlay) overlayPush(false); }, 1000);
  ['play', 'pause', 'loadedmetadata', 'emptied', 'volumechange'].forEach((ev) => audioEl.addEventListener(ev, () => overlayPush(true)));

  document.addEventListener('keydown', (e) => {
    if (gameCapture) {
      e.preventDefault(); e.stopPropagation();
      const a = gameCapture;
      if (e.key === 'Escape') { gameCapture = null; overlaySync(); czRefresh(); return; }
      if ((e.key === 'Backspace' || e.key === 'Delete') && !e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey) {
        game.keys[a] = ''; gameCapture = null; gameSave(); czRefresh(); return;
      }
      const combo = gameComboOf(e);
      if (!combo) return;
      GAME_ALL_KEYS.forEach((o) => { if (o !== a && game.keys[o] === combo) game.keys[o] = ''; });
      game.keys[a] = combo; gameCapture = null; gameSave(); czRefresh();
      return;
    }
    const combo = gameComboOf(e);
    if (!combo) return;
    const act = GAME_ACTIONS.find((a) => game.keys[a] && game.keys[a] === combo);
    if (!act) return;
    const tg = e.target;
    const typing = tg && (tg.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName));
    if (typing && !(e.ctrlKey || e.altKey || e.metaKey)) return;
    if (e.repeat && act !== 'volUp' && act !== 'volDown') return;
    e.preventDefault();
    gameRun(act);
  }, true);
  gameApplyPerf();
  overlaySync();

  czInit();
  renderAll();
  loadHomeTracks();
  syncLibrary();
  let _lastSync = Date.now();
  window.addEventListener('focus', () => {
    if (state.homeStatus === 'error') loadHomeTracks();
    if (Date.now() - _lastSync < 30000) return;
    _lastSync = Date.now();
    syncLibrary();
  });
  loadTelemetry();

  /* Присутствие: сервер считает пользователя «В сети», если last_seen свежее 3 минут.
     /api/me зовётся только при старте, поэтому пингуем сами — тогда в профиле будет «В сети: Leaf Desktop». */
  setInterval(() => { if (serverMode && !document.hidden) apiJson('/api/ping').catch(() => {}); }, 60000);
})();